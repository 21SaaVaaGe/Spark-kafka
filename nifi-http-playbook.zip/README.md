# Apache NiFi 1.27.0 по HTTP — Ansible playbook

Этот плейбук устанавливает Apache NiFi **1.27.0** на Linux‑хост, включает **HTTP** (без TLS), создает **systemd**‑сервис и проверяет доступность веб‑интерфейса (`/nifi/`) на указанном порту (по умолчанию `8080`).

## Как использовать

1. Добавьте нужные узлы в инвентарь, например:
   ```ini
   [nifi]
   your-hostname ansible_user=ubuntu
   ```
2. Скопируйте файлы `nifi-http.yml` и этот `README.md` на контрольный узел.
3. (Опционально) укажите SHA‑256 архива релиза в переменной `nifi_sha256` — сумму можно взять из файла `nifi-1.27.0-bin.zip.sha256` на archive.apache.org.
4. Запустите:
   ```bash
   ansible-playbook -i hosts.ini nifi-http.yml
   ```

После выполнения UI будет доступен на `http://<host>:8080/nifi/` (если `nifi_http_port` не меняли).

## Требования

- Ansible 2.9+ (рекомендуется актуальная версия).
- Дистрибутивы семейства Debian/Ubuntu или RHEL/CentOS/Rocky/Alma (ставится `openjdk-17`).
- Доступ `become: yes` (sudo/root).
- Исходящий доступ к `archive.apache.org` для скачивания архива NiFi.

## Переменные (секция `vars`)

- `nifi_version` — нужная версия NiFi (по умолчанию `1.27.0`).
- `nifi_install_dir` — путь установки (`/opt/nifi`).
- `nifi_user`, `nifi_group` — системный пользователь/группа сервиса.
- `nifi_http_host` — адрес бинда HTTP (`0.0.0.0` для всех интерфейсов).
- `nifi_http_port` — порт HTTP (по умолчанию `8080`).
- `nifi_download_url` — URL архива релиза.
- `nifi_sha256` — SHA‑256 суммы архива (строка; оставить пустым, чтобы пропустить проверку).
- `nifi_heap` — размер кучи JVM (`Xms`/`Xmx`) для `bootstrap.conf`.
- `nifi_sensitive_props_key` — ключ для шифрования чувствительных свойств NiFi. Генерируется локально на контроллере Ansible через lookup `password` и кэшируется в файле `.nifi_sensitive_key` рядом с плейбуком.

## Что делает плейбук (по шагам)

1. **Предустановка**: ставит `unzip` и Java 17 для вашей ОС (apt или yum).
2. **Пользователь и директории**: создает `nifi:nifi` и каталог установки `/opt/nifi`.
3. **Скачивание и распаковка**: скачивает `nifi-1.27.0-bin.zip`, распаковывает в `/opt/nifi`.
4. **Симлинк**: создает `/opt/nifi/current` на версионированный каталог.
5. **Права**: рекурсивно выдает владельца `nifi:nifi`.
6. **Конфигурация `nifi.properties`**:
   - включает HTTP: задает `nifi.web.http.host` и `nifi.web.http.port`
   - отключает HTTPS: очищает `nifi.web.https.host` и `nifi.web.https.port`
   - прописывает `nifi.sensitive.props.key`
7. **Тюнинг `bootstrap.conf`**: записывает `java.arg.2=-Xms...` и `java.arg.3=-Xmx...` на основе `nifi_heap`.
8. **systemd unit**: создает `/etc/systemd/system/nifi.service` c `ExecStart=nifi.sh run`, включает автозапуск.
9. **Проверка готовности**: ждет HTTP 200/302 от `http://127.0.0.1:<port>/nifi/` (30 попыток с задержкой 5с).

## Управление сервисом

```bash
sudo systemctl status nifi
sudo systemctl restart nifi
sudo journalctl -u nifi -f
```

## Безопасность

Плейбук намеренно включает **HTTP без TLS** — используйте только в доверенных средах или за реверс‑прокси/фаерволом. Для production рекомендуется включить HTTPS (TLS) в `nifi.properties` и настроить сертификаты, а также ограничить доступ по сети.

## Настройка Java

Если ваша система требует явного `JAVA_HOME`, раскомментируйте соответствующую строку в юните systemd и укажите путь к OpenJDK 17, например:
```
Environment="JAVA_HOME=/usr/lib/jvm/java-17-openjdk"
```

## Обновление версии

Чтобы поставить другую версию NiFi, измените `nifi_version` и (при необходимости) `nifi_download_url`/`nifi_sha256`, затем повторно выполните плейбук. Симлинк `current` будет указывать на новую версию; не забудьте проверить миграцию конфигов при переходах между минорными релизами.

---

Удачных деплоев! Если нужен вариант в виде роли (`roles/nifi/...`) или с шаблонами `template`, дайте знать.
