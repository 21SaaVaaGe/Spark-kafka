"""
Скрипт 2: Streaming + broadcast join с MSSQL справочником.

Читает GSM из Kafka, делает join с таблицей MSSQL (base stations),
фильтрует по совпадению, выводит в консоль.

Запуск:
  spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.4.0 \\
    --packages com.microsoft.sqlserver:mssql-jdbc:12.2.0.jre11 \\
    02_streaming_mssql_broadcast.py
"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json, broadcast
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType, TimestampType
)

GSM_SCHEMA = StructType([
    StructField("IMSI", StringType(), True),
    StructField("IMEI", StringType(), True),
    StructField("phone_number", StringType(), True),
    StructField("base_station_id", StringType(), True),
    StructField("lac", StringType(), True),
    StructField("cell_id", StringType(), True),
    StructField("event_time", TimestampType(), True),
    StructField("call_duration", LongType(), True),
    StructField("billing_info", StringType(), True),
])

# JDBC для MSSQL
MSSQL_JDBC = "jdbc:sqlserver://localhost:1433;databaseName=YourDB"
MSSQL_TABLE = "dbo.BaseStations"
MSSQL_USER = "sa"
MSSQL_PASSWORD = "YourPassword"
MSSQL_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver"


def main():
    spark = SparkSession.builder \
        .appName("GSM-MSSQL-Broadcast") \
        .config("spark.sql.adaptive.enabled", "true") \
        .getOrCreate()

    # 1. Загружаем справочник MSSQL (broadcast для маленьких таблиц)
    ref_df = spark.read \
        .format("jdbc") \
        .option("url", MSSQL_JDBC) \
        .option("dbtable", MSSQL_TABLE) \
        .option("user", MSSQL_USER) \
        .option("password", MSSQL_PASSWORD) \
        .option("driver", MSSQL_DRIVER) \
        .load()

    # Переименуем колонки для join (если в MSSQL другие имена)
    # ref_df = ref_df.withColumnRenamed("bs_id", "base_station_id")
    ref_broadcast = broadcast(ref_df)

    # 2. Стриминг из Kafka
    df_raw = spark.readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", "localhost:9092") \
        .option("subscribe", "GSM") \
        .option("startingOffsets", "latest") \
        .load()

    df_gsm = df_raw.select(
        from_json(col("value").cast("string"), GSM_SCHEMA).alias("data")
    ).select("data.*")

    # 3. Join по base_station_id (или lac, cell_id — настройте под свою схему)
    join_cols = ["base_station_id"]
    # Если в ref есть lac, cell_id:
    # join_cols = ["base_station_id", "lac", "cell_id"]

    df_joined = df_gsm.join(
        ref_broadcast,
        on=join_cols,
        how="inner"
    )

    # 4. Выбираем нужные поля (избегаем дубликатов из ref)
    output_cols = ["IMSI", "IMEI", "phone_number", "base_station_id", "event_time", "call_duration"]
    df_out = df_joined.select([c for c in output_cols if c in df_joined.columns])

    query = df_out.writeStream \
        .outputMode("append") \
        .format("console") \
        .option("truncate", False) \
        .start()

    query.awaitTermination()


if __name__ == "__main__":
    main()
