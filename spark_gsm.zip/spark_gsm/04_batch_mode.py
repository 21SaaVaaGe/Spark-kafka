"""
Скрипт 4: Batch-режим для тестирования (одноразовое чтение).

Читает ограниченный объём из Kafka, делает join с MSSQL, пишет в MSSQL и Kafka.
Удобно для отладки и CI.

Запуск:
  spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.4.0 \\
    --packages com.microsoft.sqlserver:mssql-jdbc:12.2.0.jre11 \\
    04_batch_mode.py
"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json, struct, to_json
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType, TimestampType
)

GSM_SCHEMA = StructType([
    StructField("IMSI", StringType(), True),
    StructField("IMEI", StringType(), True),
    StructField("phone_number", StringType(), True),
    StructField("base_station_id", StringType(), True),
    StructField("lac", StringType(), True),
    StructField("cell_id", StringType(), True),
    StructField("event_time", TimestampType(), True),
    StructField("call_duration", LongType(), True),
    StructField("billing_info", StringType(), True),
])

KAFKA_BOOTSTRAP = "localhost:9092"
KAFKA_TOPIC_SOURCE = "GSM"
KAFKA_TOPIC_SINK = "GSM_VALIDATED"
MSSQL_JDBC = "jdbc:sqlserver://localhost:1433;databaseName=YourDB"
MSSQL_REF_TABLE = "dbo.BaseStations"
MSSQL_SINK_TABLE = "dbo.ValidatedRecords"
MSSQL_USER = "sa"
MSSQL_PASSWORD = "YourPassword"
MSSQL_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver"

# Batch: читаем весь доступный интервал (earliest..latest)


def main():
    spark = SparkSession.builder \
        .appName("GSM-Batch") \
        .getOrCreate()

    # 1. Batch read из Kafka (limit через maxOffsetsPerTrigger)
    df_raw = spark.read \
        .format("kafka") \
        .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP) \
        .option("subscribe", KAFKA_TOPIC_SOURCE) \
        .option("startingOffsets", "earliest") \
        .option("endingOffsets", "latest") \
        .load()

    df_gsm = df_raw.select(
        from_json(col("value").cast("string"), GSM_SCHEMA).alias("data")
    ).select("data.*")

    # 2. Join с MSSQL
    ref_df = spark.read \
        .format("jdbc") \
        .option("url", MSSQL_JDBC) \
        .option("dbtable", MSSQL_REF_TABLE) \
        .option("user", MSSQL_USER) \
        .option("password", MSSQL_PASSWORD) \
        .option("driver", MSSQL_DRIVER) \
        .load()

    joined = df_gsm.join(ref_df, on="base_station_id", how="inner")
    output_cols = ["IMSI", "IMEI", "phone_number", "base_station_id", "event_time", "call_duration"]
    valid = joined.select([c for c in output_cols if c in joined.columns])

    count = valid.count()
    print(f"Validated records: {count}")

    if count == 0:
        print("No records to write.")
        return

    # 3. Запись в MSSQL
    valid.write \
        .format("jdbc") \
        .option("url", MSSQL_JDBC) \
        .option("dbtable", MSSQL_SINK_TABLE) \
        .option("user", MSSQL_USER) \
        .option("password", MSSQL_PASSWORD) \
        .option("driver", MSSQL_DRIVER) \
        .mode("append") \
        .save()

    # 4. Запись в Kafka
    df_kafka = valid.select(to_json(struct(*valid.columns)).alias("value"))
    df_kafka.write \
        .format("kafka") \
        .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP) \
        .option("topic", KAFKA_TOPIC_SINK) \
        .save()

    print("Done: MSSQL + Kafka written.")


if __name__ == "__main__":
    main()
