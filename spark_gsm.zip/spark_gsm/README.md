# GSM Kafka → MSSQL Pipeline (PySpark + Structured Streaming)

Набор скриптов для обработки GSM-данных из Kafka (Avro/JSON), валидации по MSSQL и записи в MSSQL и Kafka.

## Архитектура

```
Kafka (GSM) → Spark Structured Streaming → Join MSSQL (base_station) → 
  ├─ MSSQL (ValidatedRecords)
  └─ Kafka (GSM_VALIDATED)
```

## Скрипты

| Скрипт | Описание |
|--------|----------|
| `01_kafka_avro_read.py` | Базовое чтение из Kafka с парсингом JSON (схема Avro-подобная) |
| `01_kafka_avro_read_confluent.py` | Чтение Avro через Confluent Schema Registry |
| `02_streaming_mssql_broadcast.py` | Streaming + broadcast join с MSSQL, вывод в консоль |
| `03_streaming_foreachbatch_dual_sink.py` | foreachBatch: запись в MSSQL и Kafka |
| `04_batch_mode.py` | Batch-режим (одно чтение) для тестов |
| `05_config_driven_pipeline.py` | Конфиг из `config.py`, режимы `--mode streaming` / `batch` |
| `06_local_file_test.py` | Тест без Kafka: JSON-файл → join MSSQL → write |
| `07_streaming_kafka_only_sinks.py` | Два отдельных sink (MSSQL + Kafka) от одного stream |

## Зависимости

```bash
pip install -r requirements.txt
```

Spark-submit с пакетами:

```bash
spark-submit \
  --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.4.0 \
  --packages org.apache.spark:spark-avro_2.12:3.4.0 \
  --packages com.microsoft.sqlserver:mssql-jdbc:12.2.0.jre11 \
  ваш_скрипт.py
```

## Конфигурация

Отредактируйте `config.py`:

- `KAFKA_BOOTSTRAP_SERVERS`, `KAFKA_TOPIC_SOURCE`, `KAFKA_TOPIC_SINK`
- `MSSQL_JDBC_URL`, `MSSQL_REFERENCE_TABLE`, `MSSQL_SINK_TABLE`
- `JOIN_COLUMNS` — поля для join (например `base_station_id`, `lac`, `cell_id`)
- `OUTPUT_COLUMNS` — поля, которые пишем в MSSQL и Kafka

## Схема Avro/JSON (пример)

```
IMSI, IMEI, phone_number, base_station_id, lac, cell_id,
event_time, call_duration, billing_info
```

Подставьте свою схему в `GSM_SCHEMA` в каждом скрипте.

## Примеры запуска

```bash
# Batch для отладки
spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.4.0,com.microsoft.sqlserver:mssql-jdbc:12.2.0.jre11 04_batch_mode.py

# Streaming с конфигом
spark-submit ... 05_config_driven_pipeline.py --mode streaming

# Локальный тест без Kafka
spark-submit --packages com.microsoft.sqlserver:mssql-jdbc:12.2.0.jre11 06_local_file_test.py --input /path/to/data.jsonl --output-mssql
```
