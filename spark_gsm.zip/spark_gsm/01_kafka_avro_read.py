"""
Скрипт 1: Базовое чтение Avro из Kafka (Spark Structured Streaming).

Запуск:
  spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.4.0 \\
    --packages org.apache.spark:spark-avro_2.12:3.4.0 \\
    01_kafka_avro_read.py
"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType, DoubleType, TimestampType
)

# Схема Avro для GSM (пример; замените на свою)
GSM_AVRO_SCHEMA = StructType([
    StructField("IMSI", StringType(), True),
    StructField("IMEI", StringType(), True),
    StructField("phone_number", StringType(), True),
    StructField("base_station_id", StringType(), True),
    StructField("lac", StringType(), True),
    StructField("cell_id", StringType(), True),
    StructField("event_time", TimestampType(), True),
    StructField("call_duration", LongType(), True),
    StructField("billing_info", StringType(), True),
])


def main():
    spark = SparkSession.builder \
        .appName("GSM-Kafka-Avro-Read") \
        .getOrCreate()

    # Чтение сырых байт из Kafka
    df_raw = spark.readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", "localhost:9092") \
        .option("subscribe", "GSM") \
        .option("startingOffsets", "latest") \
        .load()

    # Если Avro хранится в value как JSON (часто при Kafka + Avro)
    # Используем from_json с schema
    df_parsed = df_raw.select(
        col("topic"),
        col("partition"),
        col("offset"),
        from_json(col("value").cast("string"), GSM_AVRO_SCHEMA).alias("data")
    ).select("topic", "partition", "offset", "data.*")

    # Консольный вывод (для отладки)
    query = df_parsed.writeStream \
        .outputMode("append") \
        .format("console") \
        .option("truncate", False) \
        .start()

    query.awaitTermination()


if __name__ == "__main__":
    main()
