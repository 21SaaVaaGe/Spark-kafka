"""
Скрипт 6: Локальное тестирование без Kafka.

Читает JSON/AVRO из файла или папки, имитирует pipeline: join с MSSQL → write.

Запуск (без Kafka, только MSSQL):
  spark-submit --packages com.microsoft.sqlserver:mssql-jdbc:12.2.0.jre11 \\
    06_local_file_test.py --input /path/to/gsm_data.json

Формат JSON: один объект на строку (JSON Lines) с полями IMSI, IMEI, base_station_id, etc.
"""
import argparse
from pyspark.sql import SparkSession
from pyspark.sql.functions import broadcast

MSSQL_JDBC = "jdbc:sqlserver://localhost:1433;databaseName=YourDB"
MSSQL_REF_TABLE = "dbo.BaseStations"
MSSQL_SINK_TABLE = "dbo.ValidatedRecords"
MSSQL_USER = "sa"
MSSQL_PASSWORD = "YourPassword"
MSSQL_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Path to JSON/JSONL file or directory")
    parser.add_argument("--output-mssql", action="store_true", help="Write to MSSQL")
    parser.add_argument("--output-dir", default="/tmp/gsm_validated", help="Local output (parquet)")
    args = parser.parse_args()

    spark = SparkSession.builder \
        .appName("GSM-Local-File-Test") \
        .getOrCreate()

    # Читаем JSON (JSON Lines)
    df_gsm = spark.read.json(args.input)

    # Join с MSSQL
    ref_df = spark.read \
        .format("jdbc") \
        .option("url", MSSQL_JDBC) \
        .option("dbtable", MSSQL_REF_TABLE) \
        .option("user", MSSQL_USER) \
        .option("password", MSSQL_PASSWORD) \
        .option("driver", MSSQL_DRIVER) \
        .load()

    joined = df_gsm.join(broadcast(ref_df), on="base_station_id", how="inner")
    output_cols = ["IMSI", "IMEI", "phone_number", "base_station_id", "event_time", "call_duration"]
    valid = joined.select([c for c in output_cols if c in joined.columns])

    valid.show(20, truncate=False)
    print(f"Total: {valid.count()}")

    if args.output_mssql:
        valid.write \
            .format("jdbc") \
            .option("url", MSSQL_JDBC) \
            .option("dbtable", MSSQL_SINK_TABLE) \
            .option("user", MSSQL_USER) \
            .option("password", MSSQL_PASSWORD) \
            .option("driver", MSSQL_DRIVER) \
            .mode("append") \
            .save()
        print("Written to MSSQL.")
    else:
        valid.write.mode("overwrite").parquet(args.output_dir)
        print(f"Written to {args.output_dir}")


if __name__ == "__main__":
    main()
