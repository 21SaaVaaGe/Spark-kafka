"""
Скрипт 7: Два независимых sink через дублирование стрима.

Один обработанный stream → два writeStream (MSSQL через foreachBatch, Kafka напрямую).
Используем .writeStream дважды от одного DataFrame.

Важно: оба query используют один checkpoint — нужны разные checkpoint paths.
"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json, struct, to_json, broadcast
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType, TimestampType
)

GSM_SCHEMA = StructType([
    StructField("IMSI", StringType(), True),
    StructField("IMEI", StringType(), True),
    StructField("phone_number", StringType(), True),
    StructField("base_station_id", StringType(), True),
    StructField("lac", StringType(), True),
    StructField("cell_id", StringType(), True),
    StructField("event_time", TimestampType(), True),
    StructField("call_duration", LongType(), True),
    StructField("billing_info", StringType(), True),
])

KAFKA_BOOTSTRAP = "localhost:9092"
KAFKA_TOPIC_SOURCE = "GSM"
KAFKA_TOPIC_SINK = "GSM_VALIDATED"
MSSQL_JDBC = "jdbc:sqlserver://localhost:1433;databaseName=YourDB"
MSSQL_REF_TABLE = "dbo.BaseStations"
MSSQL_SINK_TABLE = "dbo.ValidatedRecords"
MSSQL_USER = "sa"
MSSQL_PASSWORD = "YourPassword"
MSSQL_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
CHECKPOINT_MSSQL = "/tmp/spark_checkpoint/gsm_mssql"
CHECKPOINT_KAFKA = "/tmp/spark_checkpoint/gsm_kafka"


def main():
    spark = SparkSession.builder \
        .appName("GSM-Two-Sinks") \
        .getOrCreate()

    ref_df = spark.read \
        .format("jdbc") \
        .option("url", MSSQL_JDBC) \
        .option("dbtable", MSSQL_REF_TABLE) \
        .option("user", MSSQL_USER) \
        .option("password", MSSQL_PASSWORD) \
        .option("driver", MSSQL_DRIVER) \
        .load()

    df_raw = spark.readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP) \
        .option("subscribe", KAFKA_TOPIC_SOURCE) \
        .option("startingOffsets", "latest") \
        .load()

    df_gsm = df_raw.select(
        from_json(col("value").cast("string"), GSM_SCHEMA).alias("data")
    ).select("data.*")

    validated = df_gsm.join(broadcast(ref_df), on="base_station_id", how="inner")
    output_cols = ["IMSI", "IMEI", "phone_number", "base_station_id", "event_time", "call_duration"]
    valid = validated.select([c for c in output_cols if c in validated.columns])

    # Query 1: MSSQL через foreachBatch
    def write_mssql_batch(batch_df, batch_id):
        if not batch_df.isEmpty():
            batch_df.write \
                .format("jdbc") \
                .option("url", MSSQL_JDBC) \
                .option("dbtable", MSSQL_SINK_TABLE) \
                .option("user", MSSQL_USER) \
                .option("password", MSSQL_PASSWORD) \
                .option("driver", MSSQL_DRIVER) \
                .mode("append") \
                .save()

    q1 = valid.writeStream \
        .foreachBatch(write_mssql_batch) \
        .outputMode("append") \
        .option("checkpointLocation", CHECKPOINT_MSSQL) \
        .trigger(processingTime="30 seconds") \
        .start()

    # Query 2: Kafka (требует value в формате key-value)
    df_kafka = valid.select(to_json(struct(*valid.columns)).alias("value"))
    q2 = df_kafka.writeStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP) \
        .option("topic", KAFKA_TOPIC_SINK) \
        .option("checkpointLocation", CHECKPOINT_KAFKA) \
        .trigger(processingTime="30 seconds") \
        .outputMode("append") \
        .start()

    # Оба query работают параллельно; ждём до остановки
    spark.streams.awaitAnyTermination()


if __name__ == "__main__":
    main()
