"""
Скрипт 3: foreachBatch — двойной sink: MSSQL + Kafka.

Для каждого микробatch: join с MSSQL, фильтрация, запись в MSSQL и в Kafka.

Запуск:
  spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.4.0 \\
    --packages com.microsoft.sqlserver:mssql-jdbc:12.2.0.jre11 \\
    03_streaming_foreachbatch_dual_sink.py
"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json, struct, to_json
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType, TimestampType
)

GSM_SCHEMA = StructType([
    StructField("IMSI", StringType(), True),
    StructField("IMEI", StringType(), True),
    StructField("phone_number", StringType(), True),
    StructField("base_station_id", StringType(), True),
    StructField("lac", StringType(), True),
    StructField("cell_id", StringType(), True),
    StructField("event_time", TimestampType(), True),
    StructField("call_duration", LongType(), True),
    StructField("billing_info", StringType(), True),
])

KAFKA_BOOTSTRAP = "localhost:9092"
KAFKA_TOPIC_SINK = "GSM_VALIDATED"
MSSQL_JDBC = "jdbc:sqlserver://localhost:1433;databaseName=YourDB"
MSSQL_REF_TABLE = "dbo.BaseStations"
MSSQL_SINK_TABLE = "dbo.ValidatedRecords"
MSSQL_USER = "sa"
MSSQL_PASSWORD = "YourPassword"
MSSQL_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
CHECKPOINT = "/tmp/spark_checkpoint/gsm_dual_sink"


def write_mssql_and_kafka(batch_df, batch_id):
    """foreachBatch: запись в MSSQL и Kafka."""
    if batch_df.isEmpty():
        return

    # 1. Загрузка справочника MSSQL для join (на каждый batch — актуальные данные)
    ref_df = batch_df.sparkSession.read \
        .format("jdbc") \
        .option("url", MSSQL_JDBC) \
        .option("dbtable", MSSQL_REF_TABLE) \
        .option("user", MSSQL_USER) \
        .option("password", MSSQL_PASSWORD) \
        .option("driver", MSSQL_DRIVER) \
        .load()

    joined = batch_df.join(ref_df, on="base_station_id", how="inner")

    output_cols = ["IMSI", "IMEI", "phone_number", "base_station_id", "event_time", "call_duration"]
    valid = joined.select([c for c in output_cols if c in joined.columns])

    # 2. Sink в MSSQL
    valid.write \
        .format("jdbc") \
        .option("url", MSSQL_JDBC) \
        .option("dbtable", MSSQL_SINK_TABLE) \
        .option("user", MSSQL_USER) \
        .option("password", MSSQL_PASSWORD) \
        .option("driver", MSSQL_DRIVER) \
        .mode("append") \
        .save()

    # 3. Sink в Kafka (JSON)
    df_kafka = valid.select(
        to_json(struct(*valid.columns)).alias("value")
    )
    df_kafka.write \
        .format("kafka") \
        .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP) \
        .option("topic", KAFKA_TOPIC_SINK) \
        .save()


def main():
    spark = SparkSession.builder \
        .appName("GSM-Dual-Sink") \
        .getOrCreate()

    df_raw = spark.readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP) \
        .option("subscribe", "GSM") \
        .option("startingOffsets", "latest") \
        .load()

    df_gsm = df_raw.select(
        from_json(col("value").cast("string"), GSM_SCHEMA).alias("data")
    ).select("data.*")

    query = df_gsm.writeStream \
        .foreachBatch(write_mssql_and_kafka) \
        .outputMode("append") \
        .option("checkpointLocation", CHECKPOINT) \
        .trigger(processingTime="30 seconds") \
        .start()

    query.awaitTermination()


if __name__ == "__main__":
    main()
