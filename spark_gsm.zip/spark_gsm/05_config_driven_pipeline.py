"""
Скрипт 5: Конфигурационно-управляемый pipeline.

Все параметры берутся из config.py. Режим: streaming или batch — через аргумент.

Запуск:
  spark-submit ... 05_config_driven_pipeline.py --mode streaming
  spark-submit ... 05_config_driven_pipeline.py --mode batch
"""
import argparse
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json, struct, to_json, broadcast
from pyspark.sql.types import StructType, StructField, StringType, LongType, TimestampType

try:
    from config import (
        KAFKA_BOOTSTRAP_SERVERS,
        KAFKA_TOPIC_SOURCE,
        KAFKA_TOPIC_SINK,
        MSSQL_JDBC_URL,
        MSSQL_REFERENCE_TABLE,
        MSSQL_SINK_TABLE,
        MSSQL_USER,
        MSSQL_PASSWORD,
        MSSQL_DRIVER,
        JOIN_COLUMNS,
        OUTPUT_COLUMNS,
        CHECKPOINT_LOCATION,
        TRIGGER_INTERVAL,
    )
except ImportError:
    # Fallback если config не рядом
    KAFKA_BOOTSTRAP_SERVERS = "localhost:9092"
    KAFKA_TOPIC_SOURCE = "GSM"
    KAFKA_TOPIC_SINK = "GSM_VALIDATED"
    MSSQL_JDBC_URL = "jdbc:sqlserver://localhost:1433;databaseName=YourDB"
    MSSQL_REFERENCE_TABLE = "dbo.BaseStations"
    MSSQL_SINK_TABLE = "dbo.ValidatedRecords"
    MSSQL_USER = "sa"
    MSSQL_PASSWORD = "YourPassword"
    MSSQL_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
    JOIN_COLUMNS = ["base_station_id"]
    OUTPUT_COLUMNS = ["IMSI", "IMEI", "phone_number", "base_station_id", "event_time", "call_duration"]
    CHECKPOINT_LOCATION = "/tmp/spark_checkpoint/gsm"
    TRIGGER_INTERVAL = "30 seconds"

GSM_SCHEMA = StructType([
    StructField("IMSI", StringType(), True),
    StructField("IMEI", StringType(), True),
    StructField("phone_number", StringType(), True),
    StructField("base_station_id", StringType(), True),
    StructField("lac", StringType(), True),
    StructField("cell_id", StringType(), True),
    StructField("event_time", TimestampType(), True),
    StructField("call_duration", LongType(), True),
    StructField("billing_info", StringType(), True),
])


def load_mssql_reference(spark):
    return spark.read \
        .format("jdbc") \
        .option("url", MSSQL_JDBC_URL) \
        .option("dbtable", MSSQL_REFERENCE_TABLE) \
        .option("user", MSSQL_USER) \
        .option("password", MSSQL_PASSWORD) \
        .option("driver", MSSQL_DRIVER) \
        .load()


def process_and_validate(df_gsm, ref_df, use_broadcast=True):
    ref = broadcast(ref_df) if use_broadcast else ref_df
    joined = df_gsm.join(ref, on=JOIN_COLUMNS, how="inner")
    cols = [c for c in OUTPUT_COLUMNS if c in joined.columns]
    return joined.select(cols)


def write_mssql(df):
    df.write \
        .format("jdbc") \
        .option("url", MSSQL_JDBC_URL) \
        .option("dbtable", MSSQL_SINK_TABLE) \
        .option("user", MSSQL_USER) \
        .option("password", MSSQL_PASSWORD) \
        .option("driver", MSSQL_DRIVER) \
        .mode("append") \
        .save()


def write_kafka(df):
    df.select(to_json(struct(*df.columns)).alias("value")) \
        .write \
        .format("kafka") \
        .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP_SERVERS) \
        .option("topic", KAFKA_TOPIC_SINK) \
        .save()


def run_streaming(spark):
    ref_df = load_mssql_reference(spark)

    df_raw = spark.readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP_SERVERS) \
        .option("subscribe", KAFKA_TOPIC_SOURCE) \
        .option("startingOffsets", "latest") \
        .load()

    df_gsm = df_raw.select(
        from_json(col("value").cast("string"), GSM_SCHEMA).alias("data")
    ).select("data.*")

    validated = process_and_validate(df_gsm, ref_df)

    def foreach_batch(batch_df, batch_id):
        if batch_df.isEmpty():
            return
        write_mssql(batch_df)
        write_kafka(batch_df)

    validated.writeStream \
        .foreachBatch(foreach_batch) \
        .outputMode("append") \
        .option("checkpointLocation", CHECKPOINT_LOCATION) \
        .trigger(processingTime=TRIGGER_INTERVAL) \
        .start() \
        .awaitTermination()


def run_batch(spark):
    ref_df = load_mssql_reference(spark)

    df_raw = spark.read \
        .format("kafka") \
        .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP_SERVERS) \
        .option("subscribe", KAFKA_TOPIC_SOURCE) \
        .option("startingOffsets", "earliest") \
        .option("endingOffsets", "latest") \
        .load()

    df_gsm = df_raw.select(
        from_json(col("value").cast("string"), GSM_SCHEMA).alias("data")
    ).select("data.*")

    validated = process_and_validate(df_gsm, ref_df)
    count = validated.count()
    print(f"Validated: {count}")

    if count > 0:
        write_mssql(validated)
        write_kafka(validated)
        print("Written to MSSQL and Kafka.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["streaming", "batch"], default="streaming")
    args = parser.parse_args()

    spark = SparkSession.builder \
        .appName("GSM-Config-Driven") \
        .getOrCreate()

    if args.mode == "streaming":
        run_streaming(spark)
    else:
        run_batch(spark)


if __name__ == "__main__":
    main()
