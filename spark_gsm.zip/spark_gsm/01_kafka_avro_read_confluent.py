"""
Скрипт 1b: Шаблон чтения Avro из Kafka через Confluent Schema Registry.

Требует: pip install confluent-kafka confluent-schema-registry-client
Запуск:
  spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.4.0 \\
    01_kafka_avro_read_confluent.py

Примечание: UDF с Confluent Avro работает на драйвере; для production
предпочтительнее Spark Avro с from_avro (Databricks) или Kafka Connect.
"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from pyspark.sql.types import StringType

try:
    from confluent_kafka.schema_registry import SchemaRegistryClient
    from confluent_kafka.schema_registry.avro import AvroDeserializer
    import fastavro
    CONFLUENT_AVAILABLE = True
except ImportError:
    CONFLUENT_AVAILABLE = False

SCHEMA_REGISTRY_URL = "http://localhost:8081"
SUBJECT = "GSM-value"


def get_deserializer():
    if not CONFLUENT_AVAILABLE:
        raise ImportError("pip install confluent-kafka confluent-schema-registry-client fastavro")
    client = SchemaRegistryClient({"url": SCHEMA_REGISTRY_URL})
    schema = client.get_latest_version(SUBJECT).schema
    return AvroDeserializer(SCHEMA_REGISTRY_URL, schema.schema_str)


def main():
    spark = SparkSession.builder \
        .appName("GSM-Kafka-Avro-Confluent") \
        .getOrCreate()

    deserializer = get_deserializer()

    def _deserialize(raw):
        if raw is None or len(raw) < 5:
            return None
        try:
            obj = deserializer(raw, None)
            return str(obj) if obj else None
        except Exception:
            return None

    from pyspark.sql.functions import udf
    deserialize_udf = udf(_deserialize, StringType())

    df = spark.readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", "localhost:9092") \
        .option("subscribe", "GSM") \
        .option("startingOffsets", "latest") \
        .load()

    df_decoded = df.select(
        col("key"),
        col("topic"),
        col("partition"),
        col("offset"),
        deserialize_udf(col("value")).alias("avro_decoded")
    )

    df_decoded.writeStream \
        .outputMode("append") \
        .format("console") \
        .start() \
        .awaitTermination()


if __name__ == "__main__":
    main()
