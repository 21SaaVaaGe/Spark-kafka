"""
Конфигурация для GSM Kafka → MSSQL pipeline.
"""

# Kafka
KAFKA_BOOTSTRAP_SERVERS = "localhost:9092"
KAFKA_TOPIC_SOURCE = "GSM"
KAFKA_TOPIC_SINK = "GSM_VALIDATED"
SCHEMA_REGISTRY_URL = "http://localhost:8081"

# MSSQL (JDBC)
MSSQL_JDBC_URL = "jdbc:sqlserver://localhost:1433;databaseName=YourDB"
MSSQL_REFERENCE_TABLE = "dbo.BaseStations"  # справочник для join
MSSQL_SINK_TABLE = "dbo.ValidatedRecords"
MSSQL_USER = "sa"
MSSQL_PASSWORD = "YourPassword"
MSSQL_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver"

# Join / фильтр
JOIN_COLUMNS = ["base_station_id", "lac", "cell_id"]  # поля для join
OUTPUT_COLUMNS = [
    "IMSI", "IMEI", "phone_number", "base_station_id",
    "event_time", "call_duration", "billing_info"
]

# Streaming
CHECKPOINT_LOCATION = "/tmp/spark_checkpoint/gsm_pipeline"
TRIGGER_INTERVAL = "30 seconds"
BATCH_TIMEOUT = "60 seconds"
