#!/usr/bin/env python3
import os, sys, json, argparse, uuid
import requests

def auth_headers():
    t = os.getenv("NIFI_TOKEN")
    if t:
        return {"Authorization": f"Bearer {t}"}
    return {}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--description", default="")
    ap.add_argument("--param", action="append", default=[], help="key=value (non-sensitive)")
    ap.add_argument("--sensitive", action="append", default=[], help="key=value (sensitive)")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    nifi_url = os.getenv("NIFI_URL", "http://localhost:8080/nifi-api")
    rev = {"clientId": str(uuid.uuid4()), "version": 0}

    params = []
    for kv in args.param:
        k, v = kv.split("=", 1)
        params.append({"parameter": {"name": k, "value": v, "sensitive": False}})
    for kv in args.sensitive:
        k, v = kv.split("=", 1)
        params.append({"parameter": {"name": k, "value": v, "sensitive": True}})

    payload = {
        "revision": rev,
        "disconnectedNodeAcknowledged": False,
        "component": {
            "name": args.name,
            "description": args.description,
            "parameters": params
        }
    }

    if args.dry_run:
        print(json.dumps(payload, indent=2))
        return

    r = requests.post(f"{nifi_url}/parameter-contexts", headers=auth_headers(), json=payload, timeout=30)
    try:
        r.raise_for_status()
    except Exception as e:
        print("[ERROR]", r.status_code, r.text)
        raise
    data = r.json()
    pc_id = data["id"]
    print(f"[OK] Created Parameter Context '{args.name}' id={pc_id}")

if __name__ == "__main__":
    main()