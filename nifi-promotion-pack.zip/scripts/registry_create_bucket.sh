#!/usr/bin/env bash
set -euo pipefail
: "${REGISTRY_URL:?}"
NAME="${1:-golden}"
BODY=$(jq -n --arg name "$NAME" '{name:$name}')
curl -sS -X POST "$REGISTRY_URL/buckets" -H 'Content-Type: application/json' -d "$BODY"
echo