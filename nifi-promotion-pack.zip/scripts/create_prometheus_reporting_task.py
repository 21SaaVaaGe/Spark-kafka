#!/usr/bin/env python3
import os, sys, json, argparse, uuid
import requests

def auth_headers():
    t = os.getenv("NIFI_TOKEN")
    if t:
        return {"Authorization": f"Bearer {t}"}
    return {}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", default="PrometheusReportingTask")
    ap.add_argument("--metrics-endpoint", dest="metrics_endpoint", default="/metrics")
    ap.add_argument("--metrics-host", dest="metrics_host", default="0.0.0.0")
    ap.add_argument("--metrics-port", dest="metrics_port", type=int, default=9092)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    nifi_url = os.getenv("NIFI_URL", "http://localhost:8080/nifi-api")
    rev = {"clientId": str(uuid.uuid4()), "version": 0}

    comp_type = "org.apache.nifi.reporting.prometheus.PrometheusReportingTask"

    # Properties keys are version-dependent; these commonly map in recent versions
    properties = {
        "metricsEndpoint": args.metrics_endpoint,
        "metricsHost": args.metrics_host,
        "metricsPort": str(args.metrics_port),
        "sendJvmMetrics": "true",
        "sendBulletins": "true"
    }

    payload = {
        "revision": rev,
        "disconnectedNodeAcknowledged": False,
        "component": {
            "name": args.name,
            "type": comp_type,
            "state": "STOPPED",
            "properties": properties
        }
    }

    if args.dry_run:
        print(json.dumps(payload, indent=2))
        return

    r = requests.post(f"{nifi_url}/controller/reporting-tasks", headers=auth_headers(), json=payload, timeout=30)
    try:
        r.raise_for_status()
    except Exception as e:
        print("[ERROR creating]", r.status_code, r.text)
        raise
    task = r.json()
    task_id = task["id"]
    print(f"[OK] Created ReportingTask id={task_id}")

    rs = {
        "revision": task["revision"],
        "state": "RUNNING"
    }
    r2 = requests.put(f"{nifi_url}/reporting-tasks/{task_id}/run-status", headers=auth_headers(), json=rs, timeout=30)
    if r2.status_code // 100 == 2:
        print(f"[OK] Started ReportingTask {task_id}")
    else:
        print("[WARN] Could not start task automatically. Start it in UI or check properties.")
        print(r2.status_code, r2.text)

if __name__ == "__main__":
    main()