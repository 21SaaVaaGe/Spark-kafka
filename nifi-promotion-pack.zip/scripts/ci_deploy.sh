#!/usr/bin/env bash
# Usage: ci_deploy.sh <BUCKET_ID> <FLOW_ID> <PG_ID> <VERSION>
set -euo pipefail
: "${NIFI_CLI_BIN:?}"; : "${NIFI_URL:?}"
BUCKET_ID="${1:?}"
FLOW_ID="${2:?}"
PG_ID="${3:?}"
VERSION="${4:?}"

${NIFI_CLI_BIN} session set nifi.url "${NIFI_URL}"
echo "[INFO] Updating PG ${PG_ID} to registry flow ${FLOW_ID}@${VERSION}"
${NIFI_CLI_BIN} nifi pg-change-version   --pgid "${PG_ID}"   --bucketId "${BUCKET_ID}"   --flowId "${FLOW_ID}"   --version "${VERSION}"   --clientId "ci-deploy-$(date +%s)"
echo "[OK] Version updated."