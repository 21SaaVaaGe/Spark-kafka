#!/usr/bin/env bash
set -euo pipefail
: "${NIFI_URL:?NIFI_URL not set}"
: "${NIFI_CLI_BIN:?NIFI_CLI_BIN not set}"
${NIFI_CLI_BIN} session set nifi.url "${NIFI_URL}"
echo "[OK] NiFi CLI session set to ${NIFI_URL}"