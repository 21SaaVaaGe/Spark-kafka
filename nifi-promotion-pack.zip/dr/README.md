# DR и Site-to-Site (набросок)
- Для актив-пассив: резервная копия flow.json.gz, версионирование в Registry, регулярный бэкап репозиториев.
- Site-to-Site: создайте Remote Process Group (RPG) через REST:
  POST /nifi-api/process-groups/{pgId}/remote-process-groups
  body: {{'component': {{'targetUris': 'https://nifi-dr:8080/nifi'}}}}
- Настройте порт передачи (Input/Output Ports) и права.