#!/usr/bin/env python3
import argparse, os, sys, json

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--template", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--param", action="append", default=[])
    args = ap.parse_args()

    with open(args.template, "r", encoding="utf-8") as f:
        content = f.read()

    # simple token replacement: {{param_name}}
    kv = {}
    for p in args.param:
        if "=" not in p:
            print(f"Skip invalid --param '{p}', expected key=value", file=sys.stderr)
            continue
        k, v = p.split("=", 1)
        kv[k] = v

    for k, v in kv.items():
        content = content.replace("{{" + k + "}}", v)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[OK] Wrote {args.out}")

if __name__ == "__main__":
    main()