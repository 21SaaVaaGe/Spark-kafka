# Безопасность (набросок)
- Сгенерируйте PKI: `tls-toolkit.sh standalone -n nifi -o ./certs`
- Включите HTTPS в `nifi.properties`, укажите keystore/truststore
- Создайте пользователя/группы и политики доступа через UI/REST:
  - /nifi-api/tenants/users, /tenants/user-groups, /policies
- Не храните секреты в параметрах в открытом виде — используйте "sensitive" и/или Vault через контроллер-сервисы/обменник секретов.