# NiFi Platform Upgrade Pack — практический набор
Дата: 2025-09-23

Этот пакет помогает **программно** внедрить:
- GitOps/CI-CD для NiFi (NiFi Registry + NiFi Toolkit CLI + REST API)
- Стандарты продакшн-потоков (Parameter Contexts, DLQ-паттерн)
- Наблюдаемость и SLO (PrometheusReportingTask → Prometheus → Grafana)
- Безопасность (mTLS/секреты — набросок) и DR/Site-to-Site — шаблоны
- Самообслуживание (простая генерация потоков из шаблона)

> Важно: версии и эндпоинты могут отличаться у вас (NiFi 1.16+ / 1.21+ / 2.x). Скрипты даны как **рабочие примеры**, адаптируйте под свою версию и политику безопасности.

---

## Быстрый старт

### 0) Предпосылки
- Запущенный Apache NiFi (пример: `http://localhost:8080/nifi`), доступ к API (`/nifi-api`)
- NiFi Toolkit (cli.sh) доступен локально
- (Рекомендуется) NiFi Registry (пример: `http://localhost:18080`)
- Python 3.9+, bash, curl
- Доступы/токены для защищённого API (если mTLS/SAML/OIDC включены)

Скопируйте `.env`-файл, настройте переменные, проверьте соединение:
```bash
cp scripts/nifi_env.example .env
source .env
scripts/init_cli_session.sh
```

### 1) Создать Parameter Context программно
```bash
python3 scripts/create_parameter_context.py   --name PROD_DEFAULTS   --param bootstrap.servers=broker1:9092   --param dlq.topic=topic.dlq   --sensitive db.password=SuperSecret123
```

### 2) Включить PrometheusReportingTask и метрики
```bash
python3 scripts/create_prometheus_reporting_task.py   --name PrometheusRT   --metrics-endpoint /metrics   --metrics-host 0.0.0.0   --metrics-port 9092
```
Добавьте `configs/prometheus/prometheus.yml` в свою Prometheus-конфигурацию. Импортируйте `configs/grafana/dashboard.json` в Grafana.

### 3) GitOps/CI: выкатываем новую версию потока
1. Храните версии потоков в Registry (bucket/flow).
2. Запустите:
```bash
# пример обновления версии PG до v{VERSION}
scripts/ci_deploy.sh "$BUCKET_ID" "$FLOW_ID" "$PG_ID" "$VERSION"
```
Скрипт использует NiFi CLI для смены версии PG.

### 4) DLQ-паттерн и стандарты
В `templates/` лежат примеры схем и Jolt. Принцип:
- **ValidateRecord** → валидируйте по Avro-схеме (`schemas/order.avsc`)
- Ошибочные записи → **RouteOnAttribute** → **PublishKafka/PutFile** в DLQ
- **UpdateRecord** → нормализация полей по `templates/update-record-policies.json`

### 5) Самообслуживание (демо)
Скрипт `self-service/generate_flow_from_template.py` соберёт заготовку потока (Stateless YAML) из шаблона + параметров:
```bash
python3 self-service/generate_flow_from_template.py   --template templates/stateless_ingest_validate.yaml   --out build/flows/order_ingest.yaml   --param source_path=/data/inbox   --param schema_path=schemas/order.avsc
```

### 6) Безопасность и DR
- Смотрите `security/README.md` и `dr/README.md` — там стартовые команды и ссылки на API/подходы.
- Для mTLS используйте `tls-toolkit` из NiFi Toolkit (Keystore/Truststore, user certs).

---

## Структура
```
scripts/        # автоматизация (CLI/REST), CI/CD
configs/        # prometheus/grafana
schemas/        # Avro-схемы
templates/      # Jolt/UpdateRecord/Stateless YAML
self-service/   # генерация потоков
security/       # mTLS/права — наброски
dr/             # Site-to-Site/backup — наброски
```

## Принципы SLO и метрик
- Throughput, latency (P50/P95), queue depth, error rate
- Дашборд включает ключевые панели: задержка, пропускная, DLQ

## Ограничения
- API разных версий NiFi отличаются. Проверяйте `/nifi-api` swagger у своей версии.
- Если у вас полностью закрыт доступ к API — согласуйте сервисные аккаунты/токены.