"""Local control-flow tests. No JVM/network; these do not replace Spark integration tests."""
import ast
import os
from pathlib import Path
import types
import unittest
from unittest.mock import MagicMock, patch


def load_pipeline():
    tree = ast.parse(Path(__file__).with_name('prod_refactored.py').read_text(encoding='utf-8'))
    tree.body = [node for node in tree.body if not (
        isinstance(node, ast.ImportFrom) and node.module.startswith('pyspark'))]
    ns = dict(__name__='pipeline_test', DataFrame=object, SparkSession=MagicMock(),
              StorageLevel=types.SimpleNamespace(DISK_ONLY='DISK_ONLY'), F=MagicMock(),
              from_avro=MagicMock())
    with patch.dict(os.environ, {}, clear=True):
        exec(compile(tree, 'prod_refactored.py', 'exec'), ns)
    ns['LOGGER'] = MagicMock()
    return ns


class SafetyTests(unittest.TestCase):
    def setUp(self):
        self.ns = load_pipeline()

    def batch(self, rows=10, invalid_count=0):
        batch = MagicMock()
        batch.persist.return_value = batch
        batch.count.return_value = rows
        invalid = MagicMock()
        invalid.count.return_value = invalid_count
        valid = MagicMock()
        business = valid.select.return_value.dropDuplicates.return_value.persist.return_value
        business.count.return_value = rows - invalid_count
        batch.where.side_effect = [invalid, valid]
        self.ns['process_outputs'] = MagicMock()
        return batch, business, invalid

    def test_jdbc_failure_propagates_and_has_no_local_retry(self):
        df = MagicMock()
        writer = df.repartition.return_value.write
        writer.format.return_value = writer
        writer.option.return_value = writer
        writer.mode.return_value = writer
        writer.save.side_effect = RuntimeError('connection lost')
        with self.assertRaisesRegex(RuntimeError, 'connection lost'):
            self.ns['write_mssql'](df, 'jdbc:test', 'dbo.target')
        writer.save.assert_called_once()
        df.repartition.assert_called_once_with(4)
        self.assertIn(unittest.mock.call('batchsize', 500), writer.option.call_args_list)
        self.assertIn(unittest.mock.call('numPartitions', 4), writer.option.call_args_list)

    def test_empty_batch_releases_cache_without_writing(self):
        batch, _, _ = self.batch(rows=0)
        self.ns['global_process_batch'](batch, 1)
        batch.unpersist.assert_called_with(blocking=True)
        self.ns['process_outputs'].assert_not_called()

    def test_bad_record_fails_before_any_database_write(self):
        batch, _, _ = self.batch(invalid_count=1)
        with self.assertRaisesRegex(RuntimeError, 'invalid messages'):
            self.ns['global_process_batch'](batch, 2)
        self.ns['process_outputs'].assert_not_called()
        batch.unpersist.assert_called_with(blocking=True)

    def test_sink_failure_releases_both_caches_and_propagates(self):
        batch, business, _ = self.batch()
        self.ns['process_outputs'].side_effect = RuntimeError('sink failed')
        with self.assertRaisesRegex(RuntimeError, 'sink failed'):
            self.ns['global_process_batch'](batch, 3)
        batch.unpersist.assert_called_with(blocking=True)
        business.unpersist.assert_called_once_with(blocking=True)

    def test_success_writes_materialized_business_batch(self):
        batch, business, _ = self.batch()
        self.ns['global_process_batch'](batch, 4)
        business.count.assert_called_once()
        self.ns['process_outputs'].assert_called_once_with(business, 4)
        business.unpersist.assert_called_once_with(blocking=True)

    def test_dlq_failure_prevents_database_writes(self):
        self.ns['PARSE_ERROR_MODE'] = 'dlq'
        batch, _, invalid = self.batch(invalid_count=1)
        writer = invalid.select.return_value.write
        writer.format.return_value = writer
        writer.option.return_value = writer
        writer.save.side_effect = RuntimeError('dlq unavailable')
        with self.assertRaisesRegex(RuntimeError, 'dlq unavailable'):
            self.ns['global_process_batch'](batch, 5)
        self.ns['process_outputs'].assert_not_called()
        batch.unpersist.assert_called_with(blocking=True)

    def test_shared_join_caches_released_on_failure(self):
        ns = load_pipeline()
        ns['kafka_IDENTS_msisdn'] = MagicMock()
        first, second = MagicMock(), MagicMock()
        first.persist.return_value = first
        second.persist.return_value = second
        batch = MagicMock()
        batch.join.side_effect = [first, second]
        ns['process_outputs_with_joins'] = MagicMock(side_effect=RuntimeError('sink'))
        with self.assertRaisesRegex(RuntimeError, 'sink'):
            ns['process_outputs'](batch, 6)
        first.unpersist.assert_called_once_with(blocking=True)
        second.unpersist.assert_called_once_with(blocking=True)

    def test_external_schema_requires_explicit_wire_id(self):
        self.ns['READER_SCHEMA_STR'] = '{"type":"record","name":"x","fields":[]}'
        with self.assertRaisesRegex(ValueError, 'EXPECTED_SCHEMA_ID'):
            self.ns['resolve_reader_schema']()
        self.ns['EXPECTED_SCHEMA_ID'] = '42'
        _, schema_id = self.ns['resolve_reader_schema']()
        self.assertEqual(schema_id, 42)

    def test_invalid_limits_rejected(self):
        with patch.dict(os.environ, {'MAX_OFFSETS_PER_TRIGGER': '0'}):
            with self.assertRaises(ValueError):
                self.ns['positive_int']('MAX_OFFSETS_PER_TRIGGER', 10000)

    def test_missing_checkpoint_fails_before_spark_starts(self):
        self.ns['create_spark'] = MagicMock()
        with self.assertRaisesRegex(ValueError, 'CHECKPOINT_LOCATION'):
            self.ns['main']()
        self.ns['create_spark'].assert_not_called()


if __name__ == '__main__':
    unittest.main(verbosity=2)
