#!/usr/bin/env bash
# Linux Spark Standalone deployment; edit paths/environment for your cluster.
set -euo pipefail
# Python 3.10 must be available on the driver and every executor host.
# Override with the absolute path to your Python 3.10 virtual environment if needed.
export PYSPARK_PYTHON="${PYSPARK_PYTHON:-python3.10}"
export PYSPARK_DRIVER_PYTHON="${PYSPARK_DRIVER_PYTHON:-$PYSPARK_PYTHON}"
: "${CHECKPOINT_LOCATION:?Set a dedicated durable checkpoint root, e.g. hdfs:///apps/billing-v2}"
: "${MSSQL_PASSWORD:?Provide MSSQL_PASSWORD through your secret mechanism}"
: "${MSSQL_JDBC_JAR:?Set the installed Microsoft JDBC jar path}"
# Require a conscious first-start decision: JSON offsets, earliest, or latest.
: "${STARTING_OFFSETS:?Set explicitly; latest skips existing backlog on a NEW checkpoint}"
: "${SCHEMA_VERSION:?Pin the exact schema version from Registry for reproducible restarts}"
export CHECKPOINT_LOCATION MSSQL_PASSWORD STARTING_OFFSETS SCHEMA_VERSION
export MAX_OFFSETS_PER_TRIGGER="${MAX_OFFSETS_PER_TRIGGER:-10000}"
export MAX_RECORDS_PER_PARTITION="${MAX_RECORDS_PER_PARTITION:-2500}"
export SHUFFLE_PARTITIONS="${SHUFFLE_PARTITIONS:-128}"
export JDBC_WRITE_PARTITIONS="${JDBC_WRITE_PARTITIONS:-4}"
export JDBC_BATCH_SIZE="${JDBC_BATCH_SIZE:-500}"
export TRIGGER_INTERVAL="${TRIGGER_INTERVAL:-10 seconds}"
export PARSE_ERROR_MODE="${PARSE_ERROR_MODE:-fail}"

# At most 48 executor cores, 4 cores / executor, nominally 12 executors * 32 GiB.
# Standalone placement depends on worker capacities. Leave room for OS/native I/O.
# Client mode: run under systemd/supervisor; driver memory must be set at launch.
exec spark-submit \
  --master "${SPARK_MASTER:-spark://192.168.17.14:7077}" \
  --deploy-mode client \
  --driver-memory 8g \
  --executor-memory 32g \
  --executor-cores 4 \
  --total-executor-cores 48 \
  --conf spark.dynamicAllocation.enabled=false \
  --conf "spark.pyspark.python=$PYSPARK_PYTHON" \
  --conf "spark.pyspark.driver.python=$PYSPARK_DRIVER_PYTHON" \
  --conf spark.speculation=false \
  --conf spark.driver.maxResultSize=256m \
  --conf spark.network.timeout=180s \
  --conf spark.executor.heartbeatInterval=20s \
  --packages org.apache.spark:spark-sql-kafka-0-10_2.13:4.0.1,org.apache.spark:spark-avro_2.13:4.0.1 \
  --jars "$MSSQL_JDBC_JAR" \
  "$(dirname "$0")/prod_refactored.py"
