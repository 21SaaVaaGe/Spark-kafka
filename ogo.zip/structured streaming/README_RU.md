# Kafka → PySpark 4.0.1 → MSSQL

Актуальная расширенная версия совместима с Python 3.10.

- `prod_refactored.py` — приложение; по умолчанию используется staged-запись.
- `run_billing.sh` — стартовый профиль для 64 ядер / 1 ТБ RAM.
- `DEPLOYMENT_RU.md` — обязательная инструкция по SQL, checkpoint, лимитам и гарантиям.
- `staging_sql.py` и `sql/` — генератор и восемь скриптов staging/commit procedures.
- `snapshot_lookups.py` — экспорт неизменяемых Parquet-версий справочников.
- `test_pipeline_safety.py`, `test_staging_sql.py` — локальные unit tests.
- `test_spark_integration.py` — тесты реальных Spark plans на тестовом Spark-хосте.
- `tests/sql/test_protocol.sql` — сценарии восстановления для отдельной тестовой SQL БД.

Перед запуском прочитайте [DEPLOYMENT_RU.md](DEPLOYMENT_RU.md). Новая версия требует
развёрнутых SQL-объектов и постоянного PIPELINE_ID. Рабочие базы не изменялись.
Идемпотентность относится к каждому SQL-приёмнику, общей транзакции между серверами нет.
Пиковый heap и пропускную способность нужно проверить на ваших данных.
