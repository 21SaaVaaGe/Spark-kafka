"""Generate reviewable SQL Server staging DDL; never connects to a database.

Python 3.10+, SQL Server 2016 SP1+ (CREATE OR ALTER PROCEDURE).
Uses existing target column definitions via SELECT INTO; no guessed SQL types.
"""
import argparse
import json
import os
from pathlib import Path
import re


def ident(value):
    if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,100}', value):
        raise ValueError(f'Unsafe SQL identifier: {value!r}')
    return '[' + value + ']'


def table_name(value):
    parts = value.replace('[', '').replace(']', '').split('.')
    if len(parts) != 2:
        raise ValueError('Target must be a two-part schema.table name in the connection database')
    return '.'.join(ident(part) for part in parts)


def literal(value):
    return "N'" + value.replace("'", "''") + "'"


BASE = ['DATE_TIME', 'DURATION', 'CALL_TYPE', 'TEL_FROM', 'IMSI_FROM', 'IMEI_FROM', 'TEL_TO']
TAIL = ['CODE_FROM', 'MCC_FROM', 'MNC_FROM', 'LAC_FROM', 'CELLID_FROM',
        'CODE_TO', 'MCC_TO', 'MNC_TO', 'LAC_TO', 'CELLID_TO',
        'SERVICE_CENTER_FROM', 'SERVICE_CENTER_TO']
OSS = BASE + ['ID_TO', 'MSRN', 'IMSI_TO', 'IMEI_TO'] + TAIL + ['ID_ident', 'DIRECTION', 'GP']
IDENTS = BASE + ['MSRN', 'IMSI_TO', 'IMEI_TO'] + TAIL + ['UID', 'THEME']
ALARM = BASE[:6] + ['ID_FROM', 'TEL_TO', 'MSRN', 'IMSI_TO', 'IMEI_TO', 'ID_TO'] + TAIL + ['MSG', 'UID', 'THEME']


def default_manifest():
    specs = [
        ('oss', 'MSSQL_JDBC_URL_TARGET', 'MSSQL_TARGET_TABLE', 'dbo.OSS_KAFKA', OSS),
        ('idents', 'MSSQL_JDBC_URL_IDENTS_TARGET', 'MSSQL_TARGET_IDENTS_TABLE', 'IDENTS.OSS', IDENTS),
        ('alarm', 'MSSQL_JDBC_HEAD', 'MSSQL_DATA_ALARM_KAFKA', 'ALARM.DATA_ALARM_KAFKA', ALARM),
        ('gnezdo', 'MSSQL_JDBC_URL_IDENTS_TARGET', 'MSSQL_TARGET_TABLE_ROL_GNEZDO', '[ROL].[GNEZDO]',
         ['DATE_TIME', 'MSISDN', 'IDident', 'GP', 'CODE', 'LAC', 'CELLID', 'HASHTAG']),
        ('ruchey', 'MSSQL_JDBC_URL_IDENTS_TARGET', 'MSSQL_TARGET_TABLE_VALDAY', '[TEST].[VALDAY]',
         ['ID', 'IMSI', 'IMEI', 'TYPE', 'REMARK', 'DATE_TIME']),
        ('bs_test', 'MSSQL_JDBC_URL_IDENTS_TARGET', 'MSSQL_TARGET_TABLE_TEST', '[TEST].[BS_TEST]',
         ['ID', 'IMSI', 'IMEI', 'TYPE', 'REMARK', 'DATE_TIME', 'CODE', 'LAC', 'CELLID']),
        ('road', 'MSSQL_JDBC_URL_IDENTS_TARGET', 'MSSQL_TARGET_TABLE_ROAD', '[TEST].[ROAD]',
         ['ID', 'IMSI', 'IMEI', 'REMARK', 'MIN_DATE_TIME', 'MAX_DATE_TIME', 'COUNT']),
        ('pulkovo', 'MSSQL_JDBC_URL_IDENTS_TARGET', 'MSSQL_TARGET_TABLE_PULKOVO_POLYGON', '[ROL].[PULKOVO_POLYGON]',
         ['DAY_OF_MONTH', 'DATE_TIME', 'MSISDN', 'IMSI', 'IMEI', 'HASHTAG']),
    ]
    return [dict(sink_key=key, connection=connection, target=os.getenv(env, default), columns=columns)
            for key, connection, env, default, columns in specs]


def generate(spec, schema='streaming'):
    ns = ident(schema)
    key = spec['sink_key']
    ident(key)
    if len(key) > 64:
        raise ValueError('sink_key must fit varchar(64) ledger column')
    target = table_name(spec['target'])
    columns = spec['columns']
    if not columns or len(set(c.lower() for c in columns)) != len(columns):
        raise ValueError('Column names must be nonempty and unique')
    if any(c.startswith('_ss_') for c in columns):
        raise ValueError('Reserved staging metadata column prefix')
    cols = ', '.join(ident(c) for c in columns)
    source_cols = ', '.join('t.' + ident(c) for c in columns)
    stage = ns + '.' + ident('stage_' + key)
    proc = ns + '.' + ident('commit_' + key)
    columns_json = json.dumps(columns, separators=(',', ':'))
    # Deployment fails rather than silently changing a sink's identity/contract.
    checks = '\n'.join(
        f"IF COL_LENGTH({literal(target)}, {literal(c)}) IS NULL\n"
        f"    THROW 51000, 'Missing target column: {c}', 1;" for c in columns)
    identity_checks = ', '.join(literal(c) for c in columns)
    return f"""-- Sink {key}; deploy in the database selected by {spec['connection']}.
-- Review target, indexes, transaction-log capacity and permissions before running.
-- Generated offline. This script does not alter the existing business table.
SET NOCOUNT ON;
SET XACT_ABORT ON;
IF SCHEMA_ID({literal(schema)}) IS NULL EXEC('CREATE SCHEMA {ns}');
GO
IF OBJECT_ID('{ns}.[commits]', 'U') IS NULL
    CREATE TABLE {ns}.[commits] (
        pipeline_id nvarchar(128) COLLATE Latin1_General_100_BIN2 NOT NULL,
        sink_key varchar(64) COLLATE Latin1_General_100_BIN2 NOT NULL,
        batch_id bigint NOT NULL,
        row_count bigint NOT NULL,
        committed_at datetime2(7) NOT NULL DEFAULT SYSUTCDATETIME(),
        PRIMARY KEY (pipeline_id, sink_key, batch_id)
    );
IF OBJECT_ID('{ns}.[sinks]', 'U') IS NULL
    CREATE TABLE {ns}.[sinks] (
        sink_key varchar(64) COLLATE Latin1_General_100_BIN2 NOT NULL PRIMARY KEY,
        target_table nvarchar(260) NOT NULL,
        column_names nvarchar(max) NOT NULL
    );
IF OBJECT_ID({literal(target)}, 'U') IS NULL
    THROW 51000, 'Target must be an existing user table in this database', 1;
{checks}
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID({literal(target)})
           AND name IN ({identity_checks})
           AND (is_identity=1 OR is_computed=1 OR system_type_id=189))
    THROW 51000, 'Output may not target identity, computed or rowversion columns', 1;
IF EXISTS (SELECT 1 FROM {ns}.[sinks] WHERE sink_key='{key}'
           AND (target_table<>{literal(target)} OR column_names<>{literal(columns_json)}))
    THROW 51000, 'Sink contract already differs: use a reviewed schema migration', 1;
IF OBJECT_ID('{stage}', 'U') IS NULL
BEGIN
    -- Join prevents accidental inheritance of an identity attribute.
    SELECT TOP (0) {source_cols}
    INTO {stage} FROM {target} AS t CROSS JOIN (SELECT 1 AS n) AS seed;
    ALTER TABLE {stage} ADD
        _ss_pipeline_id nvarchar(128) COLLATE Latin1_General_100_BIN2 NOT NULL,
        _ss_batch_id bigint NOT NULL,
        _ss_attempt_id varchar(36) COLLATE Latin1_General_100_BIN2 NOT NULL,
        _ss_row_key varchar(64) COLLATE Latin1_General_100_BIN2 NOT NULL,
        _ss_staged_at datetime2(7) NOT NULL DEFAULT SYSUTCDATETIME();
    -- NON-unique: Spark task retries are allowed to append the same row key.
    CREATE INDEX {ident('ix_stage_' + key)} ON {stage}
        (_ss_pipeline_id, _ss_batch_id, _ss_attempt_id, _ss_row_key);
END;
IF NOT EXISTS (SELECT 1 FROM {ns}.[sinks] WHERE sink_key='{key}')
    INSERT INTO {ns}.[sinks] (sink_key, target_table, column_names)
    VALUES ('{key}', {literal(target)}, {literal(columns_json)});
GO
CREATE OR ALTER PROCEDURE {proc}
    @pipeline_id nvarchar(128),
    @batch_id bigint,
    @attempt_id varchar(36),
    @expected_rows bigint
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF @pipeline_id IS NULL OR LEN(@pipeline_id)=0 OR @batch_id IS NULL OR @batch_id<0
       OR @expected_rows IS NULL OR @expected_rows<0 OR @attempt_id IS NULL OR LEN(@attempt_id)<>36
        THROW 51001, 'Invalid commit arguments', 1;
    BEGIN TRY
        BEGIN TRANSACTION;
        DECLARE @lock_result int;
        DECLARE @resource nvarchar(255) = N'billing:{key}:' +
            CONVERT(varchar(64), HASHBYTES('SHA2_256', @pipeline_id), 2) + N':' +
            CONVERT(nvarchar(20), @batch_id);
        EXEC @lock_result = sys.sp_getapplock
            @Resource=@resource, @LockMode='Exclusive', @LockOwner='Transaction',
            @LockTimeout=30000;
        IF @lock_result < 0 THROW 51002, 'Could not obtain sink commit lock', 1;
        IF EXISTS (SELECT 1 FROM {ns}.[commits]
                   WHERE pipeline_id=@pipeline_id AND sink_key='{key}' AND batch_id=@batch_id)
        BEGIN
            COMMIT TRANSACTION;
            RETURN;
        END;
        DECLARE @actual_rows bigint;
        SELECT @actual_rows=COUNT_BIG(DISTINCT _ss_row_key)
        FROM {stage}
        WHERE _ss_pipeline_id=@pipeline_id AND _ss_batch_id=@batch_id
              AND _ss_attempt_id=@attempt_id;
        IF @actual_rows<>@expected_rows
            THROW 51003, 'Incomplete stage or inconsistent row keys; target not committed', 1;
        ;WITH deduplicated AS (
            SELECT {cols}, ROW_NUMBER() OVER (
                PARTITION BY _ss_row_key ORDER BY _ss_row_key) AS _ss_rn
            FROM {stage}
            WHERE _ss_pipeline_id=@pipeline_id AND _ss_batch_id=@batch_id
                  AND _ss_attempt_id=@attempt_id
        )
        INSERT INTO {target} ({cols})
        SELECT {cols} FROM deduplicated WHERE _ss_rn=1;
        IF CONVERT(bigint, @@ROWCOUNT)<>@expected_rows
            THROW 51004, 'Inserted count differs from expected; rollback', 1;
        INSERT INTO {ns}.[commits] (pipeline_id, sink_key, batch_id, row_count)
        VALUES (@pipeline_id, '{key}', @batch_id, @expected_rows);
        DELETE FROM {stage} WHERE _ss_pipeline_id=@pipeline_id AND _ss_batch_id=@batch_id
                                 AND _ss_attempt_id=@attempt_id;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO
-- Runtime principal needs INSERT on staging, SELECT on sinks/commits and EXECUTE
-- on this procedure. Review ownership chaining/target permissions with your DBA.
-- Retain commits for the full checkpoint replay lifetime. Do not routinely purge them.
-- Orphan attempts: clean only while this pipeline is stopped and no tasks can retry.
"""


def protocol_test():
    fixture = dict(sink_key='fixture', connection='DISPOSABLE TEST DATABASE ONLY',
                   target='billing_protocol_test.target', columns=['ID', 'VALUE'])
    header = """-- Run ONLY in a new disposable test database with sqlcmd -b.
-- Leaves test objects for inspection; does not drop or overwrite anything.
IF SCHEMA_ID('billing_protocol_test') IS NOT NULL
    THROW 51999, 'Test schema already exists; choose a fresh disposable database', 1;
EXEC('CREATE SCHEMA billing_protocol_test');
GO
CREATE TABLE billing_protocol_test.target ([ID] int NOT NULL CHECK ([ID]>0), [VALUE] nvarchar(50) NULL);
GO
"""
    body = """
DECLARE @pipeline nvarchar(128)=N'test-generation';
DECLARE @attempt varchar(36)='00000000-0000-0000-0000-000000000001';
-- Two legitimate identical rows have DIFFERENT keys; task retries repeat SAME keys.
INSERT billing_protocol_test.stage_fixture
([ID],[VALUE],_ss_pipeline_id,_ss_batch_id,_ss_attempt_id,_ss_row_key)
VALUES (1,N'value',@pipeline,1,@attempt,REPLICATE('a',64)),
       (1,N'value',@pipeline,1,@attempt,REPLICATE('b',64)),
       (1,N'value',@pipeline,1,@attempt,REPLICATE('a',64)),
       (1,N'value',@pipeline,1,@attempt,REPLICATE('b',64));
EXEC billing_protocol_test.commit_fixture @pipeline,1,@attempt,2;
IF (SELECT COUNT(*) FROM billing_protocol_test.target)<>2 THROW 51999,'Retry duplicates not removed',1;
-- Lost commit acknowledgement: repeat call must not append anything.
EXEC billing_protocol_test.commit_fixture @pipeline,1,@attempt,2;
IF (SELECT COUNT(*) FROM billing_protocol_test.target)<>2 THROW 51999,'Repeated commit duplicated target',1;
-- A prior attempt with partial rows must not contaminate a new attempt.
INSERT billing_protocol_test.stage_fixture
([ID],[VALUE],_ss_pipeline_id,_ss_batch_id,_ss_attempt_id,_ss_row_key)
VALUES (2,N'old attempt',@pipeline,2,@attempt,REPLICATE('c',64));
DECLARE @second varchar(36)='00000000-0000-0000-0000-000000000002';
BEGIN TRY
    EXEC billing_protocol_test.commit_fixture @pipeline,2,@second,1;
    THROW 51999,'Incomplete attempt was accepted',1;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51003 THROW;
END CATCH;
IF EXISTS(SELECT 1 FROM billing_protocol_test.commits WHERE batch_id=2)
    THROW 51999,'Incomplete attempt got a commit marker',1;
-- Target constraint failure must roll back both data and ledger.
INSERT billing_protocol_test.stage_fixture
([ID],[VALUE],_ss_pipeline_id,_ss_batch_id,_ss_attempt_id,_ss_row_key)
VALUES (-1,N'bad',@pipeline,3,@attempt,REPLICATE('d',64));
BEGIN TRY
    EXEC billing_protocol_test.commit_fixture @pipeline,3,@attempt,1;
    THROW 51999,'Target constraint failure was hidden',1;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>547 THROW;
END CATCH;
IF EXISTS(SELECT 1 FROM billing_protocol_test.commits WHERE batch_id=3)
    THROW 51999,'Failed target insert got a commit marker',1;
IF (SELECT COUNT(*) FROM billing_protocol_test.target)<>2 THROW 51999,'Failed transaction changed target',1;
-- Empty output must still be durable/idempotent.
EXEC billing_protocol_test.commit_fixture @pipeline,4,@attempt,0;
IF NOT EXISTS(SELECT 1 FROM billing_protocol_test.commits WHERE batch_id=4 AND row_count=0)
    THROW 51999,'Empty batch not committed',1;
PRINT 'Protocol tests passed: task retry, commit retry, attempt isolation, rollback, empty batch.';
GO
"""
    return header + generate(fixture, 'billing_protocol_test') + body


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path)
    parser.add_argument('--output', type=Path, default=Path('sql'))
    parser.add_argument('--schema', default=os.getenv('STAGING_SCHEMA', 'streaming'))
    parser.add_argument('--protocol-test', type=Path, help='Also emit a test script for a disposable database')
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text(encoding='utf-8')) if args.manifest else default_manifest()
    keys = [spec['sink_key'] for spec in manifest]
    if len(set(keys)) != len(keys):
        raise ValueError('Duplicate sink keys')
    # Validate all before creating any output.
    scripts = [(spec['sink_key'], generate(spec, args.schema)) for spec in manifest]
    args.output.mkdir(parents=True, exist_ok=True)
    for key, script in scripts:
        (args.output / (key + '.sql')).write_text(script, encoding='utf-8')
    (args.output / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    if args.protocol_test:
        args.protocol_test.parent.mkdir(parents=True, exist_ok=True)
        args.protocol_test.write_text(protocol_test(), encoding='utf-8')
    print(f'Generated {len(scripts)} scripts in {args.output}; no database connections made.')


if __name__ == '__main__':
    main()
