import unittest
from staging_sql import default_manifest, generate, table_name


class SqlGenerationTests(unittest.TestCase):
    def test_eight_distinct_sink_contracts(self):
        specs = default_manifest()
        self.assertEqual(len(specs), 8)
        self.assertEqual(len({x['sink_key'] for x in specs}), 8)

    def test_each_commit_is_transactional_and_scoped(self):
        for spec in default_manifest():
            with self.subTest(sink=spec['sink_key']):
                sql = generate(spec)
                self.assertIn('SET XACT_ABORT ON', sql)
                self.assertIn("@LockOwner='Transaction'", sql)
                self.assertIn('IF XACT_STATE()<>0 ROLLBACK TRANSACTION', sql)
                self.assertIn('_ss_attempt_id=@attempt_id', sql)
                self.assertIn('COUNT_BIG(DISTINCT _ss_row_key)', sql)
                self.assertIn('WHERE _ss_rn=1', sql)
                # Data INSERT and ledger INSERT both precede final COMMIT.
                data = sql.index('INSERT INTO ' + table_name(spec['target']))
                ledger = sql.index('INSERT INTO [streaming].[commits]', data)
                commit = sql.index('COMMIT TRANSACTION;', ledger)
                self.assertLess(data, ledger)
                self.assertLess(ledger, commit)

    def test_stage_index_allows_task_retry_duplicates(self):
        sql = generate(default_manifest()[0])
        self.assertIn('CREATE INDEX [ix_stage_oss]', sql)
        self.assertNotIn('CREATE UNIQUE INDEX', sql)

    def test_rejects_sql_injection_and_cross_database_names(self):
        for name in ['dbo.x;DROP TABLE y', 'db.dbo.x', '[dbo].[x]--']:
            with self.subTest(name=name), self.assertRaises(ValueError):
                table_name(name)

    def test_rejects_duplicate_and_reserved_columns(self):
        for columns in [['X', 'x'], ['_ss_row_key'], []]:
            spec = dict(default_manifest()[0], columns=columns)
            with self.assertRaises(ValueError):
                generate(spec)

    def test_contract_cannot_silently_change_target(self):
        sql = generate(default_manifest()[0])
        self.assertIn('Sink contract already differs', sql)
        self.assertIn('column_names<>', sql)


if __name__ == '__main__':
    unittest.main(verbosity=2)
