"""
PySpark Structured Streaming pipeline: GSM billing from Kafka -> MSSQL.

Reads Avro-encoded GSM CDRs from a Kafka topic (Confluent wire format),
joins them with several lookup tables from MSSQL (IDENTS, BS, ROL, RUCHEY,
ROAD, PULKOVO), splits the traffic into a number of business categories
(operator subscribers, foreign 10/11-digit numbers, non-Russian numbers,
alarm/non-alarm idents, base-station polygons), and writes each category
into its target MSSQL table.

Spark 4.0.1 / Python 3.10. See DEPLOYMENT_RU.md before deployment, especially
staging SQL, stable PIPELINE_ID and checkpoint migration. No services accessed on import.
"""

import json
import os
import logging
import time
import re
import uuid
from contextlib import contextmanager
from functools import reduce
from urllib.parse import quote

from pyspark import StorageLevel
import urllib.request

from pyspark.sql import DataFrame, SparkSession, Window
from pyspark.sql import functions as F
from pyspark.sql.avro.functions import from_avro

# =============================================================================
# Configuration
# =============================================================================

# --- Kafka ---
KAFKA_BOOTSTRAP = os.getenv(
    'KAFKA_BOOTSTRAP',
    os.getenv('KAFKA_BOOTSRAP', '192.168.115.66:9092,192.168.115.122:9092,192.168.115.46:9092'),
)
INPUT_TOPICS = os.getenv('INPUT_TOPICS', 'GSM')
ERRORS_TOPIC = os.getenv('ERRORS_TOPIC', 'errors')
STARTING_OFFSETS = os.getenv('STARTING_OFFSETS', '')
CHECKPOINT_LOCATION = os.getenv('CHECKPOINT_LOCATION', '')

# --- Avro schema source ---
REGISTRY_COMPAT_URL = os.getenv("REGISTRY_COMPAT_URL", "http://kafka02:8889/apis/ccompat/v7")
SCHEMA_SUBJECT = os.getenv("SCHEMA_SUBJECT", "Billing_GSM_Transform")
READER_SCHEMA_STR = os.getenv("READER_SCHEMA_STR", "")
READER_SCHEMA_FILE = os.getenv("READER_SCHEMA_FILE", "")

# --- Avro field name overrides ---
LAC_FROM_FIELD = os.getenv("LAC_FROM_FIELD", "LAC_FROM")
LAC_TO_FIELD = os.getenv("LAC_TO_FIELD", "LAC_TO")
CELLID_FROM_FIELD = os.getenv("CELLID_FROM_FIELD", "CELLID_FROM")
CELLID_TO_FIELD = os.getenv("CELLID_TO_FIELD", "CELLID_TO")
CODE_FROM_FIELD = os.getenv("CODE_FROM_FIELD", "CODE_FROM")
CODE_TO_FIELD = os.getenv("CODE_TO_FIELD", "CODE_TO")

# --- MSSQL credentials ---
MSSQL_USER = os.getenv("MSSQL_USER", "preprocs_login")
MSSQL_PASSWORD = os.getenv("MSSQL_PASSWORD", "")
MSSQL_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver"

# --- MSSQL: PROCESSING1 (idents / msisdn) ---
MSSQL_JDBC_URL_IDENTS = os.getenv(
    "MSSQL_JDBC_URL_IDENTS",
    "jdbc:sqlserver://processing1.:1433;databaseName=DATA_PROCESSOR;encrypt=False",
)
MSSQL_MSISDN_IDENTS_TABLE = os.getenv("MSSQL_MSISDN_IDENTS_TABLE", "DTS_SEARCH.IDENTS_MSISDN")
MSSQL_DTS_IDENTS_TABLE = os.getenv("MSSQL_IDENTS_TABLE", "DTS_SEARCH.IDENTS")
MSSQL_DTS_IDENTS_BS_TABLE = os.getenv("MSSQL_IDENTS_BS_TABLE", "DTS_SEARCH.IDENTS_BS")
MSSQL_JDBC_URL_ROTS_GSM = os.getenv(
    "MSSQL_JDBC_URL_RULES",
    "jdbc:sqlserver://processing1.:1433;databaseName=DATA_PROCESSOR;encrypt=False",
)

# --- MSSQL: HP-STORAGE9 (target tables) ---
MSSQL_JDBC_URL_TARGET = os.getenv(
    "MSSQL_JDBC_URL_TARGET",
    "jdbc:sqlserver://hp-storage9.:1433;databaseName=TEST;encrypt=False",
)
MSSQL_TARGET_TABLE = os.getenv("MSSQL_TARGET_TABLE", "dbo.OSS_KAFKA")
MSSQL_JDBC_URL_IDENTS_TARGET = os.getenv(
    "MSSQL_JDBC_URL_IDENTS_TARGET",
    "jdbc:sqlserver://hp-storage9.:1433;databaseName=SOPR_DB;encrypt=False",
)
MSSQL_TARGET_IDENTS_TABLE = os.getenv("MSSQL_TARGET_IDENTS_TABLE", "IDENTS.OSS")
MSSQL_TARGET_TABLE_VALDAY = os.getenv("MSSQL_TARGET_TABLE_VALDAY", "[TEST].[VALDAY]")
MSSQL_TARGET_TABLE_ROAD = os.getenv("MSSQL_TARGET_TABLE_ROAD", "[TEST].[ROAD]")
MSSQL_TARGET_TABLE_TEST = os.getenv("MSSQL_TARGET_TABLE_TEST", "[TEST].[BS_TEST]")
MSSQL_TARGET_TABLE_ROL_GNEZDO = os.getenv("MSSQL_TARGET_TABLE_ROL_GNEZDO", "[ROL].[GNEZDO]")
MSSQL_TARGET_TABLE_PULKOVO_POLYGON = os.getenv("MSSQL_TARGET_TABLE_PULKOVO_POLYGON", "[ROL].[PULKOVO_POLYGON]")

# --- MSSQL: HEAD (lookups + ALARM target) ---
MSSQL_JDBC_HEAD = os.getenv(
    "MSSQL_JDBC_TARGET_ALARM",
    "jdbc:sqlserver://head2:1433;databaseName=HEAD;encrypt=False",
)
MSSQL_KAFKA_IDENTS_BS = os.getenv("MSSQL_KAFKA_IDENTS_BS", "dbo.V_KAFKA_IDENTS_BS")
MSSQL_KAFKA_IDENTS_PULKOVO = os.getenv("MSSQL_KAFKA_IDENTS_PULKOVO", "dbo.V_KAFKA_IDENTS_BS_PULKOVO")
MSSQL_KAFKA_IDENTS_ROAD = os.getenv("MSSQL_KAFKA_IDENTS_ROAD", "dbo.V_KAFKA_IDENTS_BS_ROAD")
MSSQL_KAFKA_IDENTS_RUCHEY = os.getenv("MSSQL_KAFKA_IDENTS_RUCHEY", "dbo.V_KAFKA_IDENTS_BS_RUCHEY")
MSSQL_KAFKA_IDENTS_MSISDN = os.getenv("MSSQL_KAFKA_IDENTS_MSISDN", "dbo.V_KAFKA_IDENTS_MSISDN")
MSSQL_KAFKA_IDENTS_ROL = os.getenv("MSSQL_KAFKA_IDENTS_ROL", "dbo.V_KAFKA_IDENTS_BS_ROL")
MSSQL_KAFKA_IDENTS_ALARM = os.getenv("MSSQL_KAFKA_IDENTS_ALARM", "dbo.V_KAFKA_IDENTS_ALARM")
MSSQL_KAFKA_IDENTS_NOT_ALARM = os.getenv("MSSQL_KAFKA_IDENTS_NOT_ALARM", "dbo.V_KAFKA_IDENTS_NOT_ALARM")
MSSQL_DATA_ALARM_KAFKA = os.getenv("MSSQL_DATA_ALARM_KAFKA", "ALARM.DATA_ALARM_KAFKA")

# Limits are starting values, not a universal memory/throughput guarantee.
def positive_int(name: str, default: int) -> int:
    value = int(os.getenv(name, str(default)))
    if value <= 0:
        raise ValueError(f"{name} must be positive")
    return value


MAX_OFFSETS_PER_TRIGGER = positive_int("MAX_OFFSETS_PER_TRIGGER", 10000)
MAX_RECORDS_PER_PARTITION = positive_int("MAX_RECORDS_PER_PARTITION", 2500)
KAFKA_FETCH_MAX_BYTES = positive_int("KAFKA_FETCH_MAX_BYTES", 8 * 1024 * 1024)
KAFKA_PARTITION_FETCH_BYTES = positive_int("KAFKA_PARTITION_FETCH_BYTES", 1024 * 1024)
MAX_MESSAGE_BYTES = positive_int("MAX_MESSAGE_BYTES", 1024 * 1024)
JDBC_WRITE_PARTITIONS = positive_int("JDBC_WRITE_PARTITIONS", 4)
JDBC_BATCH_SIZE = positive_int("JDBC_BATCH_SIZE", 500)
JDBC_FETCH_SIZE = positive_int("JDBC_FETCH_SIZE", 1000)
JDBC_QUERY_TIMEOUT = positive_int("JDBC_QUERY_TIMEOUT", 120)
SHUFFLE_PARTITIONS = positive_int("SHUFFLE_PARTITIONS", 128)
TRIGGER_INTERVAL = os.getenv("TRIGGER_INTERVAL", "10 seconds")
PARSE_ERROR_MODE = os.getenv("PARSE_ERROR_MODE", "fail").lower()
SCHEMA_VERSION = os.getenv("SCHEMA_VERSION", "latest")
EXPECTED_SCHEMA_ID = os.getenv("EXPECTED_SCHEMA_ID", "")
SCHEMA_RETRIES = positive_int("SCHEMA_RETRIES", 3)
# Staged mode requires generated SQL to be deployed in each destination database.
SINK_MODE = os.getenv("SINK_MODE", "staged").lower()
PIPELINE_ID = os.getenv("PIPELINE_ID", "")
STAGING_SCHEMA = os.getenv("STAGING_SCHEMA", "streaming")
FINALIZE_TIMEOUT = positive_int("FINALIZE_TIMEOUT", 600)
MAX_OUTPUT_ROWS_PER_SINK = positive_int("MAX_OUTPUT_ROWS_PER_SINK", 1000000)
MAX_BATCH_BYTES = positive_int("MAX_BATCH_BYTES", 256 * 1024 * 1024)
JDBC_ROWS_PER_PARTITION = positive_int("JDBC_ROWS_PER_PARTITION", 10000)
JDBC_BULK_COPY = os.getenv("JDBC_BULK_COPY", "false").lower() == "true"
LOOKUP_STORAGE_LEVEL = os.getenv("LOOKUP_STORAGE_LEVEL", "DISK_ONLY")
BATCH_STORAGE_LEVEL = os.getenv("BATCH_STORAGE_LEVEL", "DISK_ONLY")
LOOKUP_READ_CONFIG = json.loads(os.getenv("LOOKUP_READ_CONFIG", "{}"))
LOOKUP_PROFILE = os.getenv("LOOKUP_PROFILE", "false").lower() == "true"
MAX_LOOKUP_MATCHES = positive_int("MAX_LOOKUP_MATCHES", 10000)
STALL_WARN_SECONDS = positive_int("STALL_WARN_SECONDS", 300)
SESSION_TIMEZONE = os.getenv("SESSION_TIMEZONE", "Europe/Moscow")
COALESCE_SHUFFLE = os.getenv("COALESCE_SHUFFLE", "true").lower()
IDENT_BRANCHES = [("TEL_FROM", 2), ("TEL_TO", 2), ("IMSI_FROM", 19),
                  ("IMSI_TO", 19), ("IMEI_FROM", 20), ("IMEI_TO", 20)]


def storage_level(name: str):
    if name not in {"DISK_ONLY", "MEMORY_AND_DISK"}:
        raise ValueError("Only DISK_ONLY or MEMORY_AND_DISK cache levels are allowed")
    return getattr(StorageLevel, name)


def sql_identifier(name: str) -> str:
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,100}", name):
        raise ValueError(f"Invalid SQL identifier: {name!r}")
    return "[" + name + "]"

LOGGER = logging.getLogger("billing")
spark = None
LOOKUP_CACHE = []
SINK_CONTRACTS = {}
SINK_SPECS = [
    ("oss", MSSQL_JDBC_URL_TARGET, MSSQL_TARGET_TABLE),
    ("idents", MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_IDENTS_TABLE),
    ("alarm", MSSQL_JDBC_HEAD, MSSQL_DATA_ALARM_KAFKA),
    ("gnezdo", MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_TABLE_ROL_GNEZDO),
    ("ruchey", MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_TABLE_VALDAY),
    ("bs_test", MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_TABLE_TEST),
    ("road", MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_TABLE_ROAD),
    ("pulkovo", MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_TABLE_PULKOVO_POLYGON),
]


def create_spark() -> SparkSession:
    # Resource allocation belongs to spark-submit, before the driver JVM starts.
    # DISK_ONLY caches and sort-merge joins trade local I/O for bounded cache heap.
    return (
        SparkSession.builder.appName("ANALITIKA")
        .config("spark.sql.shuffle.partitions", str(SHUFFLE_PARTITIONS))
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", COALESCE_SHUFFLE)
        .config("spark.sql.adaptive.coalescePartitions.parallelismFirst", "false")
        .config("spark.sql.adaptive.advisoryPartitionSizeInBytes", "64m")
        .config("spark.sql.session.timeZone", SESSION_TIMEZONE)
        .config("spark.sql.autoBroadcastJoinThreshold", "-1")
        .config("spark.sql.adaptive.autoBroadcastJoinThreshold", "-1")
        .config("spark.sql.join.preferSortMergeJoin", "true")
        .config("spark.speculation", "false")
        .config("spark.driver.maxResultSize", "256m")
        .config("spark.sql.ui.retainedExecutions", "50")
        .config("spark.ui.retainedJobs", "50")
        .config("spark.ui.retainedStages", "100")
        .config("spark.sql.streaming.numRecentProgressUpdates", "20")
        .config("spark.sql.mapKeyDedupPolicy", "LAST_WIN")
        .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        .getOrCreate()
    )


def cache_lookup(df: DataFrame) -> DataFrame:
    # Distributed executor disk cache; no collection of lookup rows on driver.
    cached = df.persist(storage_level(LOOKUP_STORAGE_LEVEL))
    LOOKUP_CACHE.append(cached)
    return cached


# =============================================================================
# Helpers
# =============================================================================


def lit_int(name: str, value: int = 0):
    """Integer literal column with a name. Shorthand for the recurring
    `F.lit(0).alias(name).cast('integer')` pattern."""
    return F.lit(value).cast('integer').alias(name)


def lit_str(name: str, value: str = ''):
    """String literal column with a name."""
    return F.lit(value).cast('string').alias(name)


def in_any_range(col, ranges):
    """Build `col.between(lo1, hi1) | col.between(lo2, hi2) | ...` from a
    list of (lo, hi) tuples."""
    cond = F.lit(False)
    for lo, hi in ranges:
        cond = cond | col.between(lo, hi)
    return cond


def read_jdbc(url: str, table: str) -> DataFrame:
    # Config keys are table names. No bounds are invented for unknown schemas.
    config = LOOKUP_READ_CONFIG.get(table, {})
    unknown = set(config) - {"path", "partitionColumn", "lowerBound", "upperBound", "numPartitions"}
    if unknown:
        raise ValueError(f"Unknown lookup options for {table}: {sorted(unknown)}")
    if "path" in config:
        if len(config) != 1:
            raise ValueError("Snapshot path and JDBC partition settings are mutually exclusive")
        # Supply immutable versioned Parquet snapshots for reproducible recovery.
        return spark.read.parquet(config["path"])
    if config and set(config) != {"partitionColumn", "lowerBound", "upperBound", "numPartitions"}:
        raise ValueError("JDBC partitioning requires column, both bounds and numPartitions")
    if config and not 1 <= int(config["numPartitions"]) <= JDBC_WRITE_PARTITIONS:
        raise ValueError("Lookup JDBC connections must be between 1 and JDBC_WRITE_PARTITIONS")
    reader = (
        spark.read.format("jdbc")
        .option("url", url).option("user", MSSQL_USER).option("password", MSSQL_PASSWORD)
        .option("dbtable", table).option("driver", MSSQL_DRIVER)
        .option("fetchsize", JDBC_FETCH_SIZE).option("queryTimeout", JDBC_QUERY_TIMEOUT)
        .option("responseBuffering", "adaptive")
        .option("loginTimeout", "30").option("socketTimeout", "180000")
    )
    return reader.options(**config).load()


@contextmanager
def control_connection(url: str):
    # Driver handles metadata and one stored-procedure call, never data rows.
    props = spark._jvm.java.util.Properties()
    for key, value in {
        "user": MSSQL_USER, "password": MSSQL_PASSWORD, "loginTimeout": "30",
        "socketTimeout": str((FINALIZE_TIMEOUT + 60) * 1000),
        "applicationName": "billing-control", "responseBuffering": "adaptive",
    }.items():
        props.setProperty(key, value)
    connection = spark._jvm.com.microsoft.sqlserver.jdbc.SQLServerDriver().connect(url, props)
    try:
        yield connection
    finally:
        connection.close()


def batch_committed(url: str, sink_key: str, batch_id: int) -> bool:
    with control_connection(url) as connection:
        statement = connection.prepareStatement(
            f"SELECT 1 FROM {sql_identifier(STAGING_SCHEMA)}.[commits] "
            "WHERE pipeline_id=? AND sink_key=? AND batch_id=?"
        )
        try:
            statement.setQueryTimeout(JDBC_QUERY_TIMEOUT)
            statement.setString(1, PIPELINE_ID)
            statement.setString(2, sink_key)
            statement.setLong(3, int(batch_id))
            result = statement.executeQuery()
            try:
                return bool(result.next())
            finally:
                result.close()
        finally:
            statement.close()


def preflight_sinks() -> None:
    """Detect missing deployments or misrouted tables before consuming Kafka."""
    for sink_key, url, target in SINK_SPECS:
        parts = target.replace("[", "").replace("]", "").split(".")
        if len(parts) != 2:
            raise ValueError("Staged targets must use two-part schema.table names")
        canonical = ".".join(sql_identifier(part) for part in parts)
        with control_connection(url) as connection:
            statement = connection.prepareStatement(
                f"SELECT target_table, column_names FROM {sql_identifier(STAGING_SCHEMA)}.[sinks] "
                "WHERE sink_key=?"
            )
            try:
                statement.setQueryTimeout(JDBC_QUERY_TIMEOUT)
                statement.setString(1, sink_key)
                result = statement.executeQuery()
                try:
                    if not result.next() or result.getString(1) != canonical:
                        raise ValueError(f"Missing/mismatched SQL deployment for sink={sink_key}")
                    SINK_CONTRACTS[sink_key] = json.loads(result.getString(2))
                finally:
                    result.close()
            finally:
                statement.close()


def finalize_batch(url: str, sink_key: str, batch_id: int, attempt_id: str, rows: int) -> None:
    procedure = sql_identifier(STAGING_SCHEMA) + "." + sql_identifier("commit_" + sink_key)
    with control_connection(url) as connection:
        statement = connection.prepareCall("{call " + procedure + "(?, ?, ?, ?)}")
        try:
            statement.setQueryTimeout(FINALIZE_TIMEOUT)
            statement.setString(1, PIPELINE_ID)
            statement.setLong(2, int(batch_id))
            statement.setString(3, attempt_id)
            statement.setLong(4, int(rows))
            statement.execute()
        finally:
            statement.close()


def append_jdbc(df: DataFrame, url: str, table: str, partitions: int, *, bulk: bool) -> None:
    writer = (
        df.repartition(partitions).write.format("jdbc")
        .option("url", url).option("user", MSSQL_USER).option("password", MSSQL_PASSWORD)
        .option("dbtable", table).option("driver", MSSQL_DRIVER)
        .option("numPartitions", partitions).option("batchsize", JDBC_BATCH_SIZE)
        .option("queryTimeout", JDBC_QUERY_TIMEOUT)
        .option("loginTimeout", "30").option("socketTimeout", "180000")
        .option("isolationLevel", "READ_COMMITTED")
    )
    # Bulk Copy is opt-in and restricted to staging, not business tables/triggers.
    if bulk:
        writer = writer.option("useBulkCopyForBatchInsert", "true")
    writer.mode("append").save()


def stage_rows(df: DataFrame, batch_id: int, attempt_id: str) -> DataFrame:
    if any(name.startswith("_ss_") for name in df.columns):
        raise ValueError("Output columns may not use reserved _ss_ prefix")
    # Preserve legitimate duplicate rows: each identical value gets an occurrence
    # number. The SET of keys is stable across Spark task retries, unlike random UUIDs
    # per row or monotonically_increasing_id. JSON options pin timestamp precision.
    encoded = df.withColumn("_ss_json", F.to_json(F.struct(*[df[c] for c in df.columns]), {
        "ignoreNullFields": "false", "timeZone": "UTC",
        "timestampFormat": "yyyy-MM-dd'T'HH:mm:ss.SSSSSSXXX",
        "timestampNTZFormat": "yyyy-MM-dd'T'HH:mm:ss.SSSSSS",
    })).withColumn("_ss_hash", F.sha2("_ss_json", 256))
    numbered = encoded.withColumn(
        "_ss_ordinal", F.row_number().over(Window.partitionBy("_ss_hash").orderBy("_ss_json"))
    )
    return (numbered.withColumn(
        "_ss_row_key", F.sha2(F.concat_ws(":", "_ss_hash", F.col("_ss_ordinal").cast("string")), 256)
    ).drop("_ss_json", "_ss_hash", "_ss_ordinal")
      .withColumn("_ss_pipeline_id", F.lit(PIPELINE_ID))
      .withColumn("_ss_batch_id", F.lit(batch_id).cast("long"))
      .withColumn("_ss_attempt_id", F.lit(attempt_id)))


def write_mssql(df: DataFrame, url_target: str, target_table: str, *,
                batch_id: int, sink_key: str) -> None:
    """Bound writers; materialize one output at a time; fail on any write error."""
    started = time.monotonic()
    sql_identifier(sink_key)
    if SINK_MODE == "staged" and df.columns != SINK_CONTRACTS.get(sink_key):
        raise ValueError(f"Output columns differ from deployed SQL contract for sink={sink_key}")
    if SINK_MODE == "staged" and batch_committed(url_target, sink_key, batch_id):
        LOGGER.info("batch=%s sink=%s already_committed", batch_id, sink_key)
        return
    output = df.persist(storage_level(BATCH_STORAGE_LEVEL))
    try:
        rows = output.count()
        # This is a pre-write guard, not a bound on allocations while executing join.
        if rows > MAX_OUTPUT_ROWS_PER_SINK:
            raise RuntimeError(f"sink={sink_key}: {rows} output rows exceeds safety limit")
        partitions = min(JDBC_WRITE_PARTITIONS, max(1, (rows + JDBC_ROWS_PER_PARTITION - 1)
                                                  // JDBC_ROWS_PER_PARTITION))
        if SINK_MODE == "staged":
            attempt = str(uuid.uuid4())
            if rows:
                stage = sql_identifier(STAGING_SCHEMA) + "." + sql_identifier("stage_" + sink_key)
                append_jdbc(stage_rows(output, batch_id, attempt), url_target, stage,
                            partitions, bulk=JDBC_BULK_COPY)
            # Empty results also receive a commit marker. A later lookup refresh
            # must not turn an already committed empty output into a different one.
            finalize_batch(url_target, sink_key, batch_id, attempt, rows)
        elif rows:
            append_jdbc(output, url_target, target_table, partitions, bulk=False)
        LOGGER.info("batch=%s sink=%s rows=%s writers=%s elapsed_s=%.2f mode=%s",
                    batch_id, sink_key, rows, partitions, time.monotonic() - started, SINK_MODE)
    finally:
        output.unpersist(blocking=True)


def resolve_reader_schema():
    """Return the exact writer schema AND its Confluent ID.

    A single from_avro schema cannot safely decode arbitrary schema IDs.
    Pin SCHEMA_VERSION for reproducible restarts; unknown IDs fail/quarantine.
    """
    if READER_SCHEMA_STR.strip() or READER_SCHEMA_FILE.strip():
        if not EXPECTED_SCHEMA_ID:
            raise ValueError("EXPECTED_SCHEMA_ID is required with an inline/file schema")
        if READER_SCHEMA_STR.strip():
            schema = READER_SCHEMA_STR
        else:
            with open(READER_SCHEMA_FILE, encoding="utf-8") as handle:
                schema = handle.read()
        json.loads(schema)
        return schema, int(EXPECTED_SCHEMA_ID)
    url = (REGISTRY_COMPAT_URL.rstrip("/") + "/subjects/"
           + quote(SCHEMA_SUBJECT, safe="") + "/versions/" + quote(SCHEMA_VERSION, safe=""))
    for attempt in range(SCHEMA_RETRIES):
        try:
            with urllib.request.urlopen(url, timeout=10) as response:
                data = json.loads(response.read(2 * 1024 * 1024).decode("utf-8"))
            json.loads(data["schema"])
            schema_id = int(data["id"])
            if EXPECTED_SCHEMA_ID and schema_id != int(EXPECTED_SCHEMA_ID):
                raise ValueError("Registry schema ID does not match EXPECTED_SCHEMA_ID")
            return data["schema"], schema_id
        except (OSError, TimeoutError):
            if attempt + 1 == SCHEMA_RETRIES:
                raise
            time.sleep(min(2 ** attempt, 8))


# =============================================================================
# Phone-number ranges (used by foreign / non-Russian filters)
# =============================================================================

# 10-digit "foreign" ranges used to flag non-Russian counterpart numbers.
FOREIGN_10DIGIT_RANGES = [
    (8200000000, 8300000000),
    (8400000000, 8500000000),
    (8500000000, 8510000000),
    (8520000000, 8530000000),
    (8530000000, 8540000000),
    (8600000000, 8700000000),
    (8800000000, 8810000000),
    (4210000000, 4220000000),
    (4230000000, 4240000000),
    (4300000000, 4900000000),
    (3200000000, 3300000000),
    (3520000000, 3560000000),
    (3580000000, 3700000000),
    (3710000000, 3730000000),
    (3760000000, 3780000000),
    (3810000000, 3830000000),
    (3900000000, 4000000000),
    (2000000000, 3000000000),
    (5000000000, 7000000000),
]

# Russian 11-digit prefixes (74…, 73…, 78…, 79…) — these are *excluded* from
# the "foreign 11-digit" branch.
RUSSIAN_11DIGIT_RANGES = [
    (79000000000, 79999999999),
    (78000000000, 78999999999),
    (74000000000, 74999999999),
    (73000000000, 73999999999),
]


def is_foreign_11digit(col):
    """True when the number is an 11-digit foreign number: not in the
    Russian 11-digit prefixes and greater than 10_000_000_000."""
    return (~in_any_range(col, RUSSIAN_11DIGIT_RANGES)) & (col > 10000000000)


def is_foreign_10digit(col):
    """True when the number falls into one of the foreign 10-digit ranges."""
    return in_any_range(col, FOREIGN_10DIGIT_RANGES)


# =============================================================================
# Streaming source: Kafka -> wire-strip -> Avro decode -> flatten
# =============================================================================

def build_stream() -> DataFrame:
    writer_schema, schema_id = resolve_reader_schema()
    LOGGER.info("Using Avro schema_id=%s", schema_id)
    source = (
        spark.readStream.format("kafka")
        .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP)
        .option("subscribe", INPUT_TOPICS)
        .option("startingOffsets", STARTING_OFFSETS)
        .option("failOnDataLoss", "true")
        .option("maxOffsetsPerTrigger", MAX_OFFSETS_PER_TRIGGER)
        .option("maxRecordsPerPartition", MAX_RECORDS_PER_PARTITION)
        .option("kafka.fetch.max.bytes", KAFKA_FETCH_MAX_BYTES)
        .option("kafka.max.partition.fetch.bytes", KAFKA_PARTITION_FETCH_BYTES)
        .option("kafka.max.poll.records", "500")
        .option("includeHeaders", "false")
        .load()
    )
    # Native SQL expressions, no Python worker or row serialization for framing.
    framed = source.select(
        F.col("key").alias("in_key"), F.col("value").alias("in_value"),
        "topic", "partition", "offset",
    ).withColumn(
        "schema_id", F.conv(F.hex(F.substring("in_value", 2, 4)), 16, 10).cast("long")
    ).withColumn(
        "wire_error",
        F.when(F.col("in_value").isNull(), F.lit("null_value"))
         .when(F.length("in_value") <= 5, F.lit("short_confluent_frame"))
         .when(F.length("in_value") > MAX_MESSAGE_BYTES, F.lit("message_too_large"))
         .when(F.hex(F.substring("in_value", 1, 1)) != "00", F.lit("invalid_magic"))
         .when(F.col("schema_id") != schema_id, F.lit("unexpected_schema_id"))
    )
    decoded = framed.withColumn(
        "obj", from_avro(
            F.when(F.col("wire_error").isNull(),
                   F.expr("substring(in_value, 6, length(in_value) - 5)")),
            writer_schema, {"mode": "PERMISSIVE"},
        )
    )
    routed_base = decoded.select(
        "in_key", "in_value", "schema_id", "wire_error", "obj",
        "topic", "partition", "offset",
        F.col("obj.STAT_TYPE").alias("CALL_TYPE"),
        F.col("obj.PHONE_FROM").alias("TEL_FROM"),
        F.col("obj.DURATION").alias("DURATION"),
        F.col("obj.PHONE_TO").alias("TEL_TO"),
        F.col("obj.DATE_TIME").alias("DATE_TIME"),
        F.col("obj.IMSI_FROM").alias("IMSI_FROM"),
        F.col("obj.IMSI_TO").alias("IMSI_TO"),
        F.col("obj.IMEI_FROM").alias("IMEI_FROM"),
        F.col("obj.IMEI_TO").alias("IMEI_TO"),
        F.col(f"obj.{LAC_FROM_FIELD}").alias("LAC_FROM"),
        F.col(f"obj.{CELLID_FROM_FIELD}").alias("CELLID_FROM"),
        F.col(f"obj.{CODE_FROM_FIELD}").alias("CODE_FROM"),
        F.col(f"obj.{LAC_TO_FIELD}").alias("LAC_TO"),
        F.col(f"obj.{CELLID_TO_FIELD}").alias("CELLID_TO"),
        F.col(f"obj.{CODE_TO_FIELD}").alias("CODE_TO"),
    )
    # PERMISSIVE can return a non-null struct with every field null.
    all_fields_null = reduce(
        lambda a, b: a & b,
        [F.col("obj.`" + field.name.replace("`", "``") + "`").isNull()
         for field in decoded.schema["obj"].dataType.fields],
        F.lit(True),
    )
    return routed_base.withColumn(
        "parse_error",
        F.when(F.col("wire_error").isNotNull(), F.col("wire_error"))
         .when(F.col("obj").isNull() | all_fields_null, F.lit("from_avro_failed")),
    ).drop("obj", "wire_error")


# Lookup snapshots live on executor disks for this application lifetime.
# They are read lazily; this is not a cross-table transactional snapshot.
def initialize_lookups() -> None:
    global kafka_IDENTS_msisdn
    global kafka_IDENTS_not_alarm
    global kafka_IDENTS_alarm
    global kafka_IDENTS_bs
    global kafka_IDENTS_pulkovo
    global kafka_IDENTS_road
    global kafka_IDENTS_ruchey
    global kafka_IDENTS_bs_rol
    global kafka_IDENTS_not_alarm_2
    global kafka_IDENTS_not_alarm_19
    global kafka_IDENTS_not_alarm_20
    global kafka_IDENTS_alarm_2
    global kafka_IDENTS_alarm_19
    global kafka_IDENTS_alarm_20

    # MSISDN idents — used to identify subscribers of the home operator.
    kafka_IDENTS_msisdn = cache_lookup(read_jdbc(MSSQL_JDBC_HEAD, MSSQL_KAFKA_IDENTS_MSISDN).select(
        F.col("ident").cast("string").alias("ident"),
        F.col("idident").alias("ID_ident"),
        F.col("GP").cast("string"),
    ))

    # Non-alarm idents (TYPE 2 = MSISDN, 19 = IMSI, 20 = IMEI).
    kafka_IDENTS_not_alarm = cache_lookup(read_jdbc(MSSQL_JDBC_HEAD, MSSQL_KAFKA_IDENTS_NOT_ALARM).select(
        F.col("TYPE"),
        F.col("IDENTIFICATOR"),
        F.col("UID"),
        F.col("THEME").cast("string"),
    ))

    # Alarm idents (same TYPE codes).
    kafka_IDENTS_alarm = cache_lookup(read_jdbc(MSSQL_JDBC_HEAD, MSSQL_KAFKA_IDENTS_ALARM).select(
        F.col("TYPE"),
        F.col("IDENTIFICATOR"),
        F.col("UID"),
        F.col("THEME").cast("string"),
    ))


    def _bs_select(df: DataFrame) -> DataFrame:
        """Common projection for base-station lookup tables."""
        return cache_lookup(df.select(
            F.col("REMARK").cast('string'),
            F.col("LAC").cast('integer'),
            F.col("CELLID"),
            F.col("CODE"),
        ))


    kafka_IDENTS_bs = _bs_select(read_jdbc(MSSQL_JDBC_HEAD, MSSQL_KAFKA_IDENTS_BS))
    kafka_IDENTS_pulkovo = _bs_select(read_jdbc(MSSQL_JDBC_HEAD, MSSQL_KAFKA_IDENTS_PULKOVO))
    kafka_IDENTS_road = _bs_select(read_jdbc(MSSQL_JDBC_HEAD, MSSQL_KAFKA_IDENTS_ROAD))
    kafka_IDENTS_ruchey = _bs_select(read_jdbc(MSSQL_JDBC_HEAD, MSSQL_KAFKA_IDENTS_RUCHEY))

    # ROL has no REMARK column.
    kafka_IDENTS_bs_rol = cache_lookup(read_jdbc(MSSQL_JDBC_HEAD, MSSQL_KAFKA_IDENTS_ROL).select(
        F.col("LAC").cast('integer'),
        F.col("CELLID"),
        F.col("CODE"),
    ))

    # Pre-split idents by TYPE so the streaming joins don't refilter each batch.
    kafka_IDENTS_not_alarm_2 = kafka_IDENTS_not_alarm.filter(F.col("TYPE") == 2)
    kafka_IDENTS_not_alarm_19 = kafka_IDENTS_not_alarm.filter(F.col("TYPE") == 19)
    kafka_IDENTS_not_alarm_20 = kafka_IDENTS_not_alarm.filter(F.col("TYPE") == 20)

    kafka_IDENTS_alarm_2 = kafka_IDENTS_alarm.filter(F.col("TYPE") == 2)
    kafka_IDENTS_alarm_19 = kafka_IDENTS_alarm.filter(F.col("TYPE") == 19)
    kafka_IDENTS_alarm_20 = kafka_IDENTS_alarm.filter(F.col("TYPE") == 20)



# =============================================================================
# Column projections (OSS_KAFKA / IDENTS_OSS / ALARM target schemas)
# =============================================================================

def select_oss_kafka(df: DataFrame, *, direction: int, gp_col=None) -> DataFrame:
    """Select columns matching the OSS_KAFKA target schema.

    direction=0: keep TEL_FROM / TEL_TO orientation.
    direction=1: swap TEL_FROM<->TEL_TO and the related IMSI/IMEI/CODE/LAC/CELLID
                 columns (the call is being attributed to the other party).
    gp_col: column expression for GP. Defaults to empty-string literal.
    """
    if gp_col is None:
        gp_col = lit_str('GP')

    if direction == 0:
        return df.select(
            'DATE_TIME', 'DURATION', 'CALL_TYPE',
            'TEL_FROM', 'IMSI_FROM', 'IMEI_FROM', 'TEL_TO',
            lit_int('ID_TO'), lit_int('MSRN'),
            'IMSI_TO', 'IMEI_TO',
            'CODE_FROM', lit_int('MCC_FROM'), lit_int('MNC_FROM'),
            'LAC_FROM', 'CELLID_FROM',
            'CODE_TO', lit_int('MCC_TO'), lit_int('MNC_TO'),
            'LAC_TO', 'CELLID_TO',
            lit_int('SERVICE_CENTER_FROM'), lit_int('SERVICE_CENTER_TO'),
            'ID_ident', lit_int('DIRECTION', 0),
            gp_col,
        )

    # direction == 1: mirror the call.
    return df.select(
        'DATE_TIME', 'DURATION', 'CALL_TYPE',
        F.col('TEL_TO').alias('TEL_FROM'),
        F.col('IMSI_TO').alias('IMSI_FROM'),
        F.col('IMEI_TO').alias('IMEI_FROM'),
        F.col('TEL_FROM').alias('TEL_TO'),
        lit_int('ID_TO'), lit_int('MSRN'),
        F.col('IMSI_FROM').alias('IMSI_TO'),
        F.col('IMEI_FROM').alias('IMEI_TO'),
        F.col('CODE_TO').alias('CODE_FROM'),
        lit_int('MCC_FROM'), lit_int('MNC_FROM'),
        F.col('LAC_TO').alias('LAC_FROM'),
        F.col('CELLID_TO').alias('CELLID_FROM'),
        F.col('CODE_FROM').alias('CODE_TO'),
        lit_int('MCC_TO'), lit_int('MNC_TO'),
        F.col('LAC_FROM').alias('LAC_TO'),
        F.col('CELLID_FROM').alias('CELLID_TO'),
        lit_int('SERVICE_CENTER_FROM'), lit_int('SERVICE_CENTER_TO'),
        'ID_ident', lit_int('DIRECTION', 1),
        gp_col,
    )


def select_idents_oss(df: DataFrame, *, keep_branch: bool = False) -> DataFrame:
    """Select columns matching the IDENTS_OSS (non-alarm) target schema."""
    return df.select(
        'DATE_TIME', 'DURATION', 'CALL_TYPE',
        'TEL_FROM', 'IMSI_FROM', 'IMEI_FROM', 'TEL_TO',
        lit_int('MSRN'), 'IMSI_TO', 'IMEI_TO',
        'CODE_FROM', lit_int('MCC_FROM'), lit_int('MNC_FROM'),
        'LAC_FROM', 'CELLID_FROM',
        'CODE_TO', lit_int('MCC_TO'), lit_int('MNC_TO'),
        'LAC_TO', 'CELLID_TO',
        lit_int('SERVICE_CENTER_FROM'), lit_int('SERVICE_CENTER_TO'),
        F.col('IDENTIFICATOR').alias('UID'), 'THEME',
        *([F.col('_match_branch')] if keep_branch else []),
    ).distinct()


def select_alarm(df: DataFrame) -> DataFrame:
    """Select DATA_ALARM_KAFKA columns with consistent UID naming."""
    uid_col = F.col('IDENTIFICATOR').alias('UID')
    return df.select(
        'DATE_TIME', 'DURATION', 'CALL_TYPE',
        'TEL_FROM', 'IMSI_FROM', 'IMEI_FROM',
        lit_str('ID_FROM'),
        'TEL_TO', lit_int('MSRN'),
        'IMSI_TO', 'IMEI_TO', lit_str('ID_TO'),
        'CODE_FROM', lit_int('MCC_FROM'), lit_int('MNC_FROM'),
        'LAC_FROM', 'CELLID_FROM',
        'CODE_TO', lit_int('MCC_TO'), lit_int('MNC_TO'),
        'LAC_TO', 'CELLID_TO',
        lit_int('SERVICE_CENTER_FROM'), lit_int('SERVICE_CENTER_TO'),
        lit_str('MSG'), uid_col, 'THEME',
    )


def select_bs_match(df: DataFrame, *, side: str, distinct: bool = True) -> DataFrame:
    """Select columns for the simple BS-match outputs (ruchey, TEST).

    side='from' uses TEL_FROM/IMSI_FROM/IMEI_FROM; side='to' uses *_TO.
    """
    if side == 'from':
        cols = [
            F.col('TEL_FROM').alias('ID'),
            F.col('IMSI_FROM').alias('IMSI'),
            F.col('IMEI_FROM').alias('IMEI'),  # NB: ruchey/TEST_from use this
        ]
    else:
        cols = [
            F.col('TEL_TO').alias('ID'),
            F.col('IMSI_TO').alias('IMSI'),
            F.col('IMEI_TO').alias('IMEI'),
        ]
    out = df.select(*cols, lit_int('TYPE'), F.col('REMARK'), F.col("DATE_TIME"))
    return out.distinct() if distinct else out


# =============================================================================
# Per-batch processing
# =============================================================================


def _opers_branch(kafka_df: DataFrame, *, tel_col: str, other_tel_col: str,
                  direction: int, with_real_gp: bool) -> DataFrame:
    """Operator-subscriber branch: use the cached join, require ident
    to be present, and emit OSS_KAFKA rows with the requested direction."""
    joined = kafka_df

    filtered = joined.filter(
        (kafka_df[other_tel_col] != 0)
        & (F.col('ident').isNotNull())
        & (kafka_df.TEL_FROM != kafka_df.TEL_TO)
    )
    if direction == 0:
        filtered = filtered.dropna(subset=['ident'])

    gp_col = F.col('GP') if with_real_gp else None
    return select_oss_kafka(filtered, direction=direction, gp_col=gp_col)


def _foreign_11digit_branch(kafka_df: DataFrame, *, tel_col: str,
                            other_tel_col: str, direction: int) -> DataFrame:
    """Foreign 11-digit branch: counterpart is non-MSISDN and not in the
    Russian 11-digit ranges."""
    joined = kafka_df
    filtered = joined.filter(
        (kafka_df[other_tel_col] != 0)
        & (F.col('ident').isNull())
        & is_foreign_11digit(F.col(tel_col))
        & (kafka_df.TEL_TO != kafka_df.TEL_FROM)
    )
    return select_oss_kafka(filtered, direction=direction)


def _foreign_10digit_branch(kafka_df: DataFrame, *, tel_col: str,
                            other_tel_col: str, imsi_col: str,
                            direction: int) -> DataFrame:
    """Foreign 10-digit branch: counterpart falls into one of the foreign
    10-digit ranges and has no usable IMSI."""
    joined = kafka_df
    filtered = joined.filter(
        (kafka_df[other_tel_col] != 0)
        & (F.col('ident').isNull())
        & is_foreign_10digit(kafka_df[tel_col])
        & (kafka_df.TEL_FROM != kafka_df.TEL_TO)
        & ((kafka_df[imsi_col].isNull()) | (kafka_df[imsi_col] == 0))
    )
    return select_oss_kafka(filtered, direction=direction)


def _not_russian_branch(kafka_df: DataFrame, *, tel_col: str,
                        other_tel_col: str, imsi_col: str,
                        join_tel_col: str, direction: int) -> DataFrame:
    """Non-Russian branch: counterpart is in the 10-digit space, has an
    IMSI present, and the IMSI is *not* a Russian (250...) IMSI.

    NB on `join_tel_col`: the original code joins on TEL_TO in BOTH the
    direction=0 and direction=1 not-russian branches (likely a typo in the
    FROM variant), so we preserve that asymmetry here.
    """
    joined = kafka_df
    filtered = joined.filter(
        (kafka_df[other_tel_col] != 0)
        & (F.col('ident').isNull())
        & (kafka_df.TEL_TO != kafka_df.TEL_FROM)
        & (kafka_df[tel_col].between(1000000000, 10000000000))
        & (kafka_df[imsi_col] != 0)
        & (kafka_df[imsi_col].isNotNull())
        & (~F.col(imsi_col).between(250000000000000, 251000000000000))
    )
    return select_oss_kafka(filtered, direction=direction)


def _idents_branch(kafka_df: DataFrame, ident_table: DataFrame,
                   kafka_col: str) -> DataFrame:
    """Inner-join kafka_df on a single column to an idents table and
    emit IDENTS_OSS rows."""
    joined = kafka_df.join(
        ident_table,
        kafka_df[kafka_col] == ident_table.IDENTIFICATOR,
        how='inner',
    )
    return select_idents_oss(joined)


def _alarm_branch(kafka_df: DataFrame, ident_table: DataFrame,
                  kafka_col: str) -> DataFrame:
    """Inner-join kafka_df on a single column to an ALARM idents table
    and emit DATA_ALARM_KAFKA rows."""
    joined = kafka_df.join(
        ident_table,
        kafka_df[kafka_col] == ident_table.IDENTIFICATOR,
        how='inner',
    )
    return select_alarm(joined)


def _bs_polygon_match(kafka_df: DataFrame, bs_table: DataFrame, *,
                      side: str) -> DataFrame:
    """Join kafka_df to a base-station polygon table on (CODE, LAC, CELLID)."""
    if side == 'from':
        cond = (
            (kafka_df.CODE_FROM == bs_table.CODE)
            & (kafka_df.LAC_FROM == bs_table.LAC)
            & (kafka_df.CELLID_FROM == bs_table.CELLID)
        )
        tel_filter = kafka_df.TEL_FROM.isNotNull() & (
            (kafka_df.TEL_FROM != 0) | (kafka_df.IMSI_FROM != 0)
        )
    else:
        cond = (
            (kafka_df.CODE_TO == bs_table.CODE)
            & (kafka_df.LAC_TO == bs_table.LAC)
            & (kafka_df.CELLID_TO == bs_table.CELLID)
        )
        tel_filter = kafka_df.TEL_TO.isNotNull() & (
            (kafka_df.TEL_TO != 0) | (kafka_df.IMSI_TO != 0)
        )
    return kafka_df.join(bs_table, cond, how='inner').filter(tel_filter)


def expand_identifiers(batch: DataFrame):
    # Spark array() coerces heterogeneous field types. Use the old path if that
    # would change comparisons (e.g. string phone + numeric IMSI).
    types = {batch.schema[column].dataType.simpleString() for column, _ in IDENT_BRANCHES}
    if len(types) != 1:
        LOGGER.info("Identifier types differ; preserving six-join comparison semantics")
        return None
    entries = [F.struct(F.lit(column).alias("branch"), F.lit(kind).alias("kind"),
                        F.col(column).alias("value")) for column, kind in IDENT_BRANCHES]
    return (batch.withColumn("_match", F.explode(F.array(*entries)))
            .select("*", F.col("_match.branch").alias("_match_branch"),
                    F.col("_match.kind").alias("_match_type"),
                    F.col("_match.value").alias("_match_value"))
            .drop("_match").where(F.col("_match_value").isNotNull()))


def identifier_outputs(batch: DataFrame, expanded, table: DataFrame, *, alarm: bool):
    if expanded is None:
        branches = [(_alarm_branch if alarm else _idents_branch)(
            batch, table.where(F.col("TYPE") == kind), column
        ) for column, kind in IDENT_BRANCHES]
        return reduce(lambda a, b: a.unionByName(b), branches)
    matched = expanded.join(table, (expanded._match_type == table.TYPE)
                            & (expanded._match_value == table.IDENTIFICATOR), "inner")
    if alarm:
        return select_alarm(matched)
    # Keep duplicate outputs from different match branches, just as the original
    # UNION ALL of six independently distinct projections did.
    return select_idents_oss(matched, keep_branch=True).drop("_match_branch")


def profile_lookups() -> None:
    specs = [("msisdn", kafka_IDENTS_msisdn, ["ident"]),
             ("alarm", kafka_IDENTS_alarm, ["TYPE", "IDENTIFICATOR"]),
             ("not_alarm", kafka_IDENTS_not_alarm, ["TYPE", "IDENTIFICATOR"])]
    specs += [(name, table, ["CODE", "LAC", "CELLID"]) for name, table in [
        ("bs", kafka_IDENTS_bs), ("pulkovo", kafka_IDENTS_pulkovo),
        ("road", kafka_IDENTS_road), ("ruchey", kafka_IDENTS_ruchey),
        ("rol", kafka_IDENTS_bs_rol)]]
    for name, table, keys in specs:
        # Exactly one aggregate row reaches driver, never identifiers themselves.
        stats = table.groupBy(*keys).count().agg(
            F.sum("count").alias("rows"), F.count("*").alias("keys"),
            F.max(F.when(reduce(lambda a, b: a & b, [F.col(k).isNotNull() for k in keys]),
                         F.col("count")).otherwise(0)).alias("max_matches"),
        ).first()
        LOGGER.info("lookup=%s rows=%s keys=%s max_matches=%s", name, *stats)
        if (stats["max_matches"] or 0) > MAX_LOOKUP_MATCHES:
            raise RuntimeError(f"lookup={name} exceeds MAX_LOOKUP_MATCHES; review key multiplicity")


def process_outputs(batch_df: DataFrame, batch_id: int) -> None:
    operator_joins = {}
    expanded = None
    try:
        # Reuse two joins across eight OSS branches. Preserve original multiplicity.
        for column in ("TEL_FROM", "TEL_TO"):
            operator_joins[column] = batch_df.join(
                kafka_IDENTS_msisdn,
                batch_df[column] == kafka_IDENTS_msisdn.ident,
                how="left_outer",
            ).persist(storage_level(BATCH_STORAGE_LEVEL))
        expanded = expand_identifiers(batch_df)
        if expanded is not None:
            expanded = expanded.persist(storage_level(BATCH_STORAGE_LEVEL))
        process_outputs_with_joins(batch_df, batch_id, operator_joins, expanded)
    finally:
        if expanded is not None:
            expanded.unpersist(blocking=True)
        for joined in operator_joins.values():
            joined.unpersist(blocking=True)


def process_outputs_with_joins(batch_df: DataFrame, batch_id: int,
                               operator_joins: dict, expanded=None) -> None:
    """Per-microbatch handler: split batch into all output streams and write
    each to its MSSQL target table."""
    kafka_df = batch_df

    # -----------------------------------------------------------------------
    # OSS_KAFKA: 4 categories x 2 directions = 8 branches
    # -----------------------------------------------------------------------
    oss_branches = [
        # direction=0: counterpart is TEL_TO (call destination)
        _opers_branch(operator_joins["TEL_TO"], tel_col='TEL_TO', other_tel_col='TEL_FROM',
                      direction=0, with_real_gp=True),
        _foreign_11digit_branch(operator_joins["TEL_TO"], tel_col='TEL_TO',
                                other_tel_col='TEL_FROM', direction=0),
        _foreign_10digit_branch(operator_joins["TEL_TO"], tel_col='TEL_TO',
                                other_tel_col='TEL_FROM', imsi_col='IMSI_TO',
                                direction=0),
        _not_russian_branch(operator_joins["TEL_TO"], tel_col='TEL_TO',
                            other_tel_col='TEL_FROM', imsi_col='IMSI_TO',
                            join_tel_col='TEL_TO', direction=0),
        # direction=1: counterpart is TEL_FROM (mirror the call)
        _opers_branch(operator_joins["TEL_FROM"], tel_col='TEL_FROM', other_tel_col='TEL_TO',
                      direction=1, with_real_gp=False),
        _foreign_11digit_branch(operator_joins["TEL_FROM"], tel_col='TEL_FROM',
                                other_tel_col='TEL_TO', direction=1),
        _foreign_10digit_branch(operator_joins["TEL_FROM"], tel_col='TEL_FROM',
                                other_tel_col='TEL_TO', imsi_col='IMSI_FROM',
                                direction=1),
        # NB: original code joins not_russian_from on TEL_TO (likely a typo),
        # preserved here.
        _not_russian_branch(operator_joins["TEL_TO"], tel_col='TEL_FROM',
                            other_tel_col='TEL_TO', imsi_col='IMSI_FROM',
                            join_tel_col='TEL_TO', direction=1),
    ]
    combined_stream_union_kafka_oss = oss_branches[0]
    for b in oss_branches[1:]:
        combined_stream_union_kafka_oss = combined_stream_union_kafka_oss.unionByName(b)

    # -----------------------------------------------------------------------
    # IDENTS_OSS: non-alarm matches on phone / IMSI / IMEI (both sides)
    # -----------------------------------------------------------------------
    union_IDENTS_oss = identifier_outputs(kafka_df, expanded, kafka_IDENTS_not_alarm, alarm=False)
    union_IDENTS_alarm = identifier_outputs(kafka_df, expanded, kafka_IDENTS_alarm, alarm=True)

    # -----------------------------------------------------------------------
    # RUCHEY: BS-polygon match -> deduped (ID, IMSI, IMEI, REMARK, DATE_TIME)
    # -----------------------------------------------------------------------
    ruchey_union = select_bs_match(
        _bs_polygon_match(kafka_df, kafka_IDENTS_ruchey, side='from'),
        side='from',
    ).unionByName(
        select_bs_match(
            _bs_polygon_match(kafka_df, kafka_IDENTS_ruchey, side='to'),
            side='to',
        )
    )

    # -----------------------------------------------------------------------
    # ROAD: BS-polygon match -> aggregated (min/max/count of DATE_TIME)
    # -----------------------------------------------------------------------
    def _road_side(side: str) -> DataFrame:
        matched = _bs_polygon_match(kafka_df, kafka_IDENTS_road, side=side)
        id_col = 'TEL_FROM' if side == 'from' else 'TEL_TO'
        imsi_col = 'IMSI_FROM' if side == 'from' else 'IMSI_TO'
        imei_col = 'IMEI_FROM' if side == 'from' else 'IMEI_TO'
        return (
            matched.groupBy(
                F.col(id_col).alias('ID'),
                F.col(imsi_col).alias('IMSI'),
                F.col(imei_col).alias('IMEI'),
                F.col('REMARK'),
            )
            .agg(
                F.min('DATE_TIME').alias('MIN_DATE_TIME'),
                F.max('DATE_TIME').alias('MAX_DATE_TIME'),
                F.count('*').alias('COUNT'),
            )
            .select('ID', 'IMSI', 'IMEI', 'REMARK',
                    'MIN_DATE_TIME', 'MAX_DATE_TIME', 'COUNT')
        )

    road_union = _road_side('from').unionByName(_road_side('to'))

    # -----------------------------------------------------------------------
    # TEST: BS-polygon match (BS table) -> deduped, includes CODE/LAC/CELLID
    # -----------------------------------------------------------------------
    def _test_side(side: str) -> DataFrame:
        matched = _bs_polygon_match(kafka_df, kafka_IDENTS_bs, side=side)
        if side == 'from':
            id_cols = [
                F.col('TEL_FROM').alias('ID'),
                F.col('IMSI_FROM').alias('IMSI'),
                F.col('IMEI_TO').alias('IMEI'),  # NB: TEST_from uses IMEI_TO,
                                                 #     not IMEI_FROM. Preserved.
            ]
        else:
            id_cols = [
                F.col('TEL_TO').alias('ID'),
                F.col('IMSI_TO').alias('IMSI'),
                F.col('IMEI_TO').alias('IMEI'),
            ]
        return matched.select(
            *id_cols, lit_int('TYPE'),
            F.col('REMARK'), F.col("DATE_TIME"),
            'CODE', 'LAC', 'CELLID',
        ).distinct()

    TEST_result = _test_side('from').unionByName(_test_side('to'))

    # -----------------------------------------------------------------------
    # GNEZDO (ROL): join idents AND ROL BS-polygon
    # -----------------------------------------------------------------------
    def _gnezdo_side(side: str) -> DataFrame:
        tel_col = 'TEL_FROM' if side == 'from' else 'TEL_TO'
        code_col = 'CODE_FROM' if side == 'from' else 'CODE_TO'
        lac_col = 'LAC_FROM' if side == 'from' else 'LAC_TO'
        cell_col = 'CELLID_FROM' if side == 'from' else 'CELLID_TO'
        return (
            operator_joins[tel_col].where(F.col("ident").isNotNull())
            .join(
                kafka_IDENTS_bs_rol,
                (kafka_df[code_col] == kafka_IDENTS_bs_rol.CODE)
                & (kafka_df[lac_col] == kafka_IDENTS_bs_rol.LAC)
                & (kafka_df[cell_col] == kafka_IDENTS_bs_rol.CELLID),
                how='inner',
            )
            .filter(kafka_df[tel_col].isNotNull() & (kafka_df[tel_col] != 0))
            .select(
                F.col('DATE_TIME'),
                F.col(tel_col).alias('MSISDN'),
                F.col('ID_ident').alias("IDident"),
                F.col('GP'),
                F.col(code_col).alias('CODE'),
                F.col(lac_col).alias('LAC'),
                F.col(cell_col).alias('CELLID'),
                lit_str('HASHTAG'),
            )
            .distinct()
        )

    gnezdo_result = _gnezdo_side('from').unionByName(_gnezdo_side('to'))

    # -----------------------------------------------------------------------
    # PULKOVO: BS-polygon match -> day/MSISDN/IMSI/IMEI projection
    # -----------------------------------------------------------------------
    def _pulkovo_side(side: str, distinct: bool) -> DataFrame:
        if side == 'from':
            cond = (
                (kafka_df.CODE_FROM == kafka_IDENTS_pulkovo.CODE)
                & (kafka_df.LAC_FROM == kafka_IDENTS_pulkovo.LAC)
                & (kafka_df.CELLID_FROM == kafka_IDENTS_pulkovo.CELLID)
            )
            tel_filter = kafka_df.TEL_FROM.isNotNull() & (kafka_df.TEL_FROM != 0)
            id_cols = [
                F.col('TEL_FROM').alias('MSISDN'),
                F.col('IMSI_FROM').alias('IMSI'),
                F.col('IMEI_FROM').alias("IMEI"),
            ]
        else:
            cond = (
                (kafka_df.CODE_TO == kafka_IDENTS_pulkovo.CODE)
                & (kafka_df.LAC_TO == kafka_IDENTS_pulkovo.LAC)
                & (kafka_df.CELLID_TO == kafka_IDENTS_pulkovo.CELLID)
            )
            tel_filter = kafka_df.TEL_TO.isNotNull() & (kafka_df.TEL_TO != 0)
            id_cols = [
                F.col('TEL_TO').alias('MSISDN'),
                F.col('IMSI_TO').alias('IMSI'),
                F.col('IMEI_TO').alias("IMEI"),
            ]
        out = (
            kafka_df.join(kafka_IDENTS_pulkovo, cond, how='inner')
            .filter(tel_filter)
            .select(
                F.dayofmonth(F.col('DATE_TIME')).alias('DAY_OF_MONTH'),
                F.col('DATE_TIME'),
                *id_cols,
                F.lit('#SPB_PULKOVO').alias('HASHTAG'),
            )
        )
        # NB: original pulkovo_from has .distinct(), pulkovo_to does not.
        return out.distinct() if distinct else out

    pulkovo_result = _pulkovo_side('from', distinct=True).unionByName(
        _pulkovo_side('to', distinct=False)
    )

    # -----------------------------------------------------------------------
    # Write all outputs to MSSQL.
    # -----------------------------------------------------------------------
    write_mssql(combined_stream_union_kafka_oss, MSSQL_JDBC_URL_TARGET, MSSQL_TARGET_TABLE, batch_id=batch_id, sink_key="oss")
    write_mssql(union_IDENTS_oss, MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_IDENTS_TABLE, batch_id=batch_id, sink_key="idents")
    write_mssql(union_IDENTS_alarm, MSSQL_JDBC_HEAD, MSSQL_DATA_ALARM_KAFKA, batch_id=batch_id, sink_key="alarm")
    write_mssql(gnezdo_result, MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_TABLE_ROL_GNEZDO, batch_id=batch_id, sink_key="gnezdo")
    write_mssql(ruchey_union, MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_TABLE_VALDAY, batch_id=batch_id, sink_key="ruchey")
    write_mssql(TEST_result, MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_TABLE_TEST, batch_id=batch_id, sink_key="bs_test")
    write_mssql(road_union, MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_TABLE_ROAD, batch_id=batch_id, sink_key="road")
    write_mssql(pulkovo_result, MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_TABLE_PULKOVO_POLYGON, batch_id=batch_id, sink_key="pulkovo")



# No streaming distinct/state store: deduplication is bounded to one microbatch.
BUSINESS_COLUMNS = [
    "CALL_TYPE", "DURATION", "TEL_FROM", "TEL_TO", "IMSI_FROM", "IMEI_FROM",
    "IMSI_TO", "IMEI_TO", "LAC_FROM", "LAC_TO", "CELLID_FROM", "CELLID_TO",
    "CODE_FROM", "CODE_TO", "DATE_TIME",
]


def global_process_batch(batch_df: DataFrame, batch_id: int) -> None:
    started = time.monotonic()
    cached = batch_df.persist(storage_level(BATCH_STORAGE_LEVEL))
    business = None
    try:
        # Only a scalar reaches the driver; materializes/validates the full batch.
        stats = cached.agg(
            F.count("*").alias("rows"),
            F.sum(F.when(F.col("parse_error").isNotNull(), 1).otherwise(0)).alias("invalid"),
            F.sum(F.length("in_value")).alias("bytes"),
        ).first()
        rows, invalid_count, batch_bytes = stats["rows"], stats["invalid"] or 0, stats["bytes"] or 0
        LOGGER.info("batch=%s input_rows=%s input_bytes=%s invalid=%s", batch_id, rows, batch_bytes, invalid_count)
        if batch_bytes > MAX_BATCH_BYTES:
            raise RuntimeError("Decoded batch exceeds MAX_BATCH_BYTES; review sizes/limits. "
                               "A failed batch retains its already planned offset range.")
        if rows == 0:
            return
        invalid = cached.where(F.col("parse_error").isNotNull())
        if invalid_count:
            if PARSE_ERROR_MODE == "fail":
                raise RuntimeError(
                    f"batch={batch_id}: {invalid_count} invalid messages; "
                    "no MSSQL writes attempted. Check Avro schema/framing."
                )
            # Same foreachBatch/checkpoint; a DLQ failure also fails this batch.
            # Metadata key is stable across retries; Kafka sink can still duplicate.
            (invalid.select(
                F.to_json(F.struct("topic", "partition", "offset", "schema_id", "parse_error"))
                 .cast("binary").alias("key"),
                F.col("in_value").alias("value"),
            ).write.format("kafka")
             .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP)
             .option("topic", ERRORS_TOPIC)
             .option("kafka.max.request.size", str(max(MAX_MESSAGE_BYTES * 2, 1048576)))
             .save())
        business = (
            cached.where(F.col("parse_error").isNull())
            .select(*BUSINESS_COLUMNS).dropDuplicates()
            .persist(storage_level(BATCH_STORAGE_LEVEL))
        )
        unique_rows = business.count()
        # Release raw Kafka payload before the expensive joins and writes.
        cached.unpersist(blocking=True)
        if unique_rows or SINK_MODE == "staged":
            process_outputs(business, batch_id)
        LOGGER.info("batch=%s input=%s invalid=%s unique=%s elapsed_s=%.2f",
                    batch_id, rows, invalid_count, unique_rows, time.monotonic() - started)
    except Exception:
        LOGGER.exception("batch=%s failed; checkpoint must not commit this batch", batch_id)
        raise
    finally:
        if business is not None:
            business.unpersist(blocking=True)
        cached.unpersist(blocking=True)


def await_query(query) -> None:
    last_batch = None
    last_activity = time.monotonic()
    while not query.awaitTermination(30):
        progress = query.lastProgress
        if progress and progress["batchId"] != last_batch:
            last_batch = progress["batchId"]
            last_activity = time.monotonic()
            LOGGER.info("progress batch=%s input_rows=%s processed_rows_s=%s durations_ms=%s",
                        last_batch, progress.get("numInputRows"),
                        progress.get("processedRowsPerSecond"), progress.get("durationMs"))
        elif query.status.get("isTriggerActive") and time.monotonic() - last_activity >= STALL_WARN_SECONDS:
            LOGGER.warning("No completed batch for %s seconds; inspect Spark UI, JDBC locks and Kafka",
                           STALL_WARN_SECONDS)
            last_activity = time.monotonic()
        elif not query.status.get("isTriggerActive"):
            last_activity = time.monotonic()


def main() -> None:
    global spark
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    if not CHECKPOINT_LOCATION.strip():
        raise ValueError("Set CHECKPOINT_LOCATION to a durable dedicated checkpoint root")
    if not MSSQL_PASSWORD:
        raise ValueError("Set MSSQL_PASSWORD through the deployment secret mechanism")
    if not STARTING_OFFSETS.strip():
        raise ValueError("Set STARTING_OFFSETS explicitly for a new checkpoint")
    if PARSE_ERROR_MODE not in {"fail", "dlq"}:
        raise ValueError("PARSE_ERROR_MODE must be fail or dlq")
    if PARSE_ERROR_MODE == "dlq" and ERRORS_TOPIC in INPUT_TOPICS.split(","):
        raise ValueError("ERRORS_TOPIC must differ from input topics")
    if SINK_MODE not in {"append", "staged"}:
        raise ValueError("SINK_MODE must be staged or append")
    if SINK_MODE == "staged" and not re.fullmatch(r"[A-Za-z0-9_.:-]{1,128}", PIPELINE_ID):
        raise ValueError("Set stable ASCII PIPELINE_ID (1..128 letters/digits/_.:-), unique per checkpoint generation")
    sql_identifier(STAGING_SCHEMA)
    storage_level(LOOKUP_STORAGE_LEVEL)
    storage_level(BATCH_STORAGE_LEVEL)
    if COALESCE_SHUFFLE not in {"true", "false"}:
        raise ValueError("COALESCE_SHUFFLE must be true or false")
    spark = create_spark()
    spark.sparkContext.setLogLevel("WARN")
    try:
        if SINK_MODE == "staged":
            preflight_sinks()
        initialize_lookups()
        if LOOKUP_PROFILE:
            profile_lookups()
        query = (
            build_stream().writeStream
            .foreachBatch(global_process_batch)
            .queryName("BILLING_V2")
            .option("checkpointLocation", CHECKPOINT_LOCATION.rstrip("/") + "/BILLING_V2")
            .trigger(processingTime=TRIGGER_INTERVAL)
            .outputMode("append")
            .start()
        )
        await_query(query)
    finally:
        for lookup in LOOKUP_CACHE:
            lookup.unpersist(blocking=True)
        LOOKUP_CACHE.clear()
        spark.stop()


if __name__ == "__main__":
    main()
