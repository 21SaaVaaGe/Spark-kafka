"""Export raw lookup tables to a new immutable Parquet version, using Spark 4.0.1.

Run on the cluster only after setting SNAPSHOT_ROOT, SNAPSHOT_VERSION and MSSQL_PASSWORD.
No Kafka reads and no target MSSQL writes. Cross-table point-in-time consistency
requires a database snapshot supplied by the operator.
"""
import json
import os
from pathlib import Path
import re

import prod_refactored as p


def main():
    root = os.environ['SNAPSHOT_ROOT'].rstrip('/')
    version = os.environ['SNAPSHOT_VERSION']
    if not root or not re.fullmatch(r'[A-Za-z0-9_-]+', version):
        raise ValueError('Set a durable SNAPSHOT_ROOT and a safe new SNAPSHOT_VERSION')
    if p.LOOKUP_READ_CONFIG:
        raise ValueError('Unset LOOKUP_READ_CONFIG for this export to read live JDBC sources')
    if not p.MSSQL_PASSWORD:
        raise ValueError('Set MSSQL_PASSWORD')
    specs = [('msisdn', p.MSSQL_KAFKA_IDENTS_MSISDN),
             ('alarm', p.MSSQL_KAFKA_IDENTS_ALARM),
             ('not_alarm', p.MSSQL_KAFKA_IDENTS_NOT_ALARM),
             ('bs', p.MSSQL_KAFKA_IDENTS_BS),
             ('pulkovo', p.MSSQL_KAFKA_IDENTS_PULKOVO),
             ('road', p.MSSQL_KAFKA_IDENTS_ROAD),
             ('ruchey', p.MSSQL_KAFKA_IDENTS_RUCHEY),
             ('rol', p.MSSQL_KAFKA_IDENTS_ROL)]
    if len({table for _, table in specs}) != len(specs):
        raise ValueError('Lookup table aliases collide; review environment variables')
    manifest_path = Path(os.getenv('SNAPSHOT_MANIFEST', 'lookup_read_config.json'))
    if manifest_path.exists():
        raise FileExistsError('Choose a new SNAPSHOT_MANIFEST path; existing manifest is preserved')
    p.spark = p.create_spark()
    config = {}
    try:
        for key, table in specs:
            path = root + '/' + version + '/' + key
            # No overwrite: a published version must never change under a replay.
            p.read_jdbc(p.MSSQL_JDBC_HEAD, table).write.mode('errorifexists').parquet(path)
            config[table] = {'path': path}
        # Publish the configuration only when every table export has succeeded.
        with manifest_path.open('x', encoding='utf-8') as handle:
            json.dump(config, handle, ensure_ascii=False, indent=2)
        print(f'Published {len(config)} lookup paths in {manifest_path}')
    finally:
        p.spark.stop()


if __name__ == '__main__':
    main()
