"""Local control-flow tests. No JVM/network; these do not replace Spark integration tests."""
import ast
import os
from pathlib import Path
import types
import unittest
from unittest.mock import MagicMock, patch


def load_pipeline():
    tree = ast.parse(Path(__file__).with_name('prod_refactored.py').read_text(encoding='utf-8'))
    tree.body = [node for node in tree.body if not (
        isinstance(node, ast.ImportFrom) and node.module.startswith('pyspark'))]
    ns = dict(__name__='pipeline_test', DataFrame=object, SparkSession=MagicMock(), Window=MagicMock(),
              StorageLevel=types.SimpleNamespace(DISK_ONLY='DISK_ONLY', MEMORY_AND_DISK='MEMORY_AND_DISK'), F=MagicMock(),
              from_avro=MagicMock())
    with patch.dict(os.environ, {}, clear=True):
        exec(compile(tree, 'prod_refactored.py', 'exec'), ns)
    ns['LOGGER'] = MagicMock()
    return ns


class SafetyTests(unittest.TestCase):
    def setUp(self):
        self.ns = load_pipeline()

    def batch(self, rows=10, invalid_count=0):
        batch = MagicMock()
        batch.persist.return_value = batch
        batch.count.return_value = rows
        batch.agg.return_value.first.return_value = {'rows': rows, 'invalid': invalid_count, 'bytes': rows * 100}
        invalid = MagicMock()
        invalid.count.return_value = invalid_count
        valid = MagicMock()
        business = valid.select.return_value.dropDuplicates.return_value.persist.return_value
        business.count.return_value = rows - invalid_count
        batch.where.side_effect = [invalid, valid]
        self.ns['process_outputs'] = MagicMock()
        return batch, business, invalid

    def test_jdbc_failure_propagates_and_has_no_local_retry(self):
        df = MagicMock()
        writer = df.repartition.return_value.write
        writer.format.return_value = writer
        writer.option.return_value = writer
        writer.mode.return_value = writer
        writer.save.side_effect = RuntimeError('connection lost')
        with self.assertRaisesRegex(RuntimeError, 'connection lost'):
            self.ns['append_jdbc'](df, 'jdbc:test', 'dbo.target', 4, bulk=False)
        writer.save.assert_called_once()
        df.repartition.assert_called_once_with(4)
        self.assertIn(unittest.mock.call('batchsize', 500), writer.option.call_args_list)
        self.assertIn(unittest.mock.call('numPartitions', 4), writer.option.call_args_list)

    def test_empty_batch_releases_cache_without_writing(self):
        batch, _, _ = self.batch(rows=0)
        self.ns['global_process_batch'](batch, 1)
        batch.unpersist.assert_called_with(blocking=True)
        self.ns['process_outputs'].assert_not_called()

    def test_bad_record_fails_before_any_database_write(self):
        batch, _, _ = self.batch(invalid_count=1)
        with self.assertRaisesRegex(RuntimeError, 'invalid messages'):
            self.ns['global_process_batch'](batch, 2)
        self.ns['process_outputs'].assert_not_called()
        batch.unpersist.assert_called_with(blocking=True)

    def test_sink_failure_releases_both_caches_and_propagates(self):
        batch, business, _ = self.batch()
        self.ns['process_outputs'].side_effect = RuntimeError('sink failed')
        with self.assertRaisesRegex(RuntimeError, 'sink failed'):
            self.ns['global_process_batch'](batch, 3)
        batch.unpersist.assert_called_with(blocking=True)
        business.unpersist.assert_called_once_with(blocking=True)

    def test_success_writes_materialized_business_batch(self):
        batch, business, _ = self.batch()
        self.ns['global_process_batch'](batch, 4)
        business.count.assert_called_once()
        self.ns['process_outputs'].assert_called_once_with(business, 4)
        business.unpersist.assert_called_once_with(blocking=True)

    def test_dlq_failure_prevents_database_writes(self):
        self.ns['PARSE_ERROR_MODE'] = 'dlq'
        batch, _, invalid = self.batch(invalid_count=1)
        writer = invalid.select.return_value.write
        writer.format.return_value = writer
        writer.option.return_value = writer
        writer.save.side_effect = RuntimeError('dlq unavailable')
        with self.assertRaisesRegex(RuntimeError, 'dlq unavailable'):
            self.ns['global_process_batch'](batch, 5)
        self.ns['process_outputs'].assert_not_called()
        batch.unpersist.assert_called_with(blocking=True)

    def test_shared_join_caches_released_on_failure(self):
        ns = load_pipeline()
        ns['kafka_IDENTS_msisdn'] = MagicMock()
        ns['expand_identifiers'] = MagicMock(return_value=None)
        first, second = MagicMock(), MagicMock()
        first.persist.return_value = first
        second.persist.return_value = second
        batch = MagicMock()
        batch.join.side_effect = [first, second]
        ns['process_outputs_with_joins'] = MagicMock(side_effect=RuntimeError('sink'))
        with self.assertRaisesRegex(RuntimeError, 'sink'):
            ns['process_outputs'](batch, 6)
        first.unpersist.assert_called_once_with(blocking=True)
        second.unpersist.assert_called_once_with(blocking=True)

    def test_external_schema_requires_explicit_wire_id(self):
        self.ns['READER_SCHEMA_STR'] = '{"type":"record","name":"x","fields":[]}'
        with self.assertRaisesRegex(ValueError, 'EXPECTED_SCHEMA_ID'):
            self.ns['resolve_reader_schema']()
        self.ns['EXPECTED_SCHEMA_ID'] = '42'
        _, schema_id = self.ns['resolve_reader_schema']()
        self.assertEqual(schema_id, 42)

    def test_invalid_limits_rejected(self):
        with patch.dict(os.environ, {'MAX_OFFSETS_PER_TRIGGER': '0'}):
            with self.assertRaises(ValueError):
                self.ns['positive_int']('MAX_OFFSETS_PER_TRIGGER', 10000)

    def test_missing_checkpoint_fails_before_spark_starts(self):
        self.ns['create_spark'] = MagicMock()
        with self.assertRaisesRegex(ValueError, 'CHECKPOINT_LOCATION'):
            self.ns['main']()
        self.ns['create_spark'].assert_not_called()

    def staged_output(self, rows=25):
        df = MagicMock()
        df.columns = ['ID', 'VALUE']
        df.persist.return_value = df
        df.count.return_value = rows
        self.ns['SINK_CONTRACTS']['test'] = df.columns
        self.ns['PIPELINE_ID'] = 'generation-a'
        self.ns['batch_committed'] = MagicMock(return_value=False)
        self.ns['stage_rows'] = MagicMock(return_value=df)
        self.ns['append_jdbc'] = MagicMock()
        self.ns['finalize_batch'] = MagicMock()
        return df

    def write(self, df):
        self.ns['write_mssql'](df, 'jdbc:test', 'dbo.target', batch_id=7, sink_key='test')

    def test_committed_sink_skips_recalculation_and_writes(self):
        df = self.staged_output()
        self.ns['batch_committed'].return_value = True
        self.write(df)
        df.persist.assert_not_called()
        self.ns['append_jdbc'].assert_not_called()
        self.ns['finalize_batch'].assert_not_called()

    def test_staging_failure_never_calls_commit(self):
        df = self.staged_output()
        self.ns['append_jdbc'].side_effect = RuntimeError('stage incomplete')
        with self.assertRaisesRegex(RuntimeError, 'stage incomplete'):
            self.write(df)
        self.ns['finalize_batch'].assert_not_called()
        df.unpersist.assert_called_once_with(blocking=True)

    def test_finalize_failure_propagates_and_frees_output(self):
        df = self.staged_output()
        self.ns['finalize_batch'].side_effect = RuntimeError('commit response lost')
        with self.assertRaisesRegex(RuntimeError, 'response lost'):
            self.write(df)
        self.ns['append_jdbc'].assert_called_once()
        df.unpersist.assert_called_once_with(blocking=True)

    def test_zero_rows_still_commit_without_staging(self):
        df = self.staged_output(rows=0)
        self.write(df)
        self.ns['append_jdbc'].assert_not_called()
        self.assertEqual(self.ns['finalize_batch'].call_args.args[-1], 0)

    def test_attempt_id_shared_between_stage_and_commit(self):
        df = self.staged_output()
        self.write(df)
        stage_attempt = self.ns['stage_rows'].call_args.args[-1]
        self.assertEqual(stage_attempt, self.ns['finalize_batch'].call_args.args[-2])

    def test_output_guard_prevents_jdbc(self):
        df = self.staged_output(rows=self.ns['MAX_OUTPUT_ROWS_PER_SINK'] + 1)
        with self.assertRaisesRegex(RuntimeError, 'safety limit'):
            self.write(df)
        self.ns['append_jdbc'].assert_not_called()
        self.ns['finalize_batch'].assert_not_called()
        df.unpersist.assert_called_once_with(blocking=True)

    def test_writer_count_scales_but_is_bounded(self):
        for rows, expected in [(0, None), (1, 1), (10001, 2), (99999, 4)]:
            with self.subTest(rows=rows):
                df = self.staged_output(rows)
                self.write(df)
                if expected:
                    self.assertEqual(self.ns['append_jdbc'].call_args.args[-1], expected)
                else:
                    self.ns['append_jdbc'].assert_not_called()

    def test_contract_mismatch_fails_before_querying_commits(self):
        df = self.staged_output()
        self.ns['SINK_CONTRACTS']['test'] = ['OTHER']
        with self.assertRaisesRegex(ValueError, 'contract'):
            self.write(df)
        self.ns['batch_committed'].assert_not_called()

    def test_oversized_batch_stops_before_processing(self):
        batch, _, _ = self.batch()
        batch.agg.return_value.first.return_value['bytes'] = self.ns['MAX_BATCH_BYTES'] + 1
        with self.assertRaisesRegex(RuntimeError, 'MAX_BATCH_BYTES'):
            self.ns['global_process_batch'](batch, 8)
        self.ns['process_outputs'].assert_not_called()
        batch.unpersist.assert_called_once_with(blocking=True)

    def test_memory_only_storage_rejected(self):
        with self.assertRaisesRegex(ValueError, 'Only'):
            self.ns['storage_level']('MEMORY_ONLY')

    def test_invalid_sql_identifier_rejected(self):
        with self.assertRaises(ValueError):
            self.ns['sql_identifier']('stage]; DROP TABLE x;--')

    def test_heterogeneous_identifier_fields_use_fallback(self):
        batch = MagicMock()
        schema = {}
        for column, _ in self.ns['IDENT_BRANCHES']:
            field = MagicMock()
            field.dataType.simpleString.return_value = 'string' if column == 'TEL_FROM' else 'bigint'
            schema[column] = field
        batch.schema = schema
        self.assertIsNone(self.ns['expand_identifiers'](batch))
        batch.withColumn.assert_not_called()

    def test_lookup_partitioning_requires_full_configuration(self):
        self.ns['LOOKUP_READ_CONFIG'] = {'t': {'numPartitions': 4}}
        with self.assertRaisesRegex(ValueError, 'requires'):
            self.ns['read_jdbc']('jdbc:test', 't')

    def test_lookup_snapshot_avoids_jdbc(self):
        self.ns['spark'] = MagicMock()
        self.ns['LOOKUP_READ_CONFIG'] = {'t': {'path': 'hdfs:///lookups/version-1/t'}}
        self.ns['read_jdbc']('jdbc:test', 't')
        self.ns['spark'].read.parquet.assert_called_once_with('hdfs:///lookups/version-1/t')
        self.ns['spark'].read.format.assert_not_called()

    def test_append_compatibility_mode_disables_bulk_on_business_table(self):
        df = self.staged_output()
        self.ns['SINK_MODE'] = 'append'
        self.ns['JDBC_BULK_COPY'] = True
        self.write(df)
        self.ns['append_jdbc'].assert_called_once_with(df, 'jdbc:test', 'dbo.target', 1, bulk=False)
        self.ns['finalize_batch'].assert_not_called()

    def control_mock(self):
        connection = MagicMock()
        context = MagicMock()
        context.__enter__.return_value = connection
        self.ns['control_connection'] = MagicMock(return_value=context)
        return connection

    def test_commit_check_binds_parameters_and_closes_result(self):
        connection = self.control_mock()
        self.ns['PIPELINE_ID'] = 'generation-a'
        statement = connection.prepareStatement.return_value
        result = statement.executeQuery.return_value
        result.next.return_value = True
        self.assertTrue(self.ns['batch_committed']('jdbc:test', 'oss', 7))
        sql = connection.prepareStatement.call_args.args[0]
        self.assertNotIn('generation-a', sql)
        statement.setString.assert_any_call(1, 'generation-a')
        statement.setLong.assert_called_once_with(3, 7)
        result.close.assert_called_once()
        statement.close.assert_called_once()

    def test_commit_check_failure_closes_statement(self):
        connection = self.control_mock()
        statement = connection.prepareStatement.return_value
        statement.executeQuery.side_effect = RuntimeError('database unavailable')
        with self.assertRaisesRegex(RuntimeError, 'unavailable'):
            self.ns['batch_committed']('jdbc:test', 'oss', 7)
        statement.close.assert_called_once()

    def test_finalizer_failure_closes_statement(self):
        connection = self.control_mock()
        statement = connection.prepareCall.return_value
        statement.execute.side_effect = RuntimeError('rollback')
        with self.assertRaisesRegex(RuntimeError, 'rollback'):
            self.ns['finalize_batch']('jdbc:test', 'oss', 7, 'attempt', 10)
        statement.close.assert_called_once()

    def test_preflight_rejects_wrong_destination(self):
        connection = self.control_mock()
        self.ns['SINK_SPECS'] = [('oss', 'jdbc:test', 'dbo.expected')]
        result = connection.prepareStatement.return_value.executeQuery.return_value
        result.next.return_value = True
        result.getString.return_value = '[dbo].[wrong]'
        with self.assertRaisesRegex(ValueError, 'mismatched'):
            self.ns['preflight_sinks']()
        result.close.assert_called_once()

    def test_missing_pipeline_identity_fails_before_spark(self):
        self.ns.update(CHECKPOINT_LOCATION='hdfs:///checkpoint', MSSQL_PASSWORD='test',
                       STARTING_OFFSETS='earliest', PIPELINE_ID='')
        self.ns['create_spark'] = MagicMock()
        with self.assertRaisesRegex(ValueError, 'PIPELINE_ID'):
            self.ns['main']()
        self.ns['create_spark'].assert_not_called()


if __name__ == '__main__':
    unittest.main(verbosity=2)
