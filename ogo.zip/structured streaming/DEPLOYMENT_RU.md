# Улучшенная версия: PySpark 4.0.1 / Python 3.10

Код и SQL подготовлены локально. Рабочие Kafka/MSSQL не изменялись.
`prod_refactored.py` теперь по умолчанию использует **SINK_MODE=staged**.
Перед запуском нужно развернуть SQL из каталога `sql` в нужных БД.
Предыдущий режим доступен через `SINK_MODE=append`, с прежним риском дублей при сбое.

## Что улучшено

1. Для одинаковых типов PHONE/IMSI/IMEI шесть join заменены одним для ALARM
   и одним для non-alarm. Разворачивание идентификаторов увеличивает промежуточный
   поток максимум в шесть раз. При разных типах автоматически сохраняется старый
   путь: это предотвращает изменение правил сравнения из-за приведения типов массива.
   Non-alarm distinct остаётся отдельно для каждой исходной ветки; совпадения между
   разными ветками не теряются. ALARM сохраняет все совпадения.
2. Два кэшированных MSISDN join переиспользуются OSS-ветками и GNEZDO.
3. Число строк, ошибок и исходных байтов считается одним aggregate action.
   На драйвер возвращается одна строка агрегатов. Kafka payload освобождается перед
   обработкой бизнес-выходов. Один выход материализуется и освобождается за раз.
4. Для каждого выхода измеряются строки, время и число JDBC writers. Для небольшого
   результата автоматически используется меньше writers, максимум — заданный лимит.
5. Добавлены предзаписные проверки объёма результата и объёма входного batch,
   профилирование повторов ключей справочников, предупреждение о долгом активном batch.
6. Staging допускает повторы задач, процедура отбрасывает технические повторы,
   сохраняет кратность бизнес-строк и фиксирует запись и commit marker транзакционно.
7. Добавлены опциональные Bulk Copy для staging, MEMORY_AND_DISK cache,
   JDBC partitioning справочников и неизменяемые Parquet-снимки.

Эффект ускорения нужно измерить. На маленьких batch управление задачами и MSSQL
могут занимать больше времени, чем сами join. Отключённый broadcast и DISK_ONLY —
консервативные настройки, а не заявление об оптимальной скорости.

## Как работает staging

Для каждой пары `(PIPELINE_ID, sink_key, batch_id)`:

1. Драйвер проверяет commit marker в соответствующей БД. Если он есть, этот выход
   пропускается, включая его вычисление Spark actions.
2. Выход материализуется на executors и проверяется его число строк.
3. Для каждой строки строится SHA-256 от канонического JSON и порядкового номера
   среди одинаковых строк. JSON сохраняет null и микросекунды timestamps. Номера
   одинаковых экземпляров могут назначаться в разном порядке, но множество ключей
   остаётся одинаковым. Используется предположение об отсутствии SHA-256-коллизий.
4. Spark append пишет типизированные строки в `streaming.stage_<sink>` с новым
   `attempt_id`. Неуникальный индекс позволяет повторным попыткам Spark tasks
   вставить те же ключи, не останавливая batch на UNIQUE violation.
5. После успешного завершения Spark write драйвер вызывает `streaming.commit_<sink>`.
   Процедура берёт transaction-owned application lock, повторно проверяет ledger,
   проверяет число разных row keys для **этой попытки**, удаляет технические повторы
   при вставке и транзакционно фиксирует строки, ledger и удаление текущего staging.

Драйвер не получает строки событий. Через JDBC control проходят только контракты,
проверка наличия marker и вызов процедуры. Все значения передаются параметрами;
имена объектов проверяются. Частичная неуспешная попытка не смешивается с новой.
Потерянный ответ после commit приводит к повторной проверке ledger при рестарте.

**Граница гарантий:** это идемпотентная фиксация каждого выхода в его БД, при сохранном
ledger и неизменной идентичности pipeline. Общей транзакции на восемь таблиц/несколько
серверов нет. Некоторое время часть таблиц может содержать batch, а часть — ещё нет.
DLQ Kafka остаётся at-least-once. Это не дедупликация одинаковых Kafka-событий между
разными batch: внутри batch business distinct сохранён, между batch — нет.
Внешние нетранзакционные действия SQL triggers не покрываются этим протоколом.

## Развёртывание SQL

`staging_sql.py` не подключается к БД. Генератор создаёт SQL из имён целевых таблиц
и колонок. Типы не угадываются: при выполнении SQL `SELECT TOP (0) ... INTO`
копирует их из существующей целевой таблицы. Identity/computed/rowversion в списке
выходных колонок запрещены. Исходная бизнес-таблица не изменяется.

| Скрипт | БД подключения при исходных настройках | Целевая таблица |
|---|---|---|
| `sql/oss.sql` | hp-storage9 / TEST | dbo.OSS_KAFKA |
| `sql/idents.sql` | hp-storage9 / SOPR_DB | IDENTS.OSS |
| `sql/alarm.sql` | head2 / HEAD | ALARM.DATA_ALARM_KAFKA |
| `sql/gnezdo.sql` | hp-storage9 / SOPR_DB | ROL.GNEZDO |
| `sql/ruchey.sql` | hp-storage9 / SOPR_DB | TEST.VALDAY |
| `sql/bs_test.sql` | hp-storage9 / SOPR_DB | TEST.BS_TEST |
| `sql/road.sql` | hp-storage9 / SOPR_DB | TEST.ROAD |
| `sql/pulkovo.sql` | hp-storage9 / SOPR_DB | ROL.PULKOVO_POLYGON |

Здесь `[TEST].[ROAD]` — **schema.table в SOPR_DB**, как в исходнике, а не ссылка на
database TEST. Проверьте эту неоднозначность перед развёртыванием.
Для HEAD код использует переменную окружения `MSSQL_JDBC_TARGET_ALARM`.

Если имена отличаются, задайте те же переменные MSSQL_TARGET_* при генерации или
измените manifest и выполните:

```bash
python3.10 staging_sql.py --manifest sql/manifest.json --output sql_reviewed
```

Без `--manifest` генератор читает целевые имена из environment с исходными defaults.
`--schema`/`STAGING_SCHEMA` задаёт схему служебных таблиц. Ключи восьми sink сохраняйте.
Развёртывайте отдельные скрипты в соответствующих БД через SQLCMD с `-b` (остановка
при ошибке); требуется SQL Server 2016 SP1+ для CREATE OR ALTER PROCEDURE.
Проверьте настоящие DDL, обязательные невыводимые колонки, триггеры и ограничения.

Каждая БД получит таблицы `streaming.commits`, `streaming.sinks`, необходимые
`streaming.stage_*` и `streaming.commit_*`. Повторный запуск генератора не меняет
БД. Повторное выполнение SQL не пересоздаёт существующие таблицы, но обновляет
процедуру. Изменение зарегистрированного target/списка колонок блокируется:
для него нужна отдельная миграция. Изменение типов целевой таблицы также требует
проверки/миграции staging, а не простого повторного выполнения SQL.

У runtime-логина должны быть INSERT и необходимый metadata/SELECT-доступ к staging,
SELECT к sinks/commits, EXECUTE к процедурам; цепочку ownership и права целевых
таблиц проверяет DBA. До чтения Kafka приложение проверяет зарегистрированные
таблицы; при формировании выхода — список колонок. Это не полная проверка DDL.

**Не очищайте commits по расписанию**: ledger нужен весь срок возможного replay.
После аварии могут остаться staging rows старых попыток или поздних task retries.
Удаляйте их после остановки pipeline и завершения всех его задач. Не добавлен
автоматический TTL, способный удалить активную загрузку. Для больших объёмов
согласуйте политику архивирования/партиционирования staging и ledger с DBA.

## Запуск и checkpoint

Обязательные параметры launcher:

- `MSSQL_PASSWORD`, `MSSQL_JDBC_JAR`.
- `CHECKPOINT_LOCATION`: отдельный постоянный корень, например
  `hdfs:///apps/billing-v2`; приложение добавляет `/BILLING_V2`.
- `STARTING_OFFSETS`: JSON offsets либо осознанно выбранные earliest/latest.
- `SCHEMA_VERSION`: конкретная версия Registry для воспроизводимых рестартов.
- `PIPELINE_ID`: например `gsm-billing-generation-20260921`. Это **постоянный ID
  поколения checkpoint**, а не UUID каждого запуска. Не меняйте его при рестарте.
  Допустимы 1–128 ASCII букв/цифр и `_.:-`. При новом checkpoint с batch_id,
  снова начинающимся с нуля, нужен новый ID.

Запуск: `bash run_billing.sh`. По умолчанию 48 executor cores, по 4 ядра и 32 GiB
heap на executor, 8 GiB драйверу. Фактическое число executors зависит от worker
топологии. Это старт для доступных 64 ядер/1 ТБ, с резервом ОС/native memory/I/O.
Python 3.10 должен быть доступен на драйвере и всех workers; пути можно задать через
PYSPARK_PYTHON/PYSPARK_DRIVER_PYTHON. Spark/PySpark и Kafka/Avro connectors — 4.0.1,
Scala artifacts — 2.13; Java — совместимая с Spark 4.0.1, например Java 17.

Сервис-менеджер должен перезапускать client-mode драйвер с задержкой, ограничением
частоты и оповещением о повторяющейся ошибке. Постоянно повторять poison batch без
исправления причины бесполезно. Два экземпляра с одним checkpoint запускать нельзя.

После исходной версии со streaming distinct нужен новый checkpoint. Остановите
старую query, определите последний batch с **commit**, перенесите его end offsets
из соответствующего offset log как starting offsets нового поколения. Не берите
offsets запланированного, но не завершённого batch. `latest` на новом checkpoint
пропустит backlog, `earliest` повторит доступную историю. Старый checkpoint сохраните.
Старая версия подавляла ошибки MSSQL, поэтому даже committed batch мог быть неполным.

Переход с предыдущей версии этой доработки (уже stateless BILLING_V2) на staged
лучше выполнять на границе успешно завершённого batch, сохраняя checkpoint.
Для нового staged поколения выберите стабильный PIPELINE_ID; ранее записанные append
данные автоматически в ledger не импортируются. Если предыдущий append batch упал
после частичной записи, его надо сверить перед replay: staging не удалит старые дубли.

**Уже запланированный batch не становится меньше от снижения maxOffsetsPerTrigger.**
Его диапазон сохранён в checkpoint. При повторе такого batch нужен достаточный
ресурс/исправление причины либо отдельно спланированная миграция от последних
committed offsets; не удаляйте checkpoint для обхода ошибки.

## Параметры нагрузки

| Environment | Default | Смысл |
|---|---:|---|
| MAX_OFFSETS_PER_TRIGGER | 10000 | Общий лимит offsets на новый микробатч |
| MAX_RECORDS_PER_PARTITION | 2500 | Дробление чтения Kafka на задачи |
| TRIGGER_INTERVAL | 10 seconds | Интервал запуска, не жёсткий RPS |
| MAX_MESSAGE_BYTES | 1048576 | Проверка длины value перед Avro |
| KAFKA_FETCH_MAX_BYTES | 8388608 | Fetch response лимит с оговорками Kafka |
| KAFKA_PARTITION_FETCH_BYTES | 1048576 | Fetch на партицию |
| MAX_BATCH_BYTES | 268435456 | Предзаписная проверка суммы исходных value |
| MAX_OUTPUT_ROWS_PER_SINK | 1000000 | Предзаписная проверка числа выходных строк |
| JDBC_WRITE_PARTITIONS | 4 | Верхний предел числа writers при нормальном выполнении |
| JDBC_ROWS_PER_PARTITION | 10000 | Ориентир для выбора writers, не размер транзакции |
| JDBC_BATCH_SIZE | 500 | Строки в JDBC executeBatch |
| JDBC_FETCH_SIZE | 1000 | Чтение JDBC справочника |
| JDBC_QUERY_TIMEOUT | 120 s | JDBC statements |
| FINALIZE_TIMEOUT | 600 s | Вызов commit procedure |
| SHUFFLE_PARTITIONS | 128 | Начальный shuffle parallelism |
| COALESCE_SHUFFLE | true | AQE объединяет маленькие batch shuffle partitions |
| LOOKUP_STORAGE_LEVEL | DISK_ONLY | Можно MEMORY_AND_DISK после измерений |
| BATCH_STORAGE_LEVEL | DISK_ONLY | Можно MEMORY_AND_DISK после измерений |
| LOOKUP_PROFILE | true в launcher | Статистика lookup keys перед запуском |
| MAX_LOOKUP_MATCHES | 10000 | Проверка максимальной кратности ненулевого join key |
| STALL_WARN_SECONDS | 300 | Предупреждение о долгом активном batch |
| JDBC_BULK_COPY | false | Опционально true только для staging |
| SESSION_TIMEZONE | Europe/Moscow | Явная зона Spark SQL; согласуйте с исходными данными |

Пределы batch bytes/output rows проверяются **после соответствующего вычисления**:
это защита от опасной записи, не абсолютный лимит пикового heap. Объём результата
может увеличиться из-за повторяющихся lookup keys. MAX_RECORDS_PER_PARTITION
ограничивает записи, не байты и не результат join. Kafka может получить первый
record batch сверх fetch-лимита, чтобы продолжить чтение. Распаковка и декодирование
также требуют памяти. Ограничения producer/broker и разумный размер отдельных
сообщений остаются необходимыми.

JDBC_ROWS_PER_PARTITION выбирает число writers, но при достижении их верхнего
предела транзакция одного writer может оказаться гораздо больше 10 тысяч строк.
Finalization выполняет одну транзакцию на весь выход, поэтому нужны достаточный
transaction log и проверка locks. При перегрузке SQL уменьшайте входной batch.
Speculation отключена, но orphan connections после сетевого сбоя могут временно
увеличить число соединений сверх номинального лимита задач.

Если 21–50 млн строк — backlog/размер прежнего batch, новый source читает порциями.
Если это **один Kafka value**, нужна переработка producer: дробление или ссылки на
файлы. Один offset нельзя разбить maxOffsetsPerTrigger. Приложение предполагает
одну запись CDR в одном Confluent Avro value.

## Справочники и воспроизводимость

По умолчанию справочники лениво читаются JDBC и кэшируются на срок приложения.
Автоматического refresh нет. После потери cache partition данные могут быть
перечитаны из изменившейся БД. Уже committed outputs не повторятся, но ещё не
завершённые выходы могут использовать более свежие справочники. Для одинакового
результата replay используйте замороженные версии.

`snapshot_lookups.py` экспортирует восемь сырых справочников в новый каталог Parquet:
задайте SNAPSHOT_ROOT, новый SNAPSHOT_VERSION, MSSQL_PASSWORD и выполните через
spark-submit с MSSQL JDBC jar. Скрипт требует пустой LOOKUP_READ_CONFIG, не перезаписывает
версии и публикует локальный lookup_read_config.json только после всех успешных exports.
Передайте содержимое этого файла в LOOKUP_READ_CONFIG на driver до запуска pipeline.
Для распределённого deployment модуль prod_refactored.py должен быть доступен driver.

Пример конфигурации одного справочника:

```json
{"dbo.V_KAFKA_IDENTS_MSISDN":{"path":"hdfs:///lookups/version-001/msisdn"}}
```

Для воспроизводимости всех join задайте все восемь путей. Не изменяйте содержимое
опубликованных каталогов и не переключайте версию во время восстановления batch.
Экспорт восьми live tables не даёт единого момента времени между ними: для этого
нужен согласованный snapshot самой БД. Меняйте версии как управляемую операцию
на границе обработки и храните привязку версии к диапазону batch.

Для live JDBC можно вместо path задать partitionColumn, lowerBound, upperBound,
numPartitions. Нужны все четыре поля; число connections ограничено
JDBC_WRITE_PARTITIONS. Bounds определяют разбиение, а не фильтруют таблицу.
Выбирайте столбец и границы по реальному DDL/распределению, не по догадке.

## Avro, DLQ и сохранённая бизнес-логика

Поддерживается один выбранный writer schema ID. Для разных одновременно действующих
версий нужна отдельная схема маршрутизации; выбранный ID не применяется к чужим
payload. При inline/file schema обязателен EXPECTED_SCHEMA_ID. Исторические имена
READER_SCHEMA_* обозначают здесь точную writer schema. Проверяются framing,
ограничение value, schema ID и null/all-null результат PERMISSIVE.

PARSE_ERROR_MODE=fail по умолчанию останавливает batch до MSSQL. Режим dlq пишет
исходный value в ERRORS_TOPIC, metadata и причину — в key; ошибка DLQ останавливает
batch. Kafka DLQ может дублировать сообщения. Tombstones считаются ошибками.
Слишком большой value может не поместиться и в DLQ; нужен отдельный карантинный процесс.

Не менялись спорные исходные правила: not_russian_from сверяется по TEL_TO;
TEST/from берёт IMEI_TO; UID формируется из IDENTIFICATOR; PULKOVO distinct отличается
для направлений. Сами бизнес-категории могут пересекаться. Дедупликация всех результатов
по содержимому нарушила бы их исходную кратность, поэтому в staging сохранены экземпляры.

## Проверка перед production

Локальные unit tests: `python3.10 -m unittest -v test_pipeline_safety test_staging_sql`.
Они проверяют управляющую логику, сбои, resource cleanup, guards и генерацию SQL.

На Spark 4.0.1 + Java тестовом хосте:

```bash
python3.10 -m unittest -v test_spark_integration
```

Шесть тестов выполняют настоящие Spark планы на синтетических данных, сравнивают
мультимножества старых/новых identifier outputs, проверяют смешанные типы, NULL,
кратность, стабильность staging keys и все восемь output schemas. Они не подключаются
к Kafka/MSSQL. Здесь PySpark/JVM отсутствуют, поэтому эти тесты **пропущены**, не пройдены.

`tests/sql/test_protocol.sql` выполняйте с SQLCMD `-b` **в новой отдельной тестовой БД**.
Он создаёт schema billing_protocol_test и проверяет retry задач, повтор commit,
изоляцию попыток, rollback при constraint failure и пустой batch. Уже существующая
test schema запрещена. Скрипт оставляет объекты для проверки, ничего не удаляет.
Здесь он не выполнялся: подключения к SQL Server нет.

Затем проверьте на тестовых Kafka/БД реальный полный путь, типы Avro/JDBC, частичные
сбои, потерю executor и остановку драйвера между stage и commit/после commit.
Сравнивайте содержимое и кратность строк, а не только общее число. Проверьте ledger
каждой таблицы и отсутствие повторных вставок при рестарте с тем же checkpoint.

Для throughput увеличивайте лимит 10000 → 25000 → 50000 → 100000 только после
замеров batch duration, Kafka lag, GC/spill, disks, SQL locks/log. Значение 100000
не является рекомендацией без измерений. Быстрые SSD/NVMe под Spark local dirs
нужны отдельно от постоянного checkpoint. Для разбора аварий сохраняйте Spark event
logs и логи приложения. Не включайте bulk copy, broadcast и большие batch одновременно:
сначала определите эффект каждого изменения на фиксированном наборе данных.

## Источники

- [Spark 4.0.1: Kafka options](https://spark.apache.org/docs/4.0.1/streaming/structured-streaming-kafka-integration.html)
- [Spark 4.0.1: foreachBatch/checkpoint](https://spark.apache.org/docs/4.0.1/streaming/apis-on-dataframes-and-datasets.html)
- [Spark: SQL tuning/AQE](https://spark.apache.org/docs/4.0.1/sql-performance-tuning.html)
- [Microsoft: transaction-owned application locks](https://learn.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sp-getapplock-transact-sql?view=sql-server-ver17)
- [Microsoft: SELECT INTO](https://learn.microsoft.com/en-us/sql/t-sql/queries/select-into-clause-transact-sql?view=sql-server-ver17)
- [Microsoft: JDBC Bulk Copy](https://learn.microsoft.com/en-us/sql/connect/jdbc/use-bulk-copy-api-batch-insert-operation?view=sql-server-ver17)
