-- Run ONLY in a new disposable test database with sqlcmd -b.
-- Leaves test objects for inspection; does not drop or overwrite anything.
IF SCHEMA_ID('billing_protocol_test') IS NOT NULL
    THROW 51999, 'Test schema already exists; choose a fresh disposable database', 1;
EXEC('CREATE SCHEMA billing_protocol_test');
GO
CREATE TABLE billing_protocol_test.target ([ID] int NOT NULL CHECK ([ID]>0), [VALUE] nvarchar(50) NULL);
GO
-- Sink fixture; deploy in the database selected by DISPOSABLE TEST DATABASE ONLY.
-- Review target, indexes, transaction-log capacity and permissions before running.
-- Generated offline. This script does not alter the existing business table.
SET NOCOUNT ON;
SET XACT_ABORT ON;
IF SCHEMA_ID(N'billing_protocol_test') IS NULL EXEC('CREATE SCHEMA [billing_protocol_test]');
GO
IF OBJECT_ID('[billing_protocol_test].[commits]', 'U') IS NULL
    CREATE TABLE [billing_protocol_test].[commits] (
        pipeline_id nvarchar(128) COLLATE Latin1_General_100_BIN2 NOT NULL,
        sink_key varchar(64) COLLATE Latin1_General_100_BIN2 NOT NULL,
        batch_id bigint NOT NULL,
        row_count bigint NOT NULL,
        committed_at datetime2(7) NOT NULL DEFAULT SYSUTCDATETIME(),
        PRIMARY KEY (pipeline_id, sink_key, batch_id)
    );
IF OBJECT_ID('[billing_protocol_test].[sinks]', 'U') IS NULL
    CREATE TABLE [billing_protocol_test].[sinks] (
        sink_key varchar(64) COLLATE Latin1_General_100_BIN2 NOT NULL PRIMARY KEY,
        target_table nvarchar(260) NOT NULL,
        column_names nvarchar(max) NOT NULL
    );
IF OBJECT_ID(N'[billing_protocol_test].[target]', 'U') IS NULL
    THROW 51000, 'Target must be an existing user table in this database', 1;
IF COL_LENGTH(N'[billing_protocol_test].[target]', N'ID') IS NULL
    THROW 51000, 'Missing target column: ID', 1;
IF COL_LENGTH(N'[billing_protocol_test].[target]', N'VALUE') IS NULL
    THROW 51000, 'Missing target column: VALUE', 1;
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID(N'[billing_protocol_test].[target]')
           AND name IN (N'ID', N'VALUE')
           AND (is_identity=1 OR is_computed=1 OR system_type_id=189))
    THROW 51000, 'Output may not target identity, computed or rowversion columns', 1;
IF EXISTS (SELECT 1 FROM [billing_protocol_test].[sinks] WHERE sink_key='fixture'
           AND (target_table<>N'[billing_protocol_test].[target]' OR column_names<>N'["ID","VALUE"]'))
    THROW 51000, 'Sink contract already differs: use a reviewed schema migration', 1;
IF OBJECT_ID('[billing_protocol_test].[stage_fixture]', 'U') IS NULL
BEGIN
    -- Join prevents accidental inheritance of an identity attribute.
    SELECT TOP (0) t.[ID], t.[VALUE]
    INTO [billing_protocol_test].[stage_fixture] FROM [billing_protocol_test].[target] AS t CROSS JOIN (SELECT 1 AS n) AS seed;
    ALTER TABLE [billing_protocol_test].[stage_fixture] ADD
        _ss_pipeline_id nvarchar(128) COLLATE Latin1_General_100_BIN2 NOT NULL,
        _ss_batch_id bigint NOT NULL,
        _ss_attempt_id varchar(36) COLLATE Latin1_General_100_BIN2 NOT NULL,
        _ss_row_key varchar(64) COLLATE Latin1_General_100_BIN2 NOT NULL,
        _ss_staged_at datetime2(7) NOT NULL DEFAULT SYSUTCDATETIME();
    -- NON-unique: Spark task retries are allowed to append the same row key.
    CREATE INDEX [ix_stage_fixture] ON [billing_protocol_test].[stage_fixture]
        (_ss_pipeline_id, _ss_batch_id, _ss_attempt_id, _ss_row_key);
END;
IF NOT EXISTS (SELECT 1 FROM [billing_protocol_test].[sinks] WHERE sink_key='fixture')
    INSERT INTO [billing_protocol_test].[sinks] (sink_key, target_table, column_names)
    VALUES ('fixture', N'[billing_protocol_test].[target]', N'["ID","VALUE"]');
GO
CREATE OR ALTER PROCEDURE [billing_protocol_test].[commit_fixture]
    @pipeline_id nvarchar(128),
    @batch_id bigint,
    @attempt_id varchar(36),
    @expected_rows bigint
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF @pipeline_id IS NULL OR LEN(@pipeline_id)=0 OR @batch_id IS NULL OR @batch_id<0
       OR @expected_rows IS NULL OR @expected_rows<0 OR @attempt_id IS NULL OR LEN(@attempt_id)<>36
        THROW 51001, 'Invalid commit arguments', 1;
    BEGIN TRY
        BEGIN TRANSACTION;
        DECLARE @lock_result int;
        DECLARE @resource nvarchar(255) = N'billing:fixture:' +
            CONVERT(varchar(64), HASHBYTES('SHA2_256', @pipeline_id), 2) + N':' +
            CONVERT(nvarchar(20), @batch_id);
        EXEC @lock_result = sys.sp_getapplock
            @Resource=@resource, @LockMode='Exclusive', @LockOwner='Transaction',
            @LockTimeout=30000;
        IF @lock_result < 0 THROW 51002, 'Could not obtain sink commit lock', 1;
        IF EXISTS (SELECT 1 FROM [billing_protocol_test].[commits]
                   WHERE pipeline_id=@pipeline_id AND sink_key='fixture' AND batch_id=@batch_id)
        BEGIN
            COMMIT TRANSACTION;
            RETURN;
        END;
        DECLARE @actual_rows bigint;
        SELECT @actual_rows=COUNT_BIG(DISTINCT _ss_row_key)
        FROM [billing_protocol_test].[stage_fixture]
        WHERE _ss_pipeline_id=@pipeline_id AND _ss_batch_id=@batch_id
              AND _ss_attempt_id=@attempt_id;
        IF @actual_rows<>@expected_rows
            THROW 51003, 'Incomplete stage or inconsistent row keys; target not committed', 1;
        ;WITH deduplicated AS (
            SELECT [ID], [VALUE], ROW_NUMBER() OVER (
                PARTITION BY _ss_row_key ORDER BY _ss_row_key) AS _ss_rn
            FROM [billing_protocol_test].[stage_fixture]
            WHERE _ss_pipeline_id=@pipeline_id AND _ss_batch_id=@batch_id
                  AND _ss_attempt_id=@attempt_id
        )
        INSERT INTO [billing_protocol_test].[target] ([ID], [VALUE])
        SELECT [ID], [VALUE] FROM deduplicated WHERE _ss_rn=1;
        IF CONVERT(bigint, @@ROWCOUNT)<>@expected_rows
            THROW 51004, 'Inserted count differs from expected; rollback', 1;
        INSERT INTO [billing_protocol_test].[commits] (pipeline_id, sink_key, batch_id, row_count)
        VALUES (@pipeline_id, 'fixture', @batch_id, @expected_rows);
        DELETE FROM [billing_protocol_test].[stage_fixture] WHERE _ss_pipeline_id=@pipeline_id AND _ss_batch_id=@batch_id
                                 AND _ss_attempt_id=@attempt_id;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO
-- Runtime principal needs INSERT on staging, SELECT on sinks/commits and EXECUTE
-- on this procedure. Review ownership chaining/target permissions with your DBA.
-- Retain commits for the full checkpoint replay lifetime. Do not routinely purge them.
-- Orphan attempts: clean only while this pipeline is stopped and no tasks can retry.

DECLARE @pipeline nvarchar(128)=N'test-generation';
DECLARE @attempt varchar(36)='00000000-0000-0000-0000-000000000001';
-- Two legitimate identical rows have DIFFERENT keys; task retries repeat SAME keys.
INSERT billing_protocol_test.stage_fixture
([ID],[VALUE],_ss_pipeline_id,_ss_batch_id,_ss_attempt_id,_ss_row_key)
VALUES (1,N'value',@pipeline,1,@attempt,REPLICATE('a',64)),
       (1,N'value',@pipeline,1,@attempt,REPLICATE('b',64)),
       (1,N'value',@pipeline,1,@attempt,REPLICATE('a',64)),
       (1,N'value',@pipeline,1,@attempt,REPLICATE('b',64));
EXEC billing_protocol_test.commit_fixture @pipeline,1,@attempt,2;
IF (SELECT COUNT(*) FROM billing_protocol_test.target)<>2 THROW 51999,'Retry duplicates not removed',1;
-- Lost commit acknowledgement: repeat call must not append anything.
EXEC billing_protocol_test.commit_fixture @pipeline,1,@attempt,2;
IF (SELECT COUNT(*) FROM billing_protocol_test.target)<>2 THROW 51999,'Repeated commit duplicated target',1;
-- A prior attempt with partial rows must not contaminate a new attempt.
INSERT billing_protocol_test.stage_fixture
([ID],[VALUE],_ss_pipeline_id,_ss_batch_id,_ss_attempt_id,_ss_row_key)
VALUES (2,N'old attempt',@pipeline,2,@attempt,REPLICATE('c',64));
DECLARE @second varchar(36)='00000000-0000-0000-0000-000000000002';
BEGIN TRY
    EXEC billing_protocol_test.commit_fixture @pipeline,2,@second,1;
    THROW 51999,'Incomplete attempt was accepted',1;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51003 THROW;
END CATCH;
IF EXISTS(SELECT 1 FROM billing_protocol_test.commits WHERE batch_id=2)
    THROW 51999,'Incomplete attempt got a commit marker',1;
-- Target constraint failure must roll back both data and ledger.
INSERT billing_protocol_test.stage_fixture
([ID],[VALUE],_ss_pipeline_id,_ss_batch_id,_ss_attempt_id,_ss_row_key)
VALUES (-1,N'bad',@pipeline,3,@attempt,REPLICATE('d',64));
BEGIN TRY
    EXEC billing_protocol_test.commit_fixture @pipeline,3,@attempt,1;
    THROW 51999,'Target constraint failure was hidden',1;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>547 THROW;
END CATCH;
IF EXISTS(SELECT 1 FROM billing_protocol_test.commits WHERE batch_id=3)
    THROW 51999,'Failed target insert got a commit marker',1;
IF (SELECT COUNT(*) FROM billing_protocol_test.target)<>2 THROW 51999,'Failed transaction changed target',1;
-- Empty output must still be durable/idempotent.
EXEC billing_protocol_test.commit_fixture @pipeline,4,@attempt,0;
IF NOT EXISTS(SELECT 1 FROM billing_protocol_test.commits WHERE batch_id=4 AND row_count=0)
    THROW 51999,'Empty batch not committed',1;
PRINT 'Protocol tests passed: task retry, commit retry, attempt isolation, rollback, empty batch.';
GO
