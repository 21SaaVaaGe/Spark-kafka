-- Sink bs_test; deploy in the database selected by MSSQL_JDBC_URL_IDENTS_TARGET.
-- Review target, indexes, transaction-log capacity and permissions before running.
-- Generated offline. This script does not alter the existing business table.
SET NOCOUNT ON;
SET XACT_ABORT ON;
IF SCHEMA_ID(N'streaming') IS NULL EXEC('CREATE SCHEMA [streaming]');
GO
IF OBJECT_ID('[streaming].[commits]', 'U') IS NULL
    CREATE TABLE [streaming].[commits] (
        pipeline_id nvarchar(128) COLLATE Latin1_General_100_BIN2 NOT NULL,
        sink_key varchar(64) COLLATE Latin1_General_100_BIN2 NOT NULL,
        batch_id bigint NOT NULL,
        row_count bigint NOT NULL,
        committed_at datetime2(7) NOT NULL DEFAULT SYSUTCDATETIME(),
        PRIMARY KEY (pipeline_id, sink_key, batch_id)
    );
IF OBJECT_ID('[streaming].[sinks]', 'U') IS NULL
    CREATE TABLE [streaming].[sinks] (
        sink_key varchar(64) COLLATE Latin1_General_100_BIN2 NOT NULL PRIMARY KEY,
        target_table nvarchar(260) NOT NULL,
        column_names nvarchar(max) NOT NULL
    );
IF OBJECT_ID(N'[TEST].[BS_TEST]', 'U') IS NULL
    THROW 51000, 'Target must be an existing user table in this database', 1;
IF COL_LENGTH(N'[TEST].[BS_TEST]', N'ID') IS NULL
    THROW 51000, 'Missing target column: ID', 1;
IF COL_LENGTH(N'[TEST].[BS_TEST]', N'IMSI') IS NULL
    THROW 51000, 'Missing target column: IMSI', 1;
IF COL_LENGTH(N'[TEST].[BS_TEST]', N'IMEI') IS NULL
    THROW 51000, 'Missing target column: IMEI', 1;
IF COL_LENGTH(N'[TEST].[BS_TEST]', N'TYPE') IS NULL
    THROW 51000, 'Missing target column: TYPE', 1;
IF COL_LENGTH(N'[TEST].[BS_TEST]', N'REMARK') IS NULL
    THROW 51000, 'Missing target column: REMARK', 1;
IF COL_LENGTH(N'[TEST].[BS_TEST]', N'DATE_TIME') IS NULL
    THROW 51000, 'Missing target column: DATE_TIME', 1;
IF COL_LENGTH(N'[TEST].[BS_TEST]', N'CODE') IS NULL
    THROW 51000, 'Missing target column: CODE', 1;
IF COL_LENGTH(N'[TEST].[BS_TEST]', N'LAC') IS NULL
    THROW 51000, 'Missing target column: LAC', 1;
IF COL_LENGTH(N'[TEST].[BS_TEST]', N'CELLID') IS NULL
    THROW 51000, 'Missing target column: CELLID', 1;
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID(N'[TEST].[BS_TEST]')
           AND name IN (N'ID', N'IMSI', N'IMEI', N'TYPE', N'REMARK', N'DATE_TIME', N'CODE', N'LAC', N'CELLID')
           AND (is_identity=1 OR is_computed=1 OR system_type_id=189))
    THROW 51000, 'Output may not target identity, computed or rowversion columns', 1;
IF EXISTS (SELECT 1 FROM [streaming].[sinks] WHERE sink_key='bs_test'
           AND (target_table<>N'[TEST].[BS_TEST]' OR column_names<>N'["ID","IMSI","IMEI","TYPE","REMARK","DATE_TIME","CODE","LAC","CELLID"]'))
    THROW 51000, 'Sink contract already differs: use a reviewed schema migration', 1;
IF OBJECT_ID('[streaming].[stage_bs_test]', 'U') IS NULL
BEGIN
    -- Join prevents accidental inheritance of an identity attribute.
    SELECT TOP (0) t.[ID], t.[IMSI], t.[IMEI], t.[TYPE], t.[REMARK], t.[DATE_TIME], t.[CODE], t.[LAC], t.[CELLID]
    INTO [streaming].[stage_bs_test] FROM [TEST].[BS_TEST] AS t CROSS JOIN (SELECT 1 AS n) AS seed;
    ALTER TABLE [streaming].[stage_bs_test] ADD
        _ss_pipeline_id nvarchar(128) COLLATE Latin1_General_100_BIN2 NOT NULL,
        _ss_batch_id bigint NOT NULL,
        _ss_attempt_id varchar(36) COLLATE Latin1_General_100_BIN2 NOT NULL,
        _ss_row_key varchar(64) COLLATE Latin1_General_100_BIN2 NOT NULL,
        _ss_staged_at datetime2(7) NOT NULL DEFAULT SYSUTCDATETIME();
    -- NON-unique: Spark task retries are allowed to append the same row key.
    CREATE INDEX [ix_stage_bs_test] ON [streaming].[stage_bs_test]
        (_ss_pipeline_id, _ss_batch_id, _ss_attempt_id, _ss_row_key);
END;
IF NOT EXISTS (SELECT 1 FROM [streaming].[sinks] WHERE sink_key='bs_test')
    INSERT INTO [streaming].[sinks] (sink_key, target_table, column_names)
    VALUES ('bs_test', N'[TEST].[BS_TEST]', N'["ID","IMSI","IMEI","TYPE","REMARK","DATE_TIME","CODE","LAC","CELLID"]');
GO
CREATE OR ALTER PROCEDURE [streaming].[commit_bs_test]
    @pipeline_id nvarchar(128),
    @batch_id bigint,
    @attempt_id varchar(36),
    @expected_rows bigint
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF @pipeline_id IS NULL OR LEN(@pipeline_id)=0 OR @batch_id IS NULL OR @batch_id<0
       OR @expected_rows IS NULL OR @expected_rows<0 OR @attempt_id IS NULL OR LEN(@attempt_id)<>36
        THROW 51001, 'Invalid commit arguments', 1;
    BEGIN TRY
        BEGIN TRANSACTION;
        DECLARE @lock_result int;
        DECLARE @resource nvarchar(255) = N'billing:bs_test:' +
            CONVERT(varchar(64), HASHBYTES('SHA2_256', @pipeline_id), 2) + N':' +
            CONVERT(nvarchar(20), @batch_id);
        EXEC @lock_result = sys.sp_getapplock
            @Resource=@resource, @LockMode='Exclusive', @LockOwner='Transaction',
            @LockTimeout=30000;
        IF @lock_result < 0 THROW 51002, 'Could not obtain sink commit lock', 1;
        IF EXISTS (SELECT 1 FROM [streaming].[commits]
                   WHERE pipeline_id=@pipeline_id AND sink_key='bs_test' AND batch_id=@batch_id)
        BEGIN
            COMMIT TRANSACTION;
            RETURN;
        END;
        DECLARE @actual_rows bigint;
        SELECT @actual_rows=COUNT_BIG(DISTINCT _ss_row_key)
        FROM [streaming].[stage_bs_test]
        WHERE _ss_pipeline_id=@pipeline_id AND _ss_batch_id=@batch_id
              AND _ss_attempt_id=@attempt_id;
        IF @actual_rows<>@expected_rows
            THROW 51003, 'Incomplete stage or inconsistent row keys; target not committed', 1;
        ;WITH deduplicated AS (
            SELECT [ID], [IMSI], [IMEI], [TYPE], [REMARK], [DATE_TIME], [CODE], [LAC], [CELLID], ROW_NUMBER() OVER (
                PARTITION BY _ss_row_key ORDER BY _ss_row_key) AS _ss_rn
            FROM [streaming].[stage_bs_test]
            WHERE _ss_pipeline_id=@pipeline_id AND _ss_batch_id=@batch_id
                  AND _ss_attempt_id=@attempt_id
        )
        INSERT INTO [TEST].[BS_TEST] ([ID], [IMSI], [IMEI], [TYPE], [REMARK], [DATE_TIME], [CODE], [LAC], [CELLID])
        SELECT [ID], [IMSI], [IMEI], [TYPE], [REMARK], [DATE_TIME], [CODE], [LAC], [CELLID] FROM deduplicated WHERE _ss_rn=1;
        IF CONVERT(bigint, @@ROWCOUNT)<>@expected_rows
            THROW 51004, 'Inserted count differs from expected; rollback', 1;
        INSERT INTO [streaming].[commits] (pipeline_id, sink_key, batch_id, row_count)
        VALUES (@pipeline_id, 'bs_test', @batch_id, @expected_rows);
        DELETE FROM [streaming].[stage_bs_test] WHERE _ss_pipeline_id=@pipeline_id AND _ss_batch_id=@batch_id
                                 AND _ss_attempt_id=@attempt_id;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO
-- Runtime principal needs INSERT on staging, SELECT on sinks/commits and EXECUTE
-- on this procedure. Review ownership chaining/target permissions with your DBA.
-- Retain commits for the full checkpoint replay lifetime. Do not routinely purge them.
-- Orphan attempts: clean only while this pipeline is stopped and no tasks can retry.
