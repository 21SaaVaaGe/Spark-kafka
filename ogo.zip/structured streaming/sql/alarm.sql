-- Sink alarm; deploy in the database selected by MSSQL_JDBC_HEAD.
-- Review target, indexes, transaction-log capacity and permissions before running.
-- Generated offline. This script does not alter the existing business table.
SET NOCOUNT ON;
SET XACT_ABORT ON;
IF SCHEMA_ID(N'streaming') IS NULL EXEC('CREATE SCHEMA [streaming]');
GO
IF OBJECT_ID('[streaming].[commits]', 'U') IS NULL
    CREATE TABLE [streaming].[commits] (
        pipeline_id nvarchar(128) COLLATE Latin1_General_100_BIN2 NOT NULL,
        sink_key varchar(64) COLLATE Latin1_General_100_BIN2 NOT NULL,
        batch_id bigint NOT NULL,
        row_count bigint NOT NULL,
        committed_at datetime2(7) NOT NULL DEFAULT SYSUTCDATETIME(),
        PRIMARY KEY (pipeline_id, sink_key, batch_id)
    );
IF OBJECT_ID('[streaming].[sinks]', 'U') IS NULL
    CREATE TABLE [streaming].[sinks] (
        sink_key varchar(64) COLLATE Latin1_General_100_BIN2 NOT NULL PRIMARY KEY,
        target_table nvarchar(260) NOT NULL,
        column_names nvarchar(max) NOT NULL
    );
IF OBJECT_ID(N'[ALARM].[DATA_ALARM_KAFKA]', 'U') IS NULL
    THROW 51000, 'Target must be an existing user table in this database', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'DATE_TIME') IS NULL
    THROW 51000, 'Missing target column: DATE_TIME', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'DURATION') IS NULL
    THROW 51000, 'Missing target column: DURATION', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'CALL_TYPE') IS NULL
    THROW 51000, 'Missing target column: CALL_TYPE', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'TEL_FROM') IS NULL
    THROW 51000, 'Missing target column: TEL_FROM', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'IMSI_FROM') IS NULL
    THROW 51000, 'Missing target column: IMSI_FROM', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'IMEI_FROM') IS NULL
    THROW 51000, 'Missing target column: IMEI_FROM', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'ID_FROM') IS NULL
    THROW 51000, 'Missing target column: ID_FROM', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'TEL_TO') IS NULL
    THROW 51000, 'Missing target column: TEL_TO', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'MSRN') IS NULL
    THROW 51000, 'Missing target column: MSRN', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'IMSI_TO') IS NULL
    THROW 51000, 'Missing target column: IMSI_TO', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'IMEI_TO') IS NULL
    THROW 51000, 'Missing target column: IMEI_TO', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'ID_TO') IS NULL
    THROW 51000, 'Missing target column: ID_TO', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'CODE_FROM') IS NULL
    THROW 51000, 'Missing target column: CODE_FROM', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'MCC_FROM') IS NULL
    THROW 51000, 'Missing target column: MCC_FROM', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'MNC_FROM') IS NULL
    THROW 51000, 'Missing target column: MNC_FROM', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'LAC_FROM') IS NULL
    THROW 51000, 'Missing target column: LAC_FROM', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'CELLID_FROM') IS NULL
    THROW 51000, 'Missing target column: CELLID_FROM', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'CODE_TO') IS NULL
    THROW 51000, 'Missing target column: CODE_TO', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'MCC_TO') IS NULL
    THROW 51000, 'Missing target column: MCC_TO', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'MNC_TO') IS NULL
    THROW 51000, 'Missing target column: MNC_TO', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'LAC_TO') IS NULL
    THROW 51000, 'Missing target column: LAC_TO', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'CELLID_TO') IS NULL
    THROW 51000, 'Missing target column: CELLID_TO', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'SERVICE_CENTER_FROM') IS NULL
    THROW 51000, 'Missing target column: SERVICE_CENTER_FROM', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'SERVICE_CENTER_TO') IS NULL
    THROW 51000, 'Missing target column: SERVICE_CENTER_TO', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'MSG') IS NULL
    THROW 51000, 'Missing target column: MSG', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'UID') IS NULL
    THROW 51000, 'Missing target column: UID', 1;
IF COL_LENGTH(N'[ALARM].[DATA_ALARM_KAFKA]', N'THEME') IS NULL
    THROW 51000, 'Missing target column: THEME', 1;
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID(N'[ALARM].[DATA_ALARM_KAFKA]')
           AND name IN (N'DATE_TIME', N'DURATION', N'CALL_TYPE', N'TEL_FROM', N'IMSI_FROM', N'IMEI_FROM', N'ID_FROM', N'TEL_TO', N'MSRN', N'IMSI_TO', N'IMEI_TO', N'ID_TO', N'CODE_FROM', N'MCC_FROM', N'MNC_FROM', N'LAC_FROM', N'CELLID_FROM', N'CODE_TO', N'MCC_TO', N'MNC_TO', N'LAC_TO', N'CELLID_TO', N'SERVICE_CENTER_FROM', N'SERVICE_CENTER_TO', N'MSG', N'UID', N'THEME')
           AND (is_identity=1 OR is_computed=1 OR system_type_id=189))
    THROW 51000, 'Output may not target identity, computed or rowversion columns', 1;
IF EXISTS (SELECT 1 FROM [streaming].[sinks] WHERE sink_key='alarm'
           AND (target_table<>N'[ALARM].[DATA_ALARM_KAFKA]' OR column_names<>N'["DATE_TIME","DURATION","CALL_TYPE","TEL_FROM","IMSI_FROM","IMEI_FROM","ID_FROM","TEL_TO","MSRN","IMSI_TO","IMEI_TO","ID_TO","CODE_FROM","MCC_FROM","MNC_FROM","LAC_FROM","CELLID_FROM","CODE_TO","MCC_TO","MNC_TO","LAC_TO","CELLID_TO","SERVICE_CENTER_FROM","SERVICE_CENTER_TO","MSG","UID","THEME"]'))
    THROW 51000, 'Sink contract already differs: use a reviewed schema migration', 1;
IF OBJECT_ID('[streaming].[stage_alarm]', 'U') IS NULL
BEGIN
    -- Join prevents accidental inheritance of an identity attribute.
    SELECT TOP (0) t.[DATE_TIME], t.[DURATION], t.[CALL_TYPE], t.[TEL_FROM], t.[IMSI_FROM], t.[IMEI_FROM], t.[ID_FROM], t.[TEL_TO], t.[MSRN], t.[IMSI_TO], t.[IMEI_TO], t.[ID_TO], t.[CODE_FROM], t.[MCC_FROM], t.[MNC_FROM], t.[LAC_FROM], t.[CELLID_FROM], t.[CODE_TO], t.[MCC_TO], t.[MNC_TO], t.[LAC_TO], t.[CELLID_TO], t.[SERVICE_CENTER_FROM], t.[SERVICE_CENTER_TO], t.[MSG], t.[UID], t.[THEME]
    INTO [streaming].[stage_alarm] FROM [ALARM].[DATA_ALARM_KAFKA] AS t CROSS JOIN (SELECT 1 AS n) AS seed;
    ALTER TABLE [streaming].[stage_alarm] ADD
        _ss_pipeline_id nvarchar(128) COLLATE Latin1_General_100_BIN2 NOT NULL,
        _ss_batch_id bigint NOT NULL,
        _ss_attempt_id varchar(36) COLLATE Latin1_General_100_BIN2 NOT NULL,
        _ss_row_key varchar(64) COLLATE Latin1_General_100_BIN2 NOT NULL,
        _ss_staged_at datetime2(7) NOT NULL DEFAULT SYSUTCDATETIME();
    -- NON-unique: Spark task retries are allowed to append the same row key.
    CREATE INDEX [ix_stage_alarm] ON [streaming].[stage_alarm]
        (_ss_pipeline_id, _ss_batch_id, _ss_attempt_id, _ss_row_key);
END;
IF NOT EXISTS (SELECT 1 FROM [streaming].[sinks] WHERE sink_key='alarm')
    INSERT INTO [streaming].[sinks] (sink_key, target_table, column_names)
    VALUES ('alarm', N'[ALARM].[DATA_ALARM_KAFKA]', N'["DATE_TIME","DURATION","CALL_TYPE","TEL_FROM","IMSI_FROM","IMEI_FROM","ID_FROM","TEL_TO","MSRN","IMSI_TO","IMEI_TO","ID_TO","CODE_FROM","MCC_FROM","MNC_FROM","LAC_FROM","CELLID_FROM","CODE_TO","MCC_TO","MNC_TO","LAC_TO","CELLID_TO","SERVICE_CENTER_FROM","SERVICE_CENTER_TO","MSG","UID","THEME"]');
GO
CREATE OR ALTER PROCEDURE [streaming].[commit_alarm]
    @pipeline_id nvarchar(128),
    @batch_id bigint,
    @attempt_id varchar(36),
    @expected_rows bigint
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF @pipeline_id IS NULL OR LEN(@pipeline_id)=0 OR @batch_id IS NULL OR @batch_id<0
       OR @expected_rows IS NULL OR @expected_rows<0 OR @attempt_id IS NULL OR LEN(@attempt_id)<>36
        THROW 51001, 'Invalid commit arguments', 1;
    BEGIN TRY
        BEGIN TRANSACTION;
        DECLARE @lock_result int;
        DECLARE @resource nvarchar(255) = N'billing:alarm:' +
            CONVERT(varchar(64), HASHBYTES('SHA2_256', @pipeline_id), 2) + N':' +
            CONVERT(nvarchar(20), @batch_id);
        EXEC @lock_result = sys.sp_getapplock
            @Resource=@resource, @LockMode='Exclusive', @LockOwner='Transaction',
            @LockTimeout=30000;
        IF @lock_result < 0 THROW 51002, 'Could not obtain sink commit lock', 1;
        IF EXISTS (SELECT 1 FROM [streaming].[commits]
                   WHERE pipeline_id=@pipeline_id AND sink_key='alarm' AND batch_id=@batch_id)
        BEGIN
            COMMIT TRANSACTION;
            RETURN;
        END;
        DECLARE @actual_rows bigint;
        SELECT @actual_rows=COUNT_BIG(DISTINCT _ss_row_key)
        FROM [streaming].[stage_alarm]
        WHERE _ss_pipeline_id=@pipeline_id AND _ss_batch_id=@batch_id
              AND _ss_attempt_id=@attempt_id;
        IF @actual_rows<>@expected_rows
            THROW 51003, 'Incomplete stage or inconsistent row keys; target not committed', 1;
        ;WITH deduplicated AS (
            SELECT [DATE_TIME], [DURATION], [CALL_TYPE], [TEL_FROM], [IMSI_FROM], [IMEI_FROM], [ID_FROM], [TEL_TO], [MSRN], [IMSI_TO], [IMEI_TO], [ID_TO], [CODE_FROM], [MCC_FROM], [MNC_FROM], [LAC_FROM], [CELLID_FROM], [CODE_TO], [MCC_TO], [MNC_TO], [LAC_TO], [CELLID_TO], [SERVICE_CENTER_FROM], [SERVICE_CENTER_TO], [MSG], [UID], [THEME], ROW_NUMBER() OVER (
                PARTITION BY _ss_row_key ORDER BY _ss_row_key) AS _ss_rn
            FROM [streaming].[stage_alarm]
            WHERE _ss_pipeline_id=@pipeline_id AND _ss_batch_id=@batch_id
                  AND _ss_attempt_id=@attempt_id
        )
        INSERT INTO [ALARM].[DATA_ALARM_KAFKA] ([DATE_TIME], [DURATION], [CALL_TYPE], [TEL_FROM], [IMSI_FROM], [IMEI_FROM], [ID_FROM], [TEL_TO], [MSRN], [IMSI_TO], [IMEI_TO], [ID_TO], [CODE_FROM], [MCC_FROM], [MNC_FROM], [LAC_FROM], [CELLID_FROM], [CODE_TO], [MCC_TO], [MNC_TO], [LAC_TO], [CELLID_TO], [SERVICE_CENTER_FROM], [SERVICE_CENTER_TO], [MSG], [UID], [THEME])
        SELECT [DATE_TIME], [DURATION], [CALL_TYPE], [TEL_FROM], [IMSI_FROM], [IMEI_FROM], [ID_FROM], [TEL_TO], [MSRN], [IMSI_TO], [IMEI_TO], [ID_TO], [CODE_FROM], [MCC_FROM], [MNC_FROM], [LAC_FROM], [CELLID_FROM], [CODE_TO], [MCC_TO], [MNC_TO], [LAC_TO], [CELLID_TO], [SERVICE_CENTER_FROM], [SERVICE_CENTER_TO], [MSG], [UID], [THEME] FROM deduplicated WHERE _ss_rn=1;
        IF CONVERT(bigint, @@ROWCOUNT)<>@expected_rows
            THROW 51004, 'Inserted count differs from expected; rollback', 1;
        INSERT INTO [streaming].[commits] (pipeline_id, sink_key, batch_id, row_count)
        VALUES (@pipeline_id, 'alarm', @batch_id, @expected_rows);
        DELETE FROM [streaming].[stage_alarm] WHERE _ss_pipeline_id=@pipeline_id AND _ss_batch_id=@batch_id
                                 AND _ss_attempt_id=@attempt_id;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO
-- Runtime principal needs INSERT on staging, SELECT on sinks/commits and EXECUTE
-- on this procedure. Review ownership chaining/target permissions with your DBA.
-- Retain commits for the full checkpoint replay lifetime. Do not routinely purge them.
-- Orphan attempts: clean only while this pipeline is stopped and no tasks can retry.
