"""Run explicitly on a Spark 4.0.1 + Java host: python3.10 -m unittest -v test_spark_integration.

No Kafka/MSSQL access. Executes real Spark expressions on synthetic data.
"""
from datetime import datetime
from functools import reduce
import importlib.util
import unittest

HAS_SPARK = importlib.util.find_spec('pyspark') is not None


@unittest.skipUnless(HAS_SPARK, 'PySpark/JVM required; run on the Spark test host')
class SparkRegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import prod_refactored as p
        from pyspark.sql import SparkSession
        cls.p = p
        cls.spark = (SparkSession.builder.master('local[2]').appName('billing-regression')
                     .config('spark.sql.shuffle.partitions', '2')
                     .config('spark.sql.session.timeZone', 'Europe/Moscow')
                     .config('spark.ui.enabled', 'false').getOrCreate())
        cls.spark.sparkContext.setLogLevel('ERROR')
        p.spark = cls.spark

    @classmethod
    def tearDownClass(cls):
        cls.spark.stop()

    def batch(self, heterogeneous=False):
        from pyspark.sql import types as T
        columns = self.p.BUSINESS_COLUMNS
        types = [T.TimestampType() if c == 'DATE_TIME' else
                 (T.StringType() if heterogeneous and c == 'TEL_FROM' else T.LongType())
                 for c in columns]
        schema = T.StructType([T.StructField(c, t, True) for c, t in zip(columns, types)])
        values = dict(CALL_TYPE=1, DURATION=10, TEL_FROM=7001, TEL_TO=7001,
                      IMSI_FROM=7001, IMSI_TO=250000000000001, IMEI_FROM=123, IMEI_TO=None,
                      LAC_FROM=1, LAC_TO=2, CELLID_FROM=3, CELLID_TO=4,
                      CODE_FROM=250, CODE_TO=250, DATE_TIME=datetime(2026, 9, 21, 12, 0, 0, 123456))
        if heterogeneous:
            values['TEL_FROM'] = '007001'
        first = tuple(values[c] for c in columns)
        second = dict(values, TEL_TO=9001, IMEI_TO=123)
        # Duplicate source rows exercise per-branch DISTINCT and alarm multiplicity.
        return self.spark.createDataFrame([first, first, tuple(second[c] for c in columns)], schema)

    def lookup(self):
        # Numeric string with leading zero must retain original implicit comparison.
        return self.spark.createDataFrame(
            [(2, '007001', 'unused', 'A'), (2, '007001', 'unused', 'A'),
             (19, '7001', 'unused', 'B'), (20, '123', 'unused', 'C'),
             (20, None, 'unused', 'NULL')],
            'TYPE int, IDENTIFICATOR string, UID string, THEME string')

    def assert_multiset_equal(self, left, right):
        self.assertEqual(left.columns, right.columns)
        self.assertEqual(left.exceptAll(right).count(), 0)
        self.assertEqual(right.exceptAll(left).count(), 0)

    def check_identifiers(self, alarm, heterogeneous=False):
        from pyspark.sql import functions as F
        p = self.p
        batch, table = self.batch(heterogeneous), self.lookup()
        old = [((p._alarm_branch if alarm else p._idents_branch)(
            batch, table.where(F.col('TYPE') == kind), column)) for column, kind in p.IDENT_BRANCHES]
        reference = reduce(lambda a, b: a.unionByName(b), old)
        expanded = p.expand_identifiers(batch)
        if heterogeneous:
            self.assertIsNone(expanded)
        else:
            self.assertIsNotNone(expanded)
        actual = p.identifier_outputs(batch, expanded, table, alarm=alarm)
        self.assert_multiset_equal(reference, actual)

    def test_normalized_non_alarm_preserves_branch_duplicates(self):
        self.check_identifiers(False)

    def test_normalized_alarm_preserves_all_matches(self):
        self.check_identifiers(True)

    def test_mixed_type_fallback_preserves_string_comparison(self):
        self.check_identifiers(False, heterogeneous=True)

    def test_stage_keys_preserve_duplicate_multiplicity_and_microseconds(self):
        data = self.spark.createDataFrame(
            [(1, datetime(2026, 1, 1, 0, 0, 0, 123456)),
             (1, datetime(2026, 1, 1, 0, 0, 0, 123456)),
             (1, datetime(2026, 1, 1, 0, 0, 0, 123457)), (None, None)],
            'ID long, STAMP timestamp')
        self.p.PIPELINE_ID = 'test-generation'
        first = self.p.stage_rows(data.repartition(1), 1, 'attempt-1')
        retry = self.p.stage_rows(data.repartition(3), 1, 'attempt-2')
        self.assertEqual(first.select('_ss_row_key').distinct().count(), 4)
        self.assert_multiset_equal(first.select('_ss_row_key'), retry.select('_ss_row_key'))
        self.assert_multiset_equal(data, first.select('ID', 'STAMP'))

    def test_stage_null_is_not_empty_string(self):
        data = self.spark.createDataFrame([(None,), ('',), ('null',)], 'VALUE string')
        staged = self.p.stage_rows(data, 2, 'attempt')
        self.assertEqual(staged.select('_ss_row_key').distinct().count(), 3)

    def test_all_output_plans_match_sql_contracts(self):
        from unittest.mock import patch
        from staging_sql import default_manifest
        p = self.p
        batch = self.batch()
        p.kafka_IDENTS_msisdn = self.spark.createDataFrame(
            [('7001', 10, 'G')], 'ident string, ID_ident long, GP string')
        p.kafka_IDENTS_alarm = self.lookup()
        p.kafka_IDENTS_not_alarm = self.lookup()
        bs = self.spark.createDataFrame([('polygon', 1, 3, 250)],
                                        'REMARK string, LAC long, CELLID long, CODE long')
        for name in ('bs', 'pulkovo', 'road', 'ruchey'):
            setattr(p, 'kafka_IDENTS_' + name, bs)
        p.kafka_IDENTS_bs_rol = bs.drop('REMARK')
        expected = {s['sink_key']: s['columns'] for s in default_manifest()}
        observed = set()

        def inspect(df, url, table, *, batch_id, sink_key):
            self.assertEqual(df.columns, expected[sink_key])
            # Execute every branch to catch unresolved/ambiguous column references.
            df.count()
            observed.add(sink_key)

        with patch.object(p, 'write_mssql', side_effect=inspect):
            p.process_outputs(batch, 1)
        self.assertEqual(observed, set(expected))


if __name__ == '__main__':
    unittest.main(verbosity=2)
