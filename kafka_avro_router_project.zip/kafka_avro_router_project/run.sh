#!/usr/bin/env bash
set -euo pipefail

SPARK_PACKAGES="org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.1,org.apache.spark:spark-avro_2.12:3.5.1"
MSSQL_JAR="${MSSQL_JAR:-/opt/jars/mssql-jdbc.jar}"

spark-submit \  --packages "${SPARK_PACKAGES}" \  --jars "${MSSQL_JAR}" \  stream_kafka_router.py
