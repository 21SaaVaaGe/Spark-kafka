# Kafka Avro Router (Spark Structured Streaming)

Этот проект реализует потоковую интеграцию Kafka ↔ Spark ↔ MSSQL с динамическим маршрутизацией и метриками.

## Возможности

- Чтение сообщений из Kafka (value в Avro, Confluent wire header поддерживается).
- Декодирование Avro через встроенный `from_avro` (Spark Avro), **офлайн**: схема читаетcя из переменной/файла; если не заданы — из Apicurio (совместимый Confluent API).
- Динамические правила маршрутизации из таблицы MSSQL: `topic_name, LAC, TAC, MSS`.
- Если запись совпала с правилом — форвард **исходного бинарного** `value` в Kafka-топик `topic_name`.
- Вставка совпавших записей в таблицу MSSQL. При недоступности MSSQL — выгрузка JSON в S3 (MinIO).
- Все ошибки парсинга/wire/несовпадения правил уходят в топик `errors` с заголовком `error`.
- Метрики OpenTelemetry: базовые (работает ли job, число активных кверей), потоковые (сколько прочитано/ошибок/смэтчено), гистограммы длительности батчей и RPS.

## Требования

- Spark 3.5.x (рекомендовано).
- JAR'ы для Spark:
  - `org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.1`
  - `org.apache.spark:spark-avro_2.12:3.5.1`
  - MSSQL JDBC: `mssql-jdbc-<version>.jre8.jar` (или подходящая версия).
- Python библиотеки (драйвер/экзекьюторы):
  - `opentelemetry-sdk`, `opentelemetry-exporter-otlp` (опционально).
  - `minio` (для S3/MinIO fallback).

## Переменные окружения (ключевые)

```bash
# Kafka
export KAFKA_BOOTSTRAP="broker1:9092,broker2:9092"
export INPUT_TOPICS="raw-input"
export ERRORS_TOPIC="errors"

# Avro schema (офлайн предпочтительно)
export READER_SCHEMA_FILE="/opt/schemas/raw-input-value.avsc"
# или
# export READER_SCHEMA_STR='{"type":"record","name":"...", "fields":[...]}'

# Если нет офлайна — Apicurio (внутренняя сеть)
export REGISTRY_COMPAT_URL="http://apicurio:8080/apis/ccompat/v6"
export SCHEMA_SUBJECT="raw-input-value"

# Поля для матчей
export PHONE_FIELD="phone"
export LAC_FIELD="lac"
export TAC_FIELD="tac"
export MSS_FIELD="mss"

# MSSQL
export MSSQL_JDBC_URL="jdbc:sqlserver://mssql:1433;databaseName=router"
export MSSQL_USER="sa"
export MSSQL_PASSWORD="yourStrong(!)Password"
export MSSQL_RULES_TABLE="dbo.routing_rules"      # topic_name, LAC, TAC, MSS
export MSSQL_TARGET_TABLE="dbo.matched_events"

# MinIO (fallback при недоступности MSSQL)
export MINIO_ENABLE=true
export MINIO_ENDPOINT="minio:9000"
export MINIO_ACCESS_KEY="minioadmin"
export MINIO_SECRET_KEY="minioadmin"
export MINIO_SECURE=false
export MINIO_BUCKET="router-fallback"
export MINIO_PREFIX="failed-mssql"

# Spark
export CHECKPOINT_LOCATION="/data/checkpoints/router"
export STARTING_OFFSETS="latest"
export OUTPUT_KAFKA_ACKS="all"

# OpenTelemetry (опционально)
export OTEL_ENABLE=true
export OTEL_SERVICE_NAME="kafka-avro-router-prod"
export OTEL_EXPORTER_OTLP_ENDPOINT="otel-collector:4317"
export OTEL_EXPORT_INTERVAL_MS=10000
```

## Запуск

```bash
spark-submit   --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.1,org.apache.spark:spark-avro_2.12:3.5.1   --jars /path/to/mssql-jdbc.jar   stream_kafka_router.py
```

> Обязательно добавьте MSSQL JDBC JAR в `--jars` или в `SPARK_CLASSPATH`.

## Метрики OpenTelemetry

Счётчики/гистограммы:
- `job.running` (gauge, 1/0) — жив ли драйвер и стартовал ли стрим.
- `job.active_queries` (gauge) — число активных стрим-кверей.
- `stream.records_in{query}` — прочитано строк по данным Spark Progress.
- `stream.batch_duration_ms{query}` — длительность `addBatch`.
- `stream.input_rows_per_second{query}`, `stream.processed_rows_per_second{query}`.
- `stream.records_error{query}` — сколько записей ушло в `errors`.
- `stream.records_unmatched{query}` — сколько без совпавшего правила.
- `stream.records_routed{query}` — сколько успешно маршрутизировано.
- `mssql.insert_ok`, `mssql.insert_fail` — статус вставок в БД.
- `minio.fallback_objects` — сколько объектов выгружено в MinIO.

Атрибут `query` заполняется именем квери (например, `errors-parse-writer`, `runtime-routing-and-db`).

## Таблицы MSSQL (пример DDL)

```sql
CREATE TABLE dbo.routing_rules (
  topic_name NVARCHAR(200) NOT NULL,
  LAC        NVARCHAR(50)  NOT NULL,
  TAC        NVARCHAR(50)  NOT NULL,
  MSS        NVARCHAR(50)  NOT NULL
);
CREATE INDEX IX_rules_ltm ON dbo.routing_rules(LAC, TAC, MSS);

CREATE TABLE dbo.matched_events (
  event_time DATETIME2 NOT NULL,
  phone      NVARCHAR(64) NULL,
  lac        NVARCHAR(50) NOT NULL,
  tac        NVARCHAR(50) NOT NULL,
  mss        NVARCHAR(50) NOT NULL,
  schema_id  INT NULL,
  topic      NVARCHAR(200) NOT NULL,
  kafka_key  NVARCHAR(512) NULL
);
```

## Поток данных

1. Spark читает Kafka и отделяет Confluent wire header (если есть).
2. `from_avro(..., PERMISSIVE)` декодирует полезную нагрузку — ошибки не валят поток.
3. Записи с ошибками парсинга мгновенно пишутся в `errors` с причинами.
4. Каждая микропартия обрабатывается в `foreachBatch`:
   - правила читаются из MSSQL (статическая табличка);
   - делается join по `LAC,TAC,MSS`;
   - совпавшие — форвардятся как есть в Kafka-топик `topic_name` и вставляются в MSSQL;
   - при недоступности MSSQL — JSON выгружается в MinIO (`s3://{bucket}/{prefix}/...`);
   - не совпавшие — в `errors` с причиной `no_rule_matched`.

## Надёжность

- Все исключения перехватываются и обрабатываются — поток не останавливается.
- Чекпоинты обязательны (`CHECKPOINT_LOCATION`) для восстановления прогресса.
- Kafka sink с `acks=all`. При наличии ключей — семантика «ровно один раз» на партиции Kafka.
- MSSQL вставки делаются в `append` режиме. Рекомендуется включить ретраи и/или CDC на стороне БД при необходимости.

## Замечания

- Для больших батчей при MinIO fallback мы формируем одиночный JSON-файл (coalesce(1)) — оцените размер объекта исходя из нагрузки.
- Если MinIO недоступен, записи уходят в `errors` с причиной `mssql_failed_and_minio_failed`.
- Apicurio используется только если не задана схема через файл/переменную.
