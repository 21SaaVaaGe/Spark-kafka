#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Kafka -> Spark Structured Streaming (Avro) -> Dynamic Routing via MSSQL Rules
- Reads from Kafka (value=Avro, Confluent wire header supported)
- Decodes with Spark builtin from_avro using a reader schema (offline capable)
- "Base" metrics via OpenTelemetry (optional, graceful if absent)
- Dynamic routing rules come from MSSQL table (topic_name, LAC, TAC, MSS)
- If a record matches a rule => forward original bytes to the given Kafka topic
- Also insert matched records into MSSQL target table; on failure, upload to S3 (MinIO)
- All parse/wire/rule errors go to the 'errors' topic with header=error
- Absolutely no exceptions bubble to stop the stream; everything is handled safely.

Dependencies (driver+executors):
  - spark-sql-kafka-0-10_2.12:<spark_version>
  - spark-avro_2.12:<spark_version>
  - MSSQL JDBC driver (mssql-jdbc-*.jar) on classpath for JDBC
  - Python: opentelemetry-sdk, opentelemetry-exporter-otlp (optional)
  - Python: minio (for S3 fallback uploads)
"""

import os, json, urllib.request, tempfile, time
from typing import Optional
from pyspark.sql import SparkSession, functions as F, types as T
from pyspark.sql.avro.functions import from_avro
from pyspark.sql.streaming import StreamingQueryListener

# -----------------------------
# Configuration via env vars
# -----------------------------
KAFKA_BOOTSTRAP = os.getenv("KAFKA_BOOTSTRAP", "kafka:9092")
INPUT_TOPICS    = os.getenv("INPUT_TOPICS", "raw-input").split(",")
ERRORS_TOPIC    = os.getenv("ERRORS_TOPIC", "errors")

# Reader schema options (prefer offline: STR or FILE). If absent, fetch from Apicurio
REGISTRY_COMPAT_URL = os.getenv("REGISTRY_COMPAT_URL", "http://apicurio:8080/apis/ccompat/v6")
SCHEMA_SUBJECT = os.getenv("SCHEMA_SUBJECT", "raw-input-value")
READER_SCHEMA_STR  = os.getenv("READER_SCHEMA_STR", "")
READER_SCHEMA_FILE = os.getenv("READER_SCHEMA_FILE", "")

# Field names inside the Avro object
PHONE_FIELD = os.getenv("PHONE_FIELD", "phone")
LAC_FIELD   = os.getenv("LAC_FIELD", "lac")
TAC_FIELD   = os.getenv("TAC_FIELD", "tac")
MSS_FIELD   = os.getenv("MSS_FIELD", "mss")

# MSSQL routing rules source table (static lookup each micro-batch)
MSSQL_JDBC_URL   = os.getenv("MSSQL_JDBC_URL", "jdbc:sqlserver://mssql:1433;databaseName=router")
MSSQL_USER       = os.getenv("MSSQL_USER", "sa")
MSSQL_PASSWORD   = os.getenv("MSSQL_PASSWORD", "yourStrong(!)Password")
MSSQL_RULES_TABLE = os.getenv("MSSQL_RULES_TABLE", "dbo.routing_rules")  # columns: topic_name, LAC, TAC, MSS
MSSQL_TARGET_TABLE = os.getenv("MSSQL_TARGET_TABLE", "dbo.matched_events")  # where to insert matched rows

# MinIO for fallback (when MSSQL insert fails)
MINIO_ENABLE   = os.getenv("MINIO_ENABLE", "true").lower() == "true"
MINIO_ENDPOINT = os.getenv("MINIO_ENDPOINT", "minio:9000")
MINIO_ACCESS_KEY = os.getenv("MINIO_ACCESS_KEY", "minioadmin")
MINIO_SECRET_KEY = os.getenv("MINIO_SECRET_KEY", "minioadmin")
MINIO_SECURE   = os.getenv("MINIO_SECURE", "false").lower() == "true"
MINIO_BUCKET   = os.getenv("MINIO_BUCKET", "router-fallback")
MINIO_PREFIX   = os.getenv("MINIO_PREFIX", "failed-mssql")  # s3 key prefix

# Spark & Kafka IO
CHECKPOINT_LOCATION = os.getenv("CHECKPOINT_LOCATION", "/tmp/ckp/stream-router")
STARTING_OFFSETS    = os.getenv("STARTING_OFFSETS", "latest")
OUTPUT_KAFKA_ACKS   = os.getenv("OUTPUT_KAFKA_ACKS", "all")

# OpenTelemetry (optional)
OTEL_ENABLE = os.getenv("OTEL_ENABLE", "true").lower() == "true"
OTEL_SERVICE_NAME = os.getenv("OTEL_SERVICE_NAME", "kafka-avro-router")
OTEL_ENDPOINT = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT", "localhost:4317")  # gRPC
OTEL_INSECURE = os.getenv("OTEL_EXPORTER_OTLP_INSECURE", "true").lower() == "true"
OTEL_EXPORT_INTERVAL_MS = int(os.getenv("OTEL_EXPORT_INTERVAL_MS", "10000"))

# -----------------------------
# OpenTelemetry setup (soft)
# -----------------------------
otel_ok = False
m_records_in = m_records_error = m_records_routed = None
m_batch_ms = m_input_rps = m_proc_rps = None
m_job_running = m_active_queries = None
m_mssql_insert_ok = m_mssql_insert_fail = None
m_minio_fallback_files = None
m_unmatched_records = None

if OTEL_ENABLE:
    try:
        from opentelemetry import metrics as ot_metrics
        from opentelemetry.sdk.metrics import MeterProvider
        from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
        from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter
        from opentelemetry.sdk.resources import Resource

        exporter = OTLPMetricExporter(endpoint=OTEL_ENDPOINT, insecure=OTEL_INSECURE)
        reader = PeriodicExportingMetricReader(exporter, export_interval_millis=OTEL_EXPORT_INTERVAL_MS)
        resource = Resource.create({"service.name": OTEL_SERVICE_NAME})
        provider = MeterProvider(resource=resource, metric_readers=[reader])
        ot_metrics.set_meter_provider(provider)
        meter = ot_metrics.get_meter("kafka-avro-router", "1.1.0")

        # Counters / Histograms
        m_records_in      = meter.create_counter("stream.records_in", description="Kafka records read")
        m_records_error   = meter.create_counter("stream.records_error", description="Records to errors topic")
        m_unmatched_records = meter.create_counter("stream.records_unmatched", description="Records with no matching rule")
        m_records_routed  = meter.create_counter("stream.records_routed", description="Records routed to Kafka topics")
        m_mssql_insert_ok = meter.create_counter("mssql.insert_ok", description="Rows inserted into MSSQL")
        m_mssql_insert_fail = meter.create_counter("mssql.insert_fail", description="MSSQL insert failures")
        m_minio_fallback_files = meter.create_counter("minio.fallback_objects", description="Objects uploaded to MinIO due to MSSQL failure")

        m_batch_ms        = meter.create_histogram("stream.batch_duration_ms", unit="ms")
        m_input_rps       = meter.create_histogram("stream.input_rows_per_second", unit="rows/s")
        m_proc_rps        = meter.create_histogram("stream.processed_rows_per_second", unit="rows/s")

        # Observable gauges for liveness
        job_state = {"running": 0, "active_queries": 0}
        def job_running_callback(options):
            from opentelemetry.sdk.metrics import Observation
            return [Observation(job_state["running"], {})]
        def active_queries_callback(options):
            from opentelemetry.sdk.metrics import Observation
            return [Observation(job_state["active_queries"], {})]

        m_job_running   = meter.create_observable_gauge("job.running", callbacks=[job_running_callback],
                                                        description="1 if driver is alive and streaming started; else 0")
        m_active_queries = meter.create_observable_gauge("job.active_queries", callbacks=[active_queries_callback],
                                                        description="Number of active streaming queries")

        otel_ok = True
    except Exception:
        otel_ok = False

# -----------------------------
# Spark
# -----------------------------
spark = (
    SparkSession.builder
    .appName("kafka-avro-router")
    .config("spark.sql.shuffle.partitions", "200")
    .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    .getOrCreate()
)
spark.sparkContext.setLogLevel("WARN")

# Maintain job state for gauges
_job_state = {"running": 1, "active_queries": 0}
def _update_job_state(active_count: int):
    _job_state["running"] = 1
    _job_state["active_queries"] = int(active_count)

# Listener for progress-based metrics
if otel_ok:
    class OTelListener(StreamingQueryListener):
        def onQueryStarted(self, event):
            try:
                _update_job_state(len(spark.streams.active))
            except Exception:
                pass

        def onQueryProgress(self, event):
            try:
                p = event.progress
                attrs = {"query": p.get("name") or p.get("id")}
                num_in = int(p.get("numInputRows", 0))
                if m_records_in: m_records_in.add(num_in, attributes=attrs)
                dur = int((p.get("durationMs") or {}).get("addBatch", 0))
                if dur > 0 and m_batch_ms: m_batch_ms.record(dur, attributes=attrs)
                in_rps  = float(p.get("inputRowsPerSecond", 0.0))
                out_rps = float(p.get("processedRowsPerSecond", 0.0))
                if in_rps > 0 and m_input_rps: m_input_rps.record(in_rps, attributes=attrs)
                if out_rps > 0 and m_proc_rps: m_proc_rps.record(out_rps, attributes=attrs)
            except Exception:
                pass

        def onQueryTerminated(self, event):
            try:
                _update_job_state(len(spark.streams.active))
            except Exception:
                pass

    spark.streams.addListener(OTelListener())

# -----------------------------
# Resolve Avro reader schema
# -----------------------------
def resolve_reader_schema() -> str:
    if READER_SCHEMA_STR.strip():
        json.loads(READER_SCHEMA_STR)  # validate JSON
        return READER_SCHEMA_STR
    if READER_SCHEMA_FILE.strip():
        with open(READER_SCHEMA_FILE, "r", encoding="utf-8") as f:
            txt = f.read()
        json.loads(txt)
        return txt
    # fallback to Apicurio
    url = REGISTRY_COMPAT_URL.rstrip("/") + f"/subjects/{SCHEMA_SUBJECT}/versions/latest"
    with urllib.request.urlopen(url, timeout=10) as resp:
        data = json.loads(resp.read().decode("utf-8"))
        return data["schema"]

READER_AVRO_SCHEMA = resolve_reader_schema()

# -----------------------------
# UDF: strip Confluent wire header (0x00 + 4 bytes schema id)
# -----------------------------
WireInfoType = T.StructType([
    T.StructField("payload",   T.BinaryType(), True),
    T.StructField("schema_id", T.IntegerType(), True),
    T.StructField("error",     T.StringType(), True),
])

@F.udf(WireInfoType)
def extract_wire_info(v: bytes):
    try:
        if v is None or len(v) == 0:
            return (None, None, "empty_value")
        if v[0] == 0 and len(v) >= 5:
            sid = int.from_bytes(v[1:5], "big", signed=False)
            return (v[5:], sid, None)
        return (v, None, None)
    except Exception as e:
        return (None, None, f"wire_parse_error: {str(e)}")

# -----------------------------
# Source: Kafka
# -----------------------------
src = (
    spark.readStream.format("kafka")
    .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP)
    .option("subscribe", ",".join(INPUT_TOPICS))
    .option("startingOffsets", STARTING_OFFSETS)
    .option("failOnDataLoss", "false")
    .option("includeHeaders", "true")
    .load()
)

with_wire = src.select(
    F.col("key").alias("in_key"),
    F.col("value").alias("in_value"),
    F.col("headers").alias("in_headers"),
    extract_wire_info(F.col("value")).alias("wire")
).select(
    "in_key", "in_value", "in_headers",
    F.col("wire.payload").alias("payload"),
    F.col("wire.schema_id").alias("schema_id"),
    F.col("wire.error").alias("wire_error")
)

decoded = with_wire.select(
    "in_key", "in_value", "in_headers", "schema_id", "wire_error",
    from_avro(F.col("payload"), READER_AVRO_SCHEMA, {"mode": "PERMISSIVE"}).alias("obj")
)

# Extract fields for routing
routed_base = decoded.select(
    "in_key", "in_value", "in_headers", "schema_id", "wire_error", "obj",
    F.col(f"obj.{PHONE_FIELD}").cast("string").alias("phone"),
    F.col(f"obj.{LAC_FIELD}").cast("string").alias("lac"),
    F.col(f"obj.{TAC_FIELD}").cast("string").alias("tac"),
    F.col(f"obj.{MSS_FIELD}").cast("string").alias("mss")
)

# -----------------------------
# Classify parse/wire errors -> immediate errors topic
# -----------------------------
parse_error_reason = (
    F.when(F.col("wire_error").isNotNull(), F.concat(F.lit("wire_error: "), F.col("wire_error")))
     .when(F.col("obj").isNull(), F.lit("from_avro_failed"))
)

errors_parse_ds = routed_base.where(parse_error_reason.isNotNull()).select(
    F.col("in_key").cast("binary").alias("key"),
    F.col("in_value").alias("value"),
    F.array(F.struct(F.lit("error").cast("binary").alias("key"),
                     parse_error_reason.cast("binary").alias("value"))).alias("headers"),
    F.lit(ERRORS_TOPIC).alias("topic")
)

def write_to_kafka(ds, checkpoint_dir, qname):
    return (
        ds.writeStream
        .queryName(qname)
        .format("kafka")
        .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP)
        .option("kafka.acks", OUTPUT_KAFKA_ACKS)
        .option("checkpointLocation", os.path.join(CHECKPOINT_LOCATION, checkpoint_dir))
        .outputMode("append")
        .start()
    )

q_parse_errors = write_to_kafka(errors_parse_ds, "errors-parse", "errors-parse-writer")

# -----------------------------
# ForeachBatch for dynamic MSSQL rules & routing & DB insert with MinIO fallback
# -----------------------------
def process_batch(batch_df, batch_id: int):
    # filter only records with successful decode
    base = batch_df.where(F.col("wire_error").isNull() & F.col("obj").isNotNull())
    if base.rdd.isEmpty():
        return

    # Load rules table (static) via JDBC
    rules_df = None
    try:
        rules_df = spark.read.format("jdbc") \
            .option("url", MSSQL_JDBC_URL) \
            .option("user", MSSQL_USER) \
            .option("password", MSSQL_PASSWORD) \
            .option("dbtable", MSSQL_RULES_TABLE) \
            .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
            .load() \
            .select(
                F.col("topic_name").cast("string"),
                F.col("LAC").cast("string").alias("lac"),
                F.col("TAC").cast("string").alias("tac"),
                F.col("MSS").cast("string").alias("mss")
            ) \
            .dropna(subset=["topic_name","lac","tac","mss"]) \
            .distinct()
    except Exception as e:
        # If rules cannot be loaded, send all to errors with reason
        reason = f"rules_load_failed: {str(e)}"
        err_df = base.select(
            F.col("in_key").cast("binary").alias("key"),
            F.col("in_value").alias("value"),
            F.array(F.struct(F.lit("error").cast("binary").alias("key"),
                             F.lit(reason).cast("binary").alias("value"))).alias("headers"),
            F.lit(ERRORS_TOPIC).alias("topic")
        )
        # Write to Kafka
        err_df.write \
            .format("kafka") \
            .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP) \
            .option("kafka.acks", OUTPUT_KAFKA_ACKS) \
            .mode("append").save()
        if otel_ok and m_records_error:
            m_records_error.add(err_df.count(), attributes={"query": "errors-runtime", "error": "rules_load_failed"})
        return

    # Join on lac,tac,mss
    joined = base.join(rules_df, on=["lac","tac","mss"], how="left")

    matched = joined.where(F.col("topic_name").isNotNull())
    unmatched = joined.where(F.col("topic_name").isNull())

    # 1) unmatched -> errors topic with no_rule
    if not unmatched.rdd.isEmpty():
        err_df2 = unmatched.select(
            F.col("in_key").cast("binary").alias("key"),
            F.col("in_value").alias("value"),
            F.array(F.struct(F.lit("error").cast("binary").alias("key"),
                             F.lit("no_rule_matched").cast("binary").alias("value"))).alias("headers"),
            F.lit(ERRORS_TOPIC).alias("topic")
        )
        err_df2.write \
            .format("kafka") \
            .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP) \
            .option("kafka.acks", OUTPUT_KAFKA_ACKS) \
            .mode("append").save()
        if otel_ok and m_unmatched_records:
            m_unmatched_records.add(err_df2.count(), attributes={"query": "errors-runtime"})

    # 2) matched -> route to Kafka topic_name with original bytes
    if not matched.rdd.isEmpty():
        out_df = matched.select(
            F.col("in_key").cast("binary").alias("key"),
            F.col("in_value").alias("value"),
            F.col("in_headers").alias("headers"),
            F.col("topic_name").alias("topic")
        )
        out_df.write \
            .format("kafka") \
            .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP) \
            .option("kafka.acks", OUTPUT_KAFKA_ACKS) \
            .mode("append").save()
        if otel_ok and m_records_routed:
            m_records_routed.add(out_df.count(), attributes={"query": "valid-runtime"})

        # Insert into MSSQL target table
        to_insert = matched.select(
            F.current_timestamp().alias("event_time"),
            "phone","lac","tac","mss","schema_id",
            F.col("topic_name").alias("topic"),
            F.col("in_key").cast("string").alias("kafka_key")
        )

        try:
            to_insert.write \
                .format("jdbc") \
                .option("url", MSSQL_JDBC_URL) \
                .option("user", MSSQL_USER) \
                .option("password", MSSQL_PASSWORD) \
                .option("dbtable", MSSQL_TARGET_TABLE) \
                .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
                .mode("append").save()
            if otel_ok and m_mssql_insert_ok:
                m_mssql_insert_ok.add(to_insert.count())
        except Exception as e:
            # MSSQL unavailable -> upload JSON to MinIO
            if MINIO_ENABLE:
                try:
                    from minio import Minio
                    from minio.error import S3Error
                    ts = time.strftime("%Y%m%d-%H%M%S")
                    tmpdir = tempfile.mkdtemp(prefix="router-batch-")
                    outpath = os.path.join(tmpdir, f"batch_{batch_id}.json")
                    # single file
                    to_insert.coalesce(1).write.mode("overwrite").json(outpath)
                    # find the part file
                    part_file = None
                    for root, _, files in os.walk(outpath):
                        for f in files:
                            if f.startswith("part-") and f.endswith(".json"):
                                part_file = os.path.join(root, f)
                                break
                    if part_file is None:
                        raise RuntimeError("No JSON part file produced for MinIO upload.")
                    client = Minio(MINIO_ENDPOINT,
                                   access_key=MINIO_ACCESS_KEY,
                                   secret_key=MINIO_SECRET_KEY,
                                   secure=MINIO_SECURE)
                    # Ensure bucket
                    found = client.bucket_exists(MINIO_BUCKET)
                    if not found:
                        client.make_bucket(MINIO_BUCKET)
                    object_name = f"{MINIO_PREFIX}/dt={ts[:8]}/batch_{batch_id}_{ts}.json"
                    client.fput_object(MINIO_BUCKET, object_name, part_file)
                    if otel_ok and m_minio_fallback_files:
                        m_minio_fallback_files.add(1, attributes={"object": object_name})
                except Exception as e2:
                    # As a last resort, ship these records to errors topic with header=mssql_failed
                    fallback_err = matched.select(
                        F.col("in_key").cast("binary").alias("key"),
                        F.col("in_value").alias("value"),
                        F.array(F.struct(F.lit("error").cast("binary").alias("key"),
                                         F.lit(f"mssql_failed_and_minio_failed: {str(e2)}").cast("binary").alias("value"))).alias("headers"),
                        F.lit(ERRORS_TOPIC).alias("topic")
                    )
                    fallback_err.write \
                        .format("kafka") \
                        .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP) \
                        .option("kafka.acks", OUTPUT_KAFKA_ACKS) \
                        .mode("append").save()
            if otel_ok and m_mssql_insert_fail:
                m_mssql_insert_fail.add(to_insert.count())

# Streaming DF to drive foreachBatch
# Note: keep only needed columns
runtime_base = routed_base.select("in_key","in_value","in_headers","schema_id","wire_error","obj","phone","lac","tac","mss")

q_runtime = (
    runtime_base.writeStream
    .queryName("runtime-routing-and-db")
    .foreachBatch(process_batch)
    .option("checkpointLocation", os.path.join(CHECKPOINT_LOCATION, "runtime"))
    .outputMode("append")
    .start()
)

# Update gauges
_update_job_state(len(spark.streams.active))

spark.streams.awaitAnyTermination()
