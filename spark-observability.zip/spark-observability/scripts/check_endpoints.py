#!/usr/bin/env python3
"""Check every HTTP endpoint used by the Spark monitoring dashboard."""

from __future__ import annotations

import argparse
import pathlib
import urllib.error
import urllib.request
from typing import Dict, Iterable, List, Tuple

from configure import load_env


def check_url(url: str, expected_text: str = "", timeout: float = 5.0) -> Tuple[bool, str]:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            body = response.read().decode("utf-8", errors="replace")
            status = response.status
        if expected_text and expected_text not in body:
            return False, f"HTTP {status}, missing {expected_text!r}"
        return True, f"HTTP {status}"
    except (urllib.error.URLError, TimeoutError, OSError) as error:
        return False, str(error)


def endpoint_checks(config: Dict[str, str]) -> List[Tuple[str, str, str]]:
    master = f"http://{config['SPARK_MASTER_HOST']}:{config['SPARK_MASTER_UI_PORT']}"
    worker = f"http://{config['SPARK_WORKER_HOST']}:{config['SPARK_WORKER_UI_PORT']}"
    driver = f"http://{config['SPARK_DRIVER_HOST']}:{config['SPARK_DRIVER_UI_PORT']}"
    streaming = f"http://{config['SPARK_DRIVER_HOST']}:{config['STREAMING_METRICS_PORT']}"
    return [
        ("Spark master", master + "/metrics/master/prometheus/", ""),
        ("Spark applications", master + "/metrics/applications/prometheus/", ""),
        ("Spark worker", worker + "/metrics/prometheus/", ""),
        ("Spark driver", driver + "/metrics/prometheus/", ""),
        ("Spark executors", driver + "/metrics/executors/prometheus/", ""),
        ("Streaming listener", streaming + "/metrics", "spark_ss_exporter_info"),
        ("Spark History Server", config["SPARK_HISTORY_URL"].rstrip("/") + "/api/v1/version", "spark"),
        ("Prometheus", config["PROMETHEUS_URL"].rstrip("/") + "/-/ready", "Ready"),
        ("Grafana", config["GRAFANA_URL"].rstrip("/") + "/api/health", "database"),
    ]


def main(argv: Iterable[str] | None = None) -> int:
    project_root = pathlib.Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=pathlib.Path,
        default=project_root / "config" / "monitoring.env",
    )
    args = parser.parse_args(argv)

    failures = 0
    for name, url, expected in endpoint_checks(load_env(args.config)):
        ok, detail = check_url(url, expected)
        marker = "OK" if ok else "FAIL"
        print(f"[{marker}] {name}: {url} ({detail})")
        failures += int(not ok)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
