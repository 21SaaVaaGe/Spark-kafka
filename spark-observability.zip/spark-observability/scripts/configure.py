#!/usr/bin/env python3
"""Render offline monitoring configuration from a simple environment file."""

from __future__ import annotations

import argparse
import json
import pathlib
import re
from typing import Dict, Iterable, List, Tuple


PLACEHOLDER = re.compile(r"\{\{([A-Z][A-Z0-9_]*)\}\}")


def load_env(path: pathlib.Path) -> Dict[str, str]:
    values: Dict[str, str] = {}
    for line_number, raw_line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        key, separator, value = line.partition("=")
        if not separator or not key.strip():
            raise ValueError(f"Invalid configuration at {path}:{line_number}")
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        values[key.strip()] = value
    return values


def render_templates(
    templates_dir: pathlib.Path,
    output_dir: pathlib.Path,
    values: Dict[str, str],
) -> List[pathlib.Path]:
    prepared: List[Tuple[pathlib.Path, str]] = []
    for source in sorted(templates_dir.rglob("*.template")):
        relative = source.relative_to(templates_dir)
        destination = output_dir / relative.with_suffix("")
        text = source.read_text(encoding="utf-8")
        missing = sorted(set(PLACEHOLDER.findall(text)) - values.keys())
        if missing:
            raise ValueError(f"Missing configuration values: {', '.join(missing)}")
        text = PLACEHOLDER.sub(lambda match: values[match.group(1)], text)
        if destination.suffix == ".json":
            json.loads(text)
        prepared.append((destination, text))

    # Validate every template before touching a previously working output set.
    for destination, text in prepared:
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(text, encoding="utf-8", newline="\n")
    return [destination for destination, _ in prepared]


def main(argv: Iterable[str] | None = None) -> int:
    project_root = pathlib.Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=pathlib.Path,
        default=project_root / "config" / "monitoring.env",
    )
    parser.add_argument(
        "--output",
        type=pathlib.Path,
        default=project_root / "generated",
    )
    args = parser.parse_args(argv)

    rendered = render_templates(project_root / "templates", args.output, load_env(args.config))
    print(f"Rendered {len(rendered)} files into {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
