import pathlib
import sys
import tempfile
import unittest


PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

from configure import load_env, render_templates  # noqa: E402


class ConfigureTest(unittest.TestCase):
    def test_renders_all_placeholders_and_removes_template_suffix(self):
        with tempfile.TemporaryDirectory() as directory:
            root = pathlib.Path(directory)
            templates = root / "templates"
            output = root / "generated"
            (templates / "nested").mkdir(parents=True)
            (templates / "nested" / "service.yml.template").write_text(
                "host: {{HOST}}\nport: {{PORT}}\n", encoding="utf-8"
            )
            env_file = root / "monitoring.env"
            env_file.write_text('HOST="spark01"\nPORT=4040\n', encoding="utf-8")

            rendered = render_templates(templates, output, load_env(env_file))

            self.assertEqual(rendered, [output / "nested" / "service.yml"])
            self.assertEqual(
                (output / "nested" / "service.yml").read_text(encoding="utf-8"),
                "host: spark01\nport: 4040\n",
            )

    def test_rejects_an_unresolved_placeholder(self):
        with tempfile.TemporaryDirectory() as directory:
            root = pathlib.Path(directory)
            templates = root / "templates"
            templates.mkdir()
            (templates / "bad.template").write_text("{{MISSING}}", encoding="utf-8")

            with self.assertRaisesRegex(ValueError, "MISSING"):
                render_templates(templates, root / "generated", {})

    def test_preserves_unrelated_files_in_output_directory(self):
        with tempfile.TemporaryDirectory() as directory:
            root = pathlib.Path(directory)
            templates = root / "templates"
            output = root / "generated"
            templates.mkdir()
            output.mkdir()
            (templates / "service.template").write_text("ok", encoding="utf-8")
            unrelated = output / "keep.txt"
            unrelated.write_text("keep", encoding="utf-8")

            render_templates(templates, output, {})

            self.assertEqual(unrelated.read_text(encoding="utf-8"), "keep")

    def test_validation_failure_does_not_modify_existing_output(self):
        with tempfile.TemporaryDirectory() as directory:
            root = pathlib.Path(directory)
            templates = root / "templates"
            output = root / "generated"
            templates.mkdir()
            output.mkdir()
            (templates / "dashboard.json.template").write_text(
                '{"broken": }', encoding="utf-8"
            )
            existing = output / "dashboard.json"
            existing.write_text('{"working": true}\n', encoding="utf-8")

            with self.assertRaises(ValueError):
                render_templates(templates, output, {})

            self.assertEqual(
                existing.read_text(encoding="utf-8"), '{"working": true}\n'
            )


if __name__ == "__main__":
    unittest.main()
