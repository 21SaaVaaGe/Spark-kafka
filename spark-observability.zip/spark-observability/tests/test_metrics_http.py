import pathlib
import sys
import unittest
import urllib.request


PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "app"))

from streaming_metrics import MetricsRegistry, start_metrics_http_server  # noqa: E402


class MetricsHttpTest(unittest.TestCase):
    def test_metrics_response_has_safe_headers(self):
        server = start_metrics_http_server(MetricsRegistry("ANALITIKA"), "127.0.0.1", 0)
        try:
            with urllib.request.urlopen(
                f"http://127.0.0.1:{server.server_address[1]}/metrics", timeout=2
            ) as response:
                body = response.read().decode("utf-8")

            self.assertIn("spark_ss_exporter_info", body)
            self.assertEqual(response.headers["X-Content-Type-Options"], "nosniff")
            self.assertEqual(response.headers["X-Frame-Options"], "DENY")
            self.assertEqual(response.headers["Cache-Control"], "no-store")
        finally:
            server.shutdown()
            server.server_close()


if __name__ == "__main__":
    unittest.main()
