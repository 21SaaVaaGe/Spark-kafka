import pathlib
import sys
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

from check_endpoints import check_url, endpoint_checks  # noqa: E402


class _Handler(BaseHTTPRequestHandler):
    def do_GET(self):  # noqa: N802
        if self.path == "/ok":
            body = b"spark_ss_exporter_info 1\n"
            self.send_response(200)
        else:
            body = b"failure\n"
            self.send_response(500)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, _format, *args):
        return


class CheckUrlTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base_url = f"http://127.0.0.1:{cls.server.server_address[1]}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def test_accepts_success_response_with_expected_content(self):
        ok, detail = check_url(self.base_url + "/ok", "spark_ss_exporter_info")

        self.assertTrue(ok)
        self.assertEqual(detail, "HTTP 200")

    def test_rejects_http_error(self):
        ok, detail = check_url(self.base_url + "/fail", "spark")

        self.assertFalse(ok)
        self.assertIn("HTTP Error 500", detail)

    def test_native_spark_endpoints_only_require_http_success(self):
        config = {
            "SPARK_MASTER_HOST": "spark01",
            "SPARK_MASTER_UI_PORT": "8080",
            "SPARK_WORKER_HOST": "spark01",
            "SPARK_WORKER_UI_PORT": "8081",
            "SPARK_DRIVER_HOST": "spark01",
            "SPARK_DRIVER_UI_PORT": "4040",
            "STREAMING_METRICS_PORT": "9109",
            "SPARK_HISTORY_URL": "http://spark01:18080",
            "PROMETHEUS_URL": "http://spark01:9090",
            "GRAFANA_URL": "http://spark01:3000",
        }

        checks = endpoint_checks(config)

        self.assertEqual([expected for _, _, expected in checks[:5]], [""] * 5)


if __name__ == "__main__":
    unittest.main()
