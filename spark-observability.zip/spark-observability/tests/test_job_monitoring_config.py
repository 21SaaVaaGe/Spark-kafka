import pathlib
import unittest


PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[1]


class JobMonitoringConfigTest(unittest.TestCase):
    def test_application_and_query_names_are_configurable(self):
        source = (PROJECT_ROOT / "app" / "prod_refactored.py").read_text(
            encoding="utf-8"
        )

        self.assertIn('APP_NAME = os.getenv("APP_NAME", "ANALITIKA")', source)
        self.assertIn('QUERY_NAME = os.getenv("QUERY_NAME", "SHRINK")', source)
        self.assertIn('.appName(APP_NAME)', source)
        self.assertIn('.queryName(QUERY_NAME)', source)
        self.assertIn('application=APP_NAME', source)
