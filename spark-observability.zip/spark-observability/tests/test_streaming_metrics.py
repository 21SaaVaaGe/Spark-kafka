import pathlib
import sys
import unittest


PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "app"))

from streaming_metrics import MetricsRegistry  # noqa: E402


class MetricsRegistryTest(unittest.TestCase):
    def test_progress_is_exported_and_duplicate_batch_is_not_counted_twice(self):
        registry = MetricsRegistry("ANALITIKA")
        registry.record_started("query-id", "run-1", "SHRINK")
        progress = {
            "id": "query-id",
            "runId": "run-1",
            "name": "SHRINK",
            "timestamp": "2026-01-01T00:00:00.000Z",
            "batchId": 7,
            "numInputRows": 42,
            "inputRowsPerSecond": 21.0,
            "processedRowsPerSecond": 20.0,
            "durationMs": {"triggerExecution": 2100},
        }

        registry.record_progress(progress)
        registry.record_progress(progress)
        rendered = registry.render()

        labels = 'application="ANALITIKA",query="SHRINK"'
        self.assertIn(f"spark_ss_query_active{{{labels}}} 1", rendered)
        self.assertIn(f"spark_ss_last_batch_input_rows{{{labels}}} 42", rendered)
        self.assertIn(f"spark_ss_input_rows_total{{{labels}}} 42", rendered)
        self.assertIn(f"spark_ss_trigger_duration_seconds{{{labels}}} 2.1", rendered)

    def test_termination_changes_state_and_counts_failures(self):
        registry = MetricsRegistry("ANALITIKA")
        registry.record_started("query-id", "run-1", "SHRINK")
        registry.record_terminated("query-id", "boom")
        rendered = registry.render()

        labels = 'application="ANALITIKA",query="SHRINK"'
        self.assertIn(f"spark_ss_query_active{{{labels}}} 0", rendered)
        self.assertIn(f"spark_ss_query_failures_total{{{labels}}} 1", rendered)


if __name__ == "__main__":
    unittest.main()
