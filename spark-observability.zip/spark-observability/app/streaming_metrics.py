"""Small dependency-free Prometheus exporter for PySpark Structured Streaming."""

from __future__ import annotations

import json
import logging
import math
import threading
import time
from dataclasses import dataclass
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Dict, Mapping, Optional


LOGGER = logging.getLogger(__name__)


def _timestamp_seconds(value: object) -> float:
    if not value:
        return time.time()
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return time.time()


def _number(value: object, default: float = 0.0) -> float:
    try:
        result = float(value)
        return result if math.isfinite(result) else default
    except (TypeError, ValueError):
        return default


def _escape_label(value: object) -> str:
    return str(value).replace("\\", "\\\\").replace("\n", "\\n").replace('"', '\\"')


def _format_number(value: float) -> str:
    return str(int(value)) if float(value).is_integer() else repr(float(value))


@dataclass
class QueryMetrics:
    active: float = 0.0
    last_progress_timestamp_seconds: float = 0.0
    last_batch_id: float = -1.0
    last_batch_input_rows: float = 0.0
    input_rows_total: float = 0.0
    input_rows_per_second: float = 0.0
    processed_rows_per_second: float = 0.0
    trigger_duration_seconds: float = 0.0
    failures_total: float = 0.0
    run_id: str = ""


class MetricsRegistry:
    """Thread-safe in-memory metrics updated by StreamingQueryListener."""

    def __init__(self, application: str) -> None:
        self.application = application
        self._lock = threading.Lock()
        self._queries: Dict[str, QueryMetrics] = {}
        self._query_names_by_id: Dict[str, str] = {}
        self._listener_errors_total = 0.0

    @staticmethod
    def _query_name(name: object, query_id: object) -> str:
        return str(name or query_id or "unnamed")

    def record_started(self, query_id: object, run_id: object, name: object) -> None:
        query_id_text = str(query_id or "")
        query_name = self._query_name(name, query_id_text)
        with self._lock:
            stats = self._queries.setdefault(query_name, QueryMetrics())
            stats.active = 1.0
            stats.run_id = str(run_id or "")
            stats.last_batch_id = -1.0
            if query_id_text:
                self._query_names_by_id[query_id_text] = query_name

    def record_progress(self, progress: Mapping[str, object]) -> None:
        query_id = str(progress.get("id") or "")
        query_name = self._query_name(
            progress.get("name") or self._query_names_by_id.get(query_id),
            query_id,
        )
        run_id = str(progress.get("runId") or "")
        batch_id = _number(progress.get("batchId"), -1.0)
        input_rows = _number(progress.get("numInputRows"))
        duration_ms = progress.get("durationMs")
        if not isinstance(duration_ms, Mapping):
            duration_ms = {}

        with self._lock:
            stats = self._queries.setdefault(query_name, QueryMetrics())
            is_new_run = bool(run_id and stats.run_id and run_id != stats.run_id)
            if is_new_run:
                stats.last_batch_id = -1.0
            if run_id:
                stats.run_id = run_id
            stats.active = 1.0
            stats.last_progress_timestamp_seconds = _timestamp_seconds(progress.get("timestamp"))
            stats.last_batch_input_rows = input_rows
            stats.input_rows_per_second = _number(progress.get("inputRowsPerSecond"))
            stats.processed_rows_per_second = _number(progress.get("processedRowsPerSecond"))
            stats.trigger_duration_seconds = _number(duration_ms.get("triggerExecution")) / 1000.0
            if batch_id >= 0 and batch_id > stats.last_batch_id:
                stats.input_rows_total += input_rows
                stats.last_batch_id = batch_id
            if query_id:
                self._query_names_by_id[query_id] = query_name

    def record_terminated(self, query_id: object, exception: object = None) -> None:
        query_id_text = str(query_id or "")
        with self._lock:
            query_name = self._query_names_by_id.get(query_id_text, query_id_text or "unnamed")
            stats = self._queries.setdefault(query_name, QueryMetrics())
            stats.active = 0.0
            if exception:
                stats.failures_total += 1.0

    def record_listener_error(self) -> None:
        with self._lock:
            self._listener_errors_total += 1.0

    def render(self) -> str:
        specs = (
            ("spark_ss_query_active", "Whether the streaming query is active.", "gauge", "active"),
            ("spark_ss_last_progress_timestamp_seconds", "Unix time of the latest progress event.", "gauge", "last_progress_timestamp_seconds"),
            ("spark_ss_last_batch_id", "Latest observed Structured Streaming batch ID.", "gauge", "last_batch_id"),
            ("spark_ss_last_batch_input_rows", "Kafka input rows in the latest micro-batch.", "gauge", "last_batch_input_rows"),
            ("spark_ss_input_rows_total", "Kafka input rows observed since the driver started.", "counter", "input_rows_total"),
            ("spark_ss_input_rows_per_second", "Input rows per second reported by Spark.", "gauge", "input_rows_per_second"),
            ("spark_ss_processed_rows_per_second", "Rows per second processed by Spark.", "gauge", "processed_rows_per_second"),
            ("spark_ss_trigger_duration_seconds", "Duration of the latest trigger execution.", "gauge", "trigger_duration_seconds"),
            ("spark_ss_query_failures_total", "Streaming query terminations with an exception.", "counter", "failures_total"),
        )
        with self._lock:
            queries = {name: QueryMetrics(**vars(stats)) for name, stats in self._queries.items()}
            listener_errors = self._listener_errors_total

        app_label = _escape_label(self.application)
        lines = [
            "# HELP spark_ss_exporter_info Static information about the embedded exporter.",
            "# TYPE spark_ss_exporter_info gauge",
            f'spark_ss_exporter_info{{application="{app_label}"}} 1',
            "# HELP spark_ss_listener_errors_total Listener events that could not be parsed.",
            "# TYPE spark_ss_listener_errors_total counter",
            f'spark_ss_listener_errors_total{{application="{app_label}"}} {_format_number(listener_errors)}',
        ]
        for metric_name, help_text, metric_type, attribute in specs:
            lines.extend((f"# HELP {metric_name} {help_text}", f"# TYPE {metric_name} {metric_type}"))
            for query_name, stats in sorted(queries.items()):
                value = getattr(stats, attribute)
                labels = f'application="{app_label}",query="{_escape_label(query_name)}"'
                lines.append(f"{metric_name}{{{labels}}} {_format_number(value)}")
        return "\n".join(lines) + "\n"


class _MetricsServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def _handler_for(registry: MetricsRegistry):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802 - required by BaseHTTPRequestHandler
            if self.path == "/metrics":
                body = registry.render().encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
            elif self.path == "/healthz":
                body = b"ok\n"
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
            else:
                body = b"not found\n"
                self.send_response(404)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, _format: str, *args: object) -> None:
            return

    return Handler


def start_metrics_http_server(
    registry: MetricsRegistry,
    host: str = "0.0.0.0",
    port: int = 9109,
) -> _MetricsServer:
    server = _MetricsServer((host, port), _handler_for(registry))
    thread = threading.Thread(target=server.serve_forever, name="spark-metrics-http", daemon=True)
    thread.start()
    return server


class MonitoringHandle:
    def __init__(self, spark, listener, server: _MetricsServer) -> None:
        self._spark = spark
        self._listener = listener
        self._server = server
        self._stopped = False

    @property
    def port(self) -> int:
        return int(self._server.server_address[1])

    def stop(self) -> None:
        if self._stopped:
            return
        self._stopped = True
        try:
            self._spark.streams.removeListener(self._listener)
        except Exception:
            LOGGER.debug("Streaming listener was already removed", exc_info=True)
        self._server.shutdown()
        self._server.server_close()


def install_streaming_monitoring(
    spark,
    application: str,
    host: str = "0.0.0.0",
    port: int = 9109,
) -> MonitoringHandle:
    """Register the listener and start a Prometheus HTTP endpoint in the driver."""
    from pyspark.sql.streaming import StreamingQueryListener

    registry = MetricsRegistry(application)

    class Listener(StreamingQueryListener):
        def onQueryStarted(self, event) -> None:
            registry.record_started(event.id, event.runId, event.name)

        def onQueryProgress(self, event) -> None:
            try:
                registry.record_progress(json.loads(event.progress.json))
            except Exception:
                registry.record_listener_error()
                LOGGER.exception("Cannot process Structured Streaming progress event")

        def onQueryIdle(self, event) -> None:
            return

        def onQueryTerminated(self, event) -> None:
            registry.record_terminated(event.id, getattr(event, "exception", None))

    server = start_metrics_http_server(registry, host, port)
    listener = Listener()
    try:
        spark.streams.addListener(listener)
    except Exception:
        server.shutdown()
        server.server_close()
        raise
    LOGGER.info("Structured Streaming metrics available at http://%s:%s/metrics", host, port)
    return MonitoringHandle(spark, listener, server)
