"""
PySpark Structured Streaming pipeline: GSM billing from Kafka -> MSSQL.

Reads Avro-encoded GSM CDRs from a Kafka topic (Confluent wire format),
joins them with several lookup tables from MSSQL (IDENTS, BS, ROL, RUCHEY,
ROAD, PULKOVO), splits the traffic into a number of business categories
(operator subscribers, foreign 10/11-digit numbers, non-Russian numbers,
alarm/non-alarm idents, base-station polygons), and writes each category
into its target MSSQL table.
"""

import json
import os
import urllib.request

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql.avro.functions import from_avro

from streaming_metrics import install_streaming_monitoring

# =============================================================================
# Configuration
# =============================================================================

# --- Kafka ---
KAFKA_BOOTSTRAP = os.getenv(
    'KAFKA_BOOTSRAP',  # NB: env var name has historical typo, kept for compat
    '192.168.115.66:9092,192.168.115.122:9092,192.168.115.46:9092',
)
INPUT_TOPICS = os.getenv('INPUT_TOPICS', 'GSM')
ERRORS_TOPIC = os.getenv('ERRORS_TOPIC', 'errors')
STARTING_OFFSETS = os.getenv('STARTING_OFFSETS', 'latest')
CHECKPOINT_LOCATION = os.getenv('CHECKPOINT_LOCATION', '/opt/tmp/')

# --- Avro schema source ---
REGISTRY_COMPAT_URL = os.getenv("REGISTRY_COMPAT_URL", "http://kafka02:8889/apis/ccompat/v7")
SCHEMA_SUBJECT = os.getenv("SCHEMA_SUBJECT", "Billing_GSM_Transform")
READER_SCHEMA_STR = os.getenv("READER_SCHEMA_STR", "")
READER_SCHEMA_FILE = os.getenv("READER_SCHEMA_FILE", "")

# --- Avro field name overrides ---
LAC_FROM_FIELD = os.getenv("LAC_FROM_FIELD", "LAC_FROM")
LAC_TO_FIELD = os.getenv("LAC_TO_FIELD", "LAC_TO")
CELLID_FROM_FIELD = os.getenv("CELLID_FROM_FIELD", "CELLID_FROM")
CELLID_TO_FIELD = os.getenv("CELLID_TO_FIELD", "CELLID_TO")
CODE_FROM_FIELD = os.getenv("CODE_FROM_FIELD", "CODE_FROM")
CODE_TO_FIELD = os.getenv("CODE_TO_FIELD", "CODE_TO")

# --- MSSQL credentials ---
MSSQL_USER = os.getenv("MSSQL_USER", "preprocs_login")
MSSQL_PASSWORD = os.environ["MSSQL_PASSWORD"]
MSSQL_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver"

# --- Monitoring ---
APP_NAME = os.getenv("APP_NAME", "ANALITIKA")
QUERY_NAME = os.getenv("QUERY_NAME", "SHRINK")
SPARK_UI_PORT = os.getenv("SPARK_UI_PORT", "4040")
SPARK_MONITORING_HOST = os.getenv("SPARK_MONITORING_HOST", "0.0.0.0")
SPARK_MONITORING_PORT = int(os.getenv("SPARK_MONITORING_PORT", "9109"))

# --- MSSQL: PROCESSING1 (idents / msisdn) ---
MSSQL_JDBC_URL_IDENTS = os.getenv(
    "MSSQL_JDBC_URL_IDENTS",
    "jdbc:sqlserver://processing1.:1433;databaseName=DATA_PROCESSOR;encrypt=False",
)
MSSQL_MSISDN_IDENTS_TABLE = os.getenv("MSSQL_MSISDN_IDENTS_TABLE", "DTS_SEARCH.IDENTS_MSISDN")
MSSQL_DTS_IDENTS_TABLE = os.getenv("MSSQL_IDENTS_TABLE", "DTS_SEARCH.IDENTS")
MSSQL_DTS_IDENTS_BS_TABLE = os.getenv("MSSQL_IDENTS_TABLE", "DTS_SEARCH.IDENTS_BS")
MSSQL_JDBC_URL_ROTS_GSM = os.getenv(
    "MSSQL_JDBC_URL_RULES",
    "jdbc:sqlserver://processing1.:1433;databaseName=DATA_PROCESSOR;encrypt=False",
)

# --- MSSQL: HP-STORAGE9 (target tables) ---
MSSQL_JDBC_URL_TARGET = os.getenv(
    "MSSQL_JDBC_URL_TARGET",
    "jdbc:sqlserver://hp-storage9.:1433;databaseName=TEST;encrypt=False",
)
MSSQL_TARGET_TABLE = os.getenv("MSSQL_TARGET_TABLE", "dbo.OSS_KAFKA")
MSSQL_JDBC_URL_IDENTS_TARGET = os.getenv(
    "MSSQL_JDBC_URL_TARGET",
    "jdbc:sqlserver://hp-storage9.:1433;databaseName=SOPR_DB;encrypt=False",
)
MSSQL_TARGET_IDENTS_TABLE = os.getenv("MSSQL_TARGET_TABLE", "IDENTS.OSS")
MSSQL_TARGET_TABLE_VALDAY = os.getenv("MSSQL_TARGET_TABLE_ALARM", "[TEST].[VALDAY]")
MSSQL_TARGET_TABLE_ROAD = os.getenv("MSSQL_TARGET_TABLE_ALARM", "[TEST].[ROAD]")
MSSQL_TARGET_TABLE_TEST = os.getenv("MSSQL_TARGET_TABLE_ALARM", "[TEST].[BS_TEST]")
MSSQL_TARGET_TABLE_ROL_GNEZDO = os.getenv("MSSQL_TARGET_TABLE_ALARM", "[ROL].[GNEZDO]")
MSSQL_TARGET_TABLE_PULKOVO_POLYGON = os.getenv("MSSQL_TARGET_TABLE_ALARM", "[ROL].[PULKOVO_POLYGON]")

# --- MSSQL: HEAD (lookups + ALARM target) ---
MSSQL_JDBC_HEAD = os.getenv(
    "MSSQL_JDBC_TARGET_ALARM",
    "jdbc:sqlserver://head2:1433;databaseName=HEAD;encrypt=False",
)
MSSQL_KAFKA_IDENTS_BS = os.getenv("MSSQL_KAFKA_IDENTS_ALARM", "dbo.V_KAFKA_IDENTS_BS")
MSSQL_KAFKA_IDENTS_PULKOVO = os.getenv("MSSQL_KAFKA_IDENTS_ALARM", "dbo.V_KAFKA_IDENTS_BS_PULKOVO")
MSSQL_KAFKA_IDENTS_ROAD = os.getenv("MSSQL_KAFKA_IDENTS_ALARM", "dbo.V_KAFKA_IDENTS_BS_ROAD")
MSSQL_KAFKA_IDENTS_RUCHEY = os.getenv("MSSQL_KAFKA_IDENTS_ALARM", "dbo.V_KAFKA_IDENTS_BS_RUCHEY")
MSSQL_KAFKA_IDENTS_MSISDN = os.getenv("MSSQL_KAFKA_IDENTS_ALARM", "dbo.V_KAFKA_IDENTS_MSISDN")
MSSQL_KAFKA_IDENTS_ROL = os.getenv("MSSQL_KAFKA_IDENTS_ALARM", "dbo.V_KAFKA_IDENTS_BS_ROL")
MSSQL_KAFKA_IDENTS_ALARM = os.getenv("MSSQL_KAFKA_IDENTS_ALARM", "dbo.V_KAFKA_IDENTS_ALARM")
MSSQL_KAFKA_IDENTS_NOT_ALARM = os.getenv("MSSQL_KAFKA_IDENTS_NOT_ALARM", "dbo.V_KAFKA_IDENTS_NOT_ALARM")
MSSQL_DATA_ALARM_KAFKA = os.getenv("MSSQL_TARGET_TABLE_ALARM", "ALARM.DATA_ALARM_KAFKA")

# =============================================================================
# Spark session
# =============================================================================

spark = (
    SparkSession.builder
    .master("spark://192.168.17.14:7077")
    .appName(APP_NAME)
    .config("spark.executor.memory", "64g")
    .config("spark.driver.cores", '2')
    .config("spark.driver.memory", '16g')
    .config("spark.executor.cores", '4')
    .config("spark.executor.instances", '6')
    .config("spark.dynamicAllocation.enabled", 'true')
    .config("spark.dynamicAllocation.initialExecutors", '1')
    .config("spark.dynamicAllocation.minExecutors", '0')
    .config("spark.dynamicAllocation.maxExecutors", '16')
    .config('spark.sql.adaptive,enabled', 'false')  # NB: original key has comma typo, kept verbatim
    .config("spark.sql.shuffle.partitions", "200")
    .config("spark.sql.execution.arrow.pyspark.enabled", "true")
    .config("spark.sql.mapKeyDedupPolicy", "LAST_WIN")
    .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    .config("spark.ui.port", SPARK_UI_PORT)
    .config("spark.metrics.namespace", APP_NAME)
    .config("spark.sql.streaming.metricsEnabled", "true")
    .getOrCreate()
)
spark.sparkContext.setLogLevel("WARN")

streaming_monitoring = install_streaming_monitoring(
    spark,
    application=APP_NAME,
    host=SPARK_MONITORING_HOST,
    port=SPARK_MONITORING_PORT,
)

# =============================================================================
# Helpers
# =============================================================================


def lit_int(name: str, value: int = 0):
    """Integer literal column with a name. Shorthand for the recurring
    `F.lit(0).alias(name).cast('integer')` pattern."""
    return F.lit(value).cast('integer').alias(name)


def lit_str(name: str, value: str = ''):
    """String literal column with a name."""
    return F.lit(value).cast('string').alias(name)


def in_any_range(col, ranges):
    """Build `col.between(lo1, hi1) | col.between(lo2, hi2) | ...` from a
    list of (lo, hi) tuples."""
    cond = F.lit(False)
    for lo, hi in ranges:
        cond = cond | col.between(lo, hi)
    return cond


def read_jdbc(url: str, table: str) -> DataFrame:
    """Standard JDBC read against MSSQL with shared credentials/driver."""
    return (
        spark.read.format("jdbc")
        .option("url", url)
        .option("user", MSSQL_USER)
        .option("password", MSSQL_PASSWORD)
        .option("dbtable", table)
        .option("driver", MSSQL_DRIVER)
        .load()
    )


def write_mssql(df: DataFrame, url_target: str, target_table: str) -> None:
    """Append-write a DataFrame to MSSQL; log and swallow errors."""
    try:
        (
            df.write
            .format('jdbc')
            .option("url", url_target)
            .option("user", MSSQL_USER)
            .option("password", MSSQL_PASSWORD)
            .option("dbtable", target_table)
            .option("driver", MSSQL_DRIVER)
            .mode("append")
            .save()
        )
    except Exception as e:
        print(e)


def resolve_reader_schema() -> str:
    """Resolve Avro reader schema from (1) inline string, (2) file, or
    (3) Confluent-compatible Schema Registry."""
    if READER_SCHEMA_STR.strip():
        json.loads(READER_SCHEMA_STR)  # validate JSON
        return READER_SCHEMA_STR
    if READER_SCHEMA_FILE.strip():
        with open(READER_SCHEMA_FILE, "r", encoding="utf-8") as f:
            txt = f.read()
        json.loads(txt)
        return txt
    url = REGISTRY_COMPAT_URL.rstrip("/") + f"/subjects/{SCHEMA_SUBJECT}/versions/latest"
    with urllib.request.urlopen(url, timeout=10) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    return data["schema"]


READER_AVRO_SCHEMA = resolve_reader_schema()

# Strip Confluent wire format header (0x00 magic byte + 4-byte schema id).
WireInfoType = T.StructType([
    T.StructField("payload", T.BinaryType(), True),
    T.StructField("schema_id", T.IntegerType(), True),
    T.StructField("error", T.StringType(), True),
])


@F.udf(WireInfoType)
def extract_wire_info(v: bytes):
    try:
        if v is None or len(v) == 0:
            return (None, None, "empty_value")
        if v[0] == 0 and len(v) >= 5:
            sid = int.from_bytes(v[1:5], "big", signed=False)
            return (v[5:], sid, None)
        return (v, None, None)
    except Exception as e:
        return (None, None, f"wire_parse_error: {str(e)}")


def write_to_kafka(ds, checkpoint_dir: str, qname: str):
    """Start a streaming write back to Kafka with checkpointing."""
    return (
        ds.writeStream
        .queryName(qname)
        .format("kafka")
        .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP)
        .option("checkpointLocation", os.path.join(CHECKPOINT_LOCATION, checkpoint_dir))
        .outputMode("append")
        .start()
    )


# =============================================================================
# Phone-number ranges (used by foreign / non-Russian filters)
# =============================================================================

# 10-digit "foreign" ranges used to flag non-Russian counterpart numbers.
FOREIGN_10DIGIT_RANGES = [
    (8200000000, 8300000000),
    (8400000000, 8500000000),
    (8500000000, 8510000000),
    (8520000000, 8530000000),
    (8530000000, 8540000000),
    (8600000000, 8700000000),
    (8800000000, 8810000000),
    (4210000000, 4220000000),
    (4230000000, 4240000000),
    (4300000000, 4900000000),
    (3200000000, 3300000000),
    (3520000000, 3560000000),
    (3580000000, 3700000000),
    (3710000000, 3730000000),
    (3760000000, 3780000000),
    (3810000000, 3830000000),
    (3900000000, 4000000000),
    (2000000000, 3000000000),
    (5000000000, 7000000000),
]

# Russian 11-digit prefixes (74…, 73…, 78…, 79…) — these are *excluded* from
# the "foreign 11-digit" branch.
RUSSIAN_11DIGIT_RANGES = [
    (79000000000, 79999999999),
    (78000000000, 78999999999),
    (74000000000, 74999999999),
    (73000000000, 73999999999),
]


def is_foreign_11digit(col):
    """True when the number is an 11-digit foreign number: not in the
    Russian 11-digit prefixes and greater than 10_000_000_000."""
    return (~in_any_range(col, RUSSIAN_11DIGIT_RANGES)) & (col > 10000000000)


def is_foreign_10digit(col):
    """True when the number falls into one of the foreign 10-digit ranges."""
    return in_any_range(col, FOREIGN_10DIGIT_RANGES)


# =============================================================================
# Streaming source: Kafka -> wire-strip -> Avro decode -> flatten
# =============================================================================

source = (
    spark.readStream.format("kafka")
    .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP)
    .option("subscribe", INPUT_TOPICS)
    .option("kafka.consumer.commit.auto.enable", "false")
    .option("kafka.consumer.enable.auto.commit", "false")
    .option("startingOffsets", STARTING_OFFSETS)
    .option("failOnDataLoss", "false")
    .option("includeHeaders", "true")
    .load()
)

with_wire = source.select(
    F.col("key").alias("in_key"),
    F.col("value").alias("in_value"),
    extract_wire_info(F.col("value")).alias("wire"),
).select(
    "in_key", "in_value",
    F.col("wire.payload").alias("payload"),
    F.col("wire.schema_id").alias("schema_id"),
    F.col("wire.error").alias("wire_error"),
)

decoded = with_wire.select(
    "in_key", "in_value", "schema_id", "wire_error",
    from_avro(F.col("payload"), READER_AVRO_SCHEMA, {"mode": "PERMISSIVE"}).alias("obj"),
)

routed_base = decoded.select(
    "in_key", "in_value", "schema_id", "wire_error", "obj",
    F.col("obj.STAT_TYPE").alias("CALL_TYPE"),
    F.col("obj.PHONE_FROM").alias("TEL_FROM"),
    F.col("obj.DURATION").alias("DURATION"),
    F.col("obj.PHONE_TO").alias("TEL_TO"),
    F.col("obj.DATE_TIME").alias("DATE_TIME"),
    F.col("obj.IMSI_FROM").alias("IMSI_FROM"),
    F.col("obj.IMSI_TO").alias("IMSI_TO"),
    F.col("obj.IMEI_FROM").alias("IMEI_FROM"),
    F.col("obj.IMEI_TO").alias("IMEI_TO"),
    F.col(f"obj.{LAC_FROM_FIELD}").alias("LAC_FROM"),
    F.col(f"obj.{CELLID_FROM_FIELD}").alias("CELLID_FROM"),
    F.col(f"obj.{CODE_FROM_FIELD}").alias("CODE_FROM"),
    F.col(f"obj.{LAC_TO_FIELD}").alias("LAC_TO"),
    F.col(f"obj.{CELLID_TO_FIELD}").alias("CELLID_TO"),
    F.col(f"obj.{CODE_TO_FIELD}").alias("CODE_TO"),
)

# Errors routed to a separate Kafka topic (defined here so it can be wired
# up later if needed).
parse_error_reason = (
    F.when(F.col("wire_error").isNotNull(),
           F.concat(F.lit("wire_error: "), F.col("wire_error")))
    .when(F.col("obj").isNull(), F.lit("from_avro_failed"))
)

errors_parse_ds = routed_base.where(parse_error_reason.isNotNull()).select(
    F.col("in_key").cast("binary").alias("key"),
    F.col("in_value").alias("value"),
    F.lit(ERRORS_TOPIC).alias("topic"),
)

# =============================================================================
# Lookup tables (cached in driver; loaded once at startup)
# =============================================================================

# MSISDN idents — used to identify subscribers of the home operator.
kafka_IDENTS_msisdn = read_jdbc(MSSQL_JDBC_HEAD, MSSQL_KAFKA_IDENTS_MSISDN).select(
    F.col("ident").cast("string").alias("ident"),
    F.col("idident").alias("ID_ident"),
    F.col("GP").cast("string"),
).cache()

# Non-alarm idents (TYPE 2 = MSISDN, 19 = IMSI, 20 = IMEI).
kafka_IDENTS_not_alarm = read_jdbc(MSSQL_JDBC_HEAD, MSSQL_KAFKA_IDENTS_NOT_ALARM).select(
    F.col("IDENTIFICATOR"),
    F.col("UID"),
    F.col("THEME").cast("string"),
).cache()

# Alarm idents (same TYPE codes).
kafka_IDENTS_alarm = read_jdbc(MSSQL_JDBC_HEAD, MSSQL_KAFKA_IDENTS_ALARM).select(
    F.col("IDENTIFICATOR"),
    F.col("UID"),
    F.col("THEME").cast("string"),
).cache()


def _bs_select(df: DataFrame) -> DataFrame:
    """Common projection for base-station lookup tables."""
    return df.select(
        F.col("REMARK").cast('string'),
        F.col("LAC").cast('integer'),
        F.col("CELLID"),
        F.col("CODE"),
    ).cache()


kafka_IDENTS_bs = F.broadcast(_bs_select(read_jdbc(MSSQL_JDBC_HEAD, MSSQL_KAFKA_IDENTS_BS)))
kafka_IDENTS_pulkovo = _bs_select(read_jdbc(MSSQL_JDBC_HEAD, MSSQL_KAFKA_IDENTS_PULKOVO))
kafka_IDENTS_road = _bs_select(read_jdbc(MSSQL_JDBC_HEAD, MSSQL_KAFKA_IDENTS_ROAD))
kafka_IDENTS_ruchey = _bs_select(read_jdbc(MSSQL_JDBC_HEAD, MSSQL_KAFKA_IDENTS_RUCHEY))

# ROL has no REMARK column.
kafka_IDENTS_bs_rol = read_jdbc(MSSQL_JDBC_HEAD, MSSQL_KAFKA_IDENTS_ROL).select(
    F.col("LAC").cast('integer'),
    F.col("CELLID"),
    F.col("CODE"),
).cache()

# Pre-split idents by TYPE so the streaming joins don't refilter each batch.
kafka_IDENTS_not_alarm_2 = kafka_IDENTS_not_alarm.filter(F.col("TYPE") == 2)
kafka_IDENTS_not_alarm_19 = kafka_IDENTS_not_alarm.filter(F.col("TYPE") == 19)
kafka_IDENTS_not_alarm_20 = kafka_IDENTS_not_alarm.filter(F.col("TYPE") == 20)

kafka_IDENTS_alarm_2 = kafka_IDENTS_alarm.filter(F.col("TYPE") == 2)
kafka_IDENTS_alarm_19 = kafka_IDENTS_alarm.filter(F.col("TYPE") == 19)
kafka_IDENTS_alarm_20 = kafka_IDENTS_alarm.filter(F.col("TYPE") == 20)


# =============================================================================
# Column projections (OSS_KAFKA / IDENTS_OSS / ALARM target schemas)
# =============================================================================

def select_oss_kafka(df: DataFrame, *, direction: int, gp_col=None) -> DataFrame:
    """Select columns matching the OSS_KAFKA target schema.

    direction=0: keep TEL_FROM / TEL_TO orientation.
    direction=1: swap TEL_FROM<->TEL_TO and the related IMSI/IMEI/CODE/LAC/CELLID
                 columns (the call is being attributed to the other party).
    gp_col: column expression for GP. Defaults to empty-string literal.
    """
    if gp_col is None:
        gp_col = lit_str('GP')

    if direction == 0:
        return df.select(
            'DATE_TIME', 'DURATION', 'CALL_TYPE',
            'TEL_FROM', 'IMSI_FROM', 'IMEI_FROM', 'TEL_TO',
            lit_int('ID_TO'), lit_int('MSRN'),
            'IMSI_TO', 'IMEI_TO',
            'CODE_FROM', lit_int('MCC_FROM'), lit_int('MNC_FROM'),
            'LAC_FROM', 'CELLID_FROM',
            'CODE_TO', lit_int('MCC_TO'), lit_int('MNC_TO'),
            'LAC_TO', 'CELLID_TO',
            lit_int('SERVICE_CENTER_FROM'), lit_int('SERVICE_CENTER_TO'),
            'ID_ident', lit_int('DIRECTION', 0),
            gp_col,
        )

    # direction == 1: mirror the call.
    return df.select(
        'DATE_TIME', 'DURATION', 'CALL_TYPE',
        F.col('TEL_TO').alias('TEL_FROM'),
        F.col('IMSI_TO').alias('IMSI_FROM'),
        F.col('IMEI_TO').alias('IMEI_FROM'),
        F.col('TEL_FROM').alias('TEL_TO'),
        lit_int('ID_TO'), lit_int('MSRN'),
        F.col('IMSI_FROM').alias('IMSI_TO'),
        F.col('IMEI_FROM').alias('IMEI_TO'),
        F.col('CODE_TO').alias('CODE_FROM'),
        lit_int('MCC_FROM'), lit_int('MNC_FROM'),
        F.col('LAC_TO').alias('LAC_FROM'),
        F.col('CELLID_TO').alias('CELLID_FROM'),
        F.col('CODE_FROM').alias('CODE_TO'),
        lit_int('MCC_TO'), lit_int('MNC_TO'),
        F.col('LAC_FROM').alias('LAC_TO'),
        F.col('CELLID_FROM').alias('CELLID_TO'),
        lit_int('SERVICE_CENTER_FROM'), lit_int('SERVICE_CENTER_TO'),
        'ID_ident', lit_int('DIRECTION', 1),
        gp_col,
    )


def select_idents_oss(df: DataFrame) -> DataFrame:
    """Select columns matching the IDENTS_OSS (non-alarm) target schema."""
    return df.select(
        'DATE_TIME', 'DURATION', 'CALL_TYPE',
        'TEL_FROM', 'IMSI_FROM', 'IMEI_FROM', 'TEL_TO',
        lit_int('MSRN'), 'IMSI_TO', 'IMEI_TO',
        'CODE_FROM', lit_int('MCC_FROM'), lit_int('MNC_FROM'),
        'LAC_FROM', 'CELLID_FROM',
        'CODE_TO', lit_int('MCC_TO'), lit_int('MNC_TO'),
        'LAC_TO', 'CELLID_TO',
        lit_int('SERVICE_CENTER_FROM'), lit_int('SERVICE_CENTER_TO'),
        F.col('IDENTIFICATOR').alias('UID'), 'THEME',
    ).distinct()


def select_alarm(df: DataFrame, *, uid_as_raw: bool = False) -> DataFrame:
    """Select columns matching the DATA_ALARM_KAFKA target schema.

    uid_as_raw=True: keep IDENTIFICATOR as-is (no UID alias). Preserves the
    original behaviour of imei_from_df_alarm — see notes at top of file.
    """
    uid_col = 'IDENTIFICATOR' if uid_as_raw else F.col('IDENTIFICATOR').alias('UID')
    return df.select(
        'DATE_TIME', 'DURATION', 'CALL_TYPE',
        'TEL_FROM', 'IMSI_FROM', 'IMEI_FROM',
        lit_str('ID_FROM'),
        'TEL_TO', lit_int('MSRN'),
        'IMSI_TO', 'IMEI_TO', lit_str('ID_TO'),
        'CODE_FROM', lit_int('MCC_FROM'), lit_int('MNC_FROM'),
        'LAC_FROM', 'CELLID_FROM',
        'CODE_TO', lit_int('MCC_TO'), lit_int('MNC_TO'),
        'LAC_TO', 'CELLID_TO',
        lit_int('SERVICE_CENTER_FROM'), lit_int('SERVICE_CENTER_TO'),
        lit_str('MSG'), uid_col, 'THEME',
    )


def select_bs_match(df: DataFrame, *, side: str, distinct: bool = True) -> DataFrame:
    """Select columns for the simple BS-match outputs (ruchey, TEST).

    side='from' uses TEL_FROM/IMSI_FROM/IMEI_FROM; side='to' uses *_TO.
    """
    if side == 'from':
        cols = [
            F.col('TEL_FROM').alias('ID'),
            F.col('IMSI_FROM').alias('IMSI'),
            F.col('IMEI_FROM').alias('IMEI'),  # NB: ruchey/TEST_from use this
        ]
    else:
        cols = [
            F.col('TEL_TO').alias('ID'),
            F.col('IMSI_TO').alias('IMSI'),
            F.col('IMEI_TO').alias('IMEI'),
        ]
    out = df.select(*cols, lit_int('TYPE'), F.col('REMARK'), F.col("DATE_TIME"))
    return out.distinct() if distinct else out


# =============================================================================
# Per-batch processing
# =============================================================================


def _opers_branch(kafka_df: DataFrame, *, tel_col: str, other_tel_col: str,
                  direction: int, with_real_gp: bool) -> DataFrame:
    """Operator-subscriber branch: join idents on `tel_col`, require ident
    to be present, and emit OSS_KAFKA rows with the requested direction."""
    join_cond = (kafka_df[tel_col] == kafka_IDENTS_msisdn.ident)

    # Note: direction=0 original branch adds an extra `withColumn("ID_TO", ...)`
    # and a redundant dropna(subset=['ident']); both are preserved verbatim.
    if direction == 0:
        right = kafka_IDENTS_msisdn.withColumn("ID_TO", F.lit(0).cast('integer'))
        joined = kafka_df.join(right, join_cond, how='left_outer')
    else:
        joined = kafka_df.join(kafka_IDENTS_msisdn, join_cond, how='left_outer')

    filtered = joined.filter(
        (kafka_df[other_tel_col] != 0)
        & (kafka_IDENTS_msisdn.ident.isNotNull())
        & (kafka_df.TEL_FROM != kafka_df.TEL_TO)
    )
    if direction == 0:
        filtered = filtered.dropna(subset=['ident'])

    gp_col = F.col('GP') if with_real_gp else None
    return select_oss_kafka(filtered, direction=direction, gp_col=gp_col)


def _foreign_11digit_branch(kafka_df: DataFrame, *, tel_col: str,
                            other_tel_col: str, direction: int) -> DataFrame:
    """Foreign 11-digit branch: counterpart is non-MSISDN and not in the
    Russian 11-digit ranges."""
    joined = kafka_df.join(
        kafka_IDENTS_msisdn,
        kafka_df[tel_col] == kafka_IDENTS_msisdn.ident,
        how='left_outer',
    )
    filtered = joined.filter(
        (kafka_df[other_tel_col] != 0)
        & (kafka_IDENTS_msisdn.ident.isNull())
        & is_foreign_11digit(F.col(tel_col))
        & (kafka_df.TEL_TO != kafka_df.TEL_FROM)
    )
    return select_oss_kafka(filtered, direction=direction)


def _foreign_10digit_branch(kafka_df: DataFrame, *, tel_col: str,
                            other_tel_col: str, imsi_col: str,
                            direction: int) -> DataFrame:
    """Foreign 10-digit branch: counterpart falls into one of the foreign
    10-digit ranges and has no usable IMSI."""
    joined = kafka_df.join(
        kafka_IDENTS_msisdn,
        kafka_df[tel_col] == kafka_IDENTS_msisdn.ident,
        how='left_outer',
    )
    filtered = joined.filter(
        (kafka_df[other_tel_col] != 0)
        & (kafka_IDENTS_msisdn.ident.isNull())
        & is_foreign_10digit(kafka_df[tel_col])
        & (kafka_df.TEL_FROM != kafka_df.TEL_TO)
        & ((kafka_df[imsi_col].isNull()) | (kafka_df[imsi_col] == 0))
    )
    return select_oss_kafka(filtered, direction=direction)


def _not_russian_branch(kafka_df: DataFrame, *, tel_col: str,
                        other_tel_col: str, imsi_col: str,
                        join_tel_col: str, direction: int) -> DataFrame:
    """Non-Russian branch: counterpart is in the 10-digit space, has an
    IMSI present, and the IMSI is *not* a Russian (250...) IMSI.

    NB on `join_tel_col`: the original code joins on TEL_TO in BOTH the
    direction=0 and direction=1 not-russian branches (likely a typo in the
    FROM variant), so we preserve that asymmetry here.
    """
    joined = kafka_df.join(
        kafka_IDENTS_msisdn,
        kafka_df[join_tel_col] == kafka_IDENTS_msisdn.ident,
        how='left_outer',
    )
    filtered = joined.filter(
        (kafka_df[other_tel_col] != 0)
        & (kafka_IDENTS_msisdn.ident.isNull())
        & (kafka_df.TEL_TO != kafka_df.TEL_FROM)
        & (kafka_df[tel_col].between(1000000000, 10000000000))
        & (kafka_df[imsi_col] != 0)
        & (kafka_df[imsi_col].isNotNull())
        & (~F.col(imsi_col).between(250000000000000, 251000000000000))
    )
    return select_oss_kafka(filtered, direction=direction)


def _idents_branch(kafka_df: DataFrame, ident_table: DataFrame,
                   kafka_col: str) -> DataFrame:
    """Inner-join kafka_df on a single column to an idents table and
    emit IDENTS_OSS rows."""
    joined = kafka_df.join(
        ident_table,
        kafka_df[kafka_col] == ident_table.IDENTIFICATOR,
        how='inner',
    )
    return select_idents_oss(joined)


def _alarm_branch(kafka_df: DataFrame, ident_table: DataFrame,
                  kafka_col: str, *, uid_as_raw: bool = False) -> DataFrame:
    """Inner-join kafka_df on a single column to an ALARM idents table
    and emit DATA_ALARM_KAFKA rows."""
    joined = kafka_df.join(
        ident_table,
        kafka_df[kafka_col] == ident_table.IDENTIFICATOR,
        how='inner',
    )
    return select_alarm(joined, uid_as_raw=uid_as_raw)


def _bs_polygon_match(kafka_df: DataFrame, bs_table: DataFrame, *,
                      side: str) -> DataFrame:
    """Join kafka_df to a base-station polygon table on (CODE, LAC, CELLID)."""
    if side == 'from':
        cond = (
            (kafka_df.CODE_FROM == bs_table.CODE)
            & (kafka_df.LAC_FROM == bs_table.LAC)
            & (kafka_df.CELLID_FROM == bs_table.CELLID)
        )
        tel_filter = kafka_df.TEL_FROM.isNotNull() & (
            (kafka_df.TEL_FROM != 0) | (kafka_df.IMSI_FROM != 0)
        )
    else:
        cond = (
            (kafka_df.CODE_TO == bs_table.CODE)
            & (kafka_df.LAC_TO == bs_table.LAC)
            & (kafka_df.CELLID_TO == bs_table.CELLID)
        )
        tel_filter = kafka_df.TEL_TO.isNotNull() & (
            (kafka_df.TEL_TO != 0) | (kafka_df.IMSI_TO != 0)
        )
    return kafka_df.join(bs_table, cond, how='inner').filter(tel_filter)


def global_process_batch(batch_df: DataFrame, batch_id: int) -> None:
    """Per-microbatch handler: split batch into all output streams and write
    each to its MSSQL target table."""
    kafka_df = batch_df

    # -----------------------------------------------------------------------
    # OSS_KAFKA: 4 categories x 2 directions = 8 branches
    # -----------------------------------------------------------------------
    oss_branches = [
        # direction=0: counterpart is TEL_TO (call destination)
        _opers_branch(kafka_df, tel_col='TEL_TO', other_tel_col='TEL_FROM',
                      direction=0, with_real_gp=True),
        _foreign_11digit_branch(kafka_df, tel_col='TEL_TO',
                                other_tel_col='TEL_FROM', direction=0),
        _foreign_10digit_branch(kafka_df, tel_col='TEL_TO',
                                other_tel_col='TEL_FROM', imsi_col='IMSI_TO',
                                direction=0),
        _not_russian_branch(kafka_df, tel_col='TEL_TO',
                            other_tel_col='TEL_FROM', imsi_col='IMSI_TO',
                            join_tel_col='TEL_TO', direction=0),
        # direction=1: counterpart is TEL_FROM (mirror the call)
        _opers_branch(kafka_df, tel_col='TEL_FROM', other_tel_col='TEL_TO',
                      direction=1, with_real_gp=False),
        _foreign_11digit_branch(kafka_df, tel_col='TEL_FROM',
                                other_tel_col='TEL_TO', direction=1),
        _foreign_10digit_branch(kafka_df, tel_col='TEL_FROM',
                                other_tel_col='TEL_TO', imsi_col='IMSI_FROM',
                                direction=1),
        # NB: original code joins not_russian_from on TEL_TO (likely a typo),
        # preserved here.
        _not_russian_branch(kafka_df, tel_col='TEL_FROM',
                            other_tel_col='TEL_TO', imsi_col='IMSI_FROM',
                            join_tel_col='TEL_TO', direction=1),
    ]
    combined_stream_union_kafka_oss = oss_branches[0]
    for b in oss_branches[1:]:
        combined_stream_union_kafka_oss = combined_stream_union_kafka_oss.unionAll(b)

    # -----------------------------------------------------------------------
    # IDENTS_OSS: non-alarm matches on phone / IMSI / IMEI (both sides)
    # -----------------------------------------------------------------------
    phone_from_df = _idents_branch(kafka_df, kafka_IDENTS_not_alarm_2, 'TEL_FROM')
    phone_to_df = _idents_branch(kafka_df, kafka_IDENTS_not_alarm_2, 'TEL_TO')
    imsi_from_df = _idents_branch(kafka_df, kafka_IDENTS_not_alarm_19, 'IMSI_FROM')

    # NB: this preserves an oddity from the original — the join is against
    # kafka_IDENTS_not_alarm_19 but the equality references
    # kafka_IDENTS_not_alarm_2.IDENTIFICATOR. Kept verbatim.
    imsi_to_df = kafka_df.join(
        kafka_IDENTS_not_alarm_19,
        kafka_df.IMSI_TO == kafka_IDENTS_not_alarm_2.IDENTIFICATOR,
        how='inner',
    )
    imsi_to_df = select_idents_oss(imsi_to_df)

    imei_from_df = _idents_branch(kafka_df, kafka_IDENTS_not_alarm_20, 'IMEI_FROM')
    imei_to_df = _idents_branch(kafka_df, kafka_IDENTS_not_alarm_20, 'IMEI_TO')

    union_IDENTS_oss = (
        phone_from_df.union(phone_to_df)
        .union(imsi_from_df)
        .union(imsi_to_df)
        .union(imei_to_df)
        .union(imei_from_df)
    )

    # -----------------------------------------------------------------------
    # DATA_ALARM_KAFKA: alarm matches on phone / IMSI / IMEI (both sides)
    # -----------------------------------------------------------------------
    phone_from_df_alarm = _alarm_branch(kafka_df, kafka_IDENTS_alarm_2, 'TEL_FROM')
    phone_to_df_alarm = _alarm_branch(kafka_df, kafka_IDENTS_alarm_2, 'TEL_TO')
    imsi_from_df_alarm = _alarm_branch(kafka_df, kafka_IDENTS_alarm_19, 'IMSI_FROM')
    imsi_to_df_alarm = _alarm_branch(kafka_df, kafka_IDENTS_alarm_19, 'IMSI_TO')
    # NB: imei_from_df_alarm in the original keeps the raw IDENTIFICATOR
    # column instead of aliasing it to UID. Preserved via uid_as_raw=True.
    imei_from_df_alarm = _alarm_branch(kafka_df, kafka_IDENTS_alarm_20,
                                       'IMEI_FROM', uid_as_raw=True)
    imei_to_df_alarm = _alarm_branch(kafka_df, kafka_IDENTS_alarm_20, 'IMEI_TO')

    # NB: the original code unions phone_from_df_alarm TWICE (not phone_to/from
    # symmetric). This duplicates those rows in the output. Preserved verbatim.
    union_IDENTS_alarm = (
        phone_from_df_alarm.unionAll(phone_to_df_alarm)
        .unionAll(phone_from_df_alarm)
        .unionAll(imsi_from_df_alarm)
        .unionAll(imsi_to_df_alarm)
        .unionAll(imei_from_df_alarm)
        .unionAll(imei_to_df_alarm)
    )

    # -----------------------------------------------------------------------
    # RUCHEY: BS-polygon match -> deduped (ID, IMSI, IMEI, REMARK, DATE_TIME)
    # -----------------------------------------------------------------------
    ruchey_union = select_bs_match(
        _bs_polygon_match(kafka_df, kafka_IDENTS_ruchey, side='from'),
        side='from',
    ).union(
        select_bs_match(
            _bs_polygon_match(kafka_df, kafka_IDENTS_ruchey, side='to'),
            side='to',
        )
    )

    # -----------------------------------------------------------------------
    # ROAD: BS-polygon match -> aggregated (min/max/count of DATE_TIME)
    # -----------------------------------------------------------------------
    def _road_side(side: str) -> DataFrame:
        matched = _bs_polygon_match(kafka_df, kafka_IDENTS_road, side=side)
        id_col = 'TEL_FROM' if side == 'from' else 'TEL_TO'
        imsi_col = 'IMSI_FROM' if side == 'from' else 'IMSI_TO'
        imei_col = 'IMEI_FROM' if side == 'from' else 'IMEI_TO'
        return (
            matched.groupBy(
                F.col(id_col).alias('ID'),
                F.col(imsi_col).alias('IMSI'),
                F.col(imei_col).alias('IMEI'),
                F.col('REMARK'),
            )
            .agg(
                F.min('DATE_TIME').alias('MIN_DATE_TIME'),
                F.max('DATE_TIME').alias('MAX_DATE_TIME'),
                F.count('*').alias('COUNT'),
            )
            .select('ID', 'IMSI', 'IMEI', 'REMARK',
                    'MIN_DATE_TIME', 'MAX_DATE_TIME', 'COUNT')
        )

    road_union = _road_side('from').union(_road_side('to'))

    # -----------------------------------------------------------------------
    # TEST: BS-polygon match (BS table) -> deduped, includes CODE/LAC/CELLID
    # -----------------------------------------------------------------------
    def _test_side(side: str) -> DataFrame:
        matched = _bs_polygon_match(kafka_df, kafka_IDENTS_bs, side=side)
        if side == 'from':
            id_cols = [
                F.col('TEL_FROM').alias('ID'),
                F.col('IMSI_FROM').alias('IMSI'),
                F.col('IMEI_TO').alias('IMEI'),  # NB: TEST_from uses IMEI_TO,
                                                 #     not IMEI_FROM. Preserved.
            ]
        else:
            id_cols = [
                F.col('TEL_TO').alias('ID'),
                F.col('IMSI_TO').alias('IMSI'),
                F.col('IMEI_TO').alias('IMEI'),
            ]
        return matched.select(
            *id_cols, lit_int('TYPE'),
            F.col('REMARK'), F.col("DATE_TIME"),
            'CODE', 'LAC', 'CELLID',
        ).distinct()

    TEST_result = _test_side('from').union(_test_side('to'))

    # -----------------------------------------------------------------------
    # GNEZDO (ROL): join idents AND ROL BS-polygon
    # -----------------------------------------------------------------------
    def _gnezdo_side(side: str) -> DataFrame:
        tel_col = 'TEL_FROM' if side == 'from' else 'TEL_TO'
        code_col = 'CODE_FROM' if side == 'from' else 'CODE_TO'
        lac_col = 'LAC_FROM' if side == 'from' else 'LAC_TO'
        cell_col = 'CELLID_FROM' if side == 'from' else 'CELLID_TO'
        return (
            kafka_df
            .join(kafka_IDENTS_msisdn,
                  kafka_df[tel_col] == kafka_IDENTS_msisdn.ident, how='inner')
            .join(
                kafka_IDENTS_bs_rol,
                (kafka_df[code_col] == kafka_IDENTS_bs_rol.CODE)
                & (kafka_df[lac_col] == kafka_IDENTS_bs_rol.LAC)
                & (kafka_df[cell_col] == kafka_IDENTS_bs_rol.CELLID),
                how='inner',
            )
            .filter(kafka_df[tel_col].isNotNull() & (kafka_df[tel_col] != 0))
            .select(
                F.col('DATE_TIME'),
                F.col(tel_col).alias('MSISDN'),
                F.col('ID_ident').alias("IDident"),
                F.col('GP'),
                F.col(code_col).alias('CODE'),
                F.col(lac_col).alias('LAC'),
                F.col(cell_col).alias('CELLID'),
                lit_str('HASHTAG'),
            )
            .distinct()
        )

    gnezdo_result = _gnezdo_side('from').union(_gnezdo_side('to'))

    # -----------------------------------------------------------------------
    # PULKOVO: BS-polygon match -> day/MSISDN/IMSI/IMEI projection
    # -----------------------------------------------------------------------
    def _pulkovo_side(side: str, distinct: bool) -> DataFrame:
        if side == 'from':
            cond = (
                (kafka_df.CODE_FROM == kafka_IDENTS_pulkovo.CODE)
                & (kafka_df.LAC_FROM == kafka_IDENTS_pulkovo.LAC)
                & (kafka_df.CELLID_FROM == kafka_IDENTS_pulkovo.CELLID)
            )
            tel_filter = kafka_df.TEL_FROM.isNotNull() & (kafka_df.TEL_FROM != 0)
            id_cols = [
                F.col('TEL_FROM').alias('MSISDN'),
                F.col('IMSI_FROM').alias('IMSI'),
                F.col('IMEI_FROM').alias("IMEI"),
            ]
        else:
            cond = (
                (kafka_df.CODE_TO == kafka_IDENTS_pulkovo.CODE)
                & (kafka_df.LAC_TO == kafka_IDENTS_pulkovo.LAC)
                & (kafka_df.CELLID_TO == kafka_IDENTS_pulkovo.CELLID)
            )
            tel_filter = kafka_df.TEL_TO.isNotNull() & (kafka_df.TEL_TO != 0)
            id_cols = [
                F.col('TEL_TO').alias('MSISDN'),
                F.col('IMSI_TO').alias('IMSI'),
                F.col('IMEI_TO').alias("IMEI"),
            ]
        out = (
            kafka_df.join(kafka_IDENTS_pulkovo, cond, how='inner')
            .filter(tel_filter)
            .select(
                F.dayofmonth(F.col('DATE_TIME')).alias('DAY_OF_MONTH'),
                F.col('DATE_TIME'),
                *id_cols,
                F.lit('#SPB_PULKOVO').alias('HASHTAG'),
            )
        )
        # NB: original pulkovo_from has .distinct(), pulkovo_to does not.
        return out.distinct() if distinct else out

    pulkovo_result = _pulkovo_side('from', distinct=True).union(
        _pulkovo_side('to', distinct=False)
    )

    # -----------------------------------------------------------------------
    # Write all outputs to MSSQL.
    # -----------------------------------------------------------------------
    write_mssql(combined_stream_union_kafka_oss, MSSQL_JDBC_URL_TARGET, MSSQL_TARGET_TABLE)
    write_mssql(union_IDENTS_oss, MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_IDENTS_TABLE)
    write_mssql(union_IDENTS_alarm, MSSQL_JDBC_HEAD, MSSQL_DATA_ALARM_KAFKA)
    write_mssql(gnezdo_result, MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_TABLE_ROL_GNEZDO)
    write_mssql(ruchey_union, MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_TABLE_VALDAY)
    write_mssql(TEST_result, MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_TABLE_TEST)
    write_mssql(road_union, MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_TABLE_ROAD)
    write_mssql(pulkovo_result, MSSQL_JDBC_URL_IDENTS_TARGET, MSSQL_TARGET_TABLE_PULKOVO_POLYGON)


# =============================================================================
# Streaming start
# =============================================================================

kafka_df = routed_base.select(
    'CALL_TYPE', 'DURATION',
    'TEL_FROM', 'TEL_TO',
    'IMSI_FROM', 'IMEI_FROM',
    'IMSI_TO', 'IMEI_TO',
    'LAC_FROM', 'LAC_TO',
    'CELLID_FROM', 'CELLID_TO',
    'CODE_FROM', 'CODE_TO',
    'DATE_TIME',
).distinct()

query = (
    kafka_df.writeStream
    .foreachBatch(global_process_batch)
    .queryName(QUERY_NAME)
    .option("maxOffsetsPerTrigger", 100)
    .option("checkpointLocation", os.path.join(CHECKPOINT_LOCATION, "BILLING"))
    .option('spark.sql.streaming.forceDeleteTempCheckpointLocation', 'true')
    .outputMode("append")
    .start()
)

try:
    query.awaitTermination()
finally:
    streaming_monitoring.stop()
