# Spark 4.0.1 Structured Streaming Monitoring

Офлайн-мониторинг одного приложения `ANALITIKA` в Spark Standalone: состояние Driver/query и количество строк, прочитанных Structured Streaming из Kafka.

## Что входит

- модифицированная `app/prod_refactored.py` с embedded monitoring;
- dependency-free `StreamingQueryListener` и Prometheus endpoint `:9109/metrics`;
- Spark `metrics.properties`;
- конфигурация и alert rules Prometheus;
- provisioning datasource/dashboard Grafana;
- генератор конфигурации и проверка всех HTTP endpoints;
- unit-тесты, работающие без установленного PySpark.

Сторонних Python-библиотек для мониторинга нет. Нужны существующие Spark 4.0.1, Prometheus и Grafana. Инструкции ниже рассчитаны на Linux-серверы без Docker.

## 1. Настройка адресов

```bash
cd /opt/spark-observability
cp config/monitoring.env.example config/monitoring.env
vi config/monitoring.env
python3 scripts/configure.py
```

По умолчанию Master, Worker и Driver указаны на известном адресе `192.168.17.14`. Если Worker или Driver находятся на другой машине, измените их host в `config/monitoring.env` и повторите генерацию.

## 2. Spark

Скопируйте `generated/spark/metrics.properties` в `$SPARK_HOME/conf/metrics.properties` или передайте файл через `spark.metrics.conf`.

```bash
export MSSQL_PASSWORD='set-locally-do-not-commit'
export SPARK_UI_PORT=4040
export SPARK_MONITORING_HOST=0.0.0.0
export SPARK_MONITORING_PORT=9109
export APP_NAME=ANALITIKA
export QUERY_NAME=SHRINK

spark-submit \
  --conf spark.metrics.conf=/opt/spark-observability/generated/spark/metrics.properties \
  /opt/spark-observability/app/prod_refactored.py
```

Порт `9109/tcp` должен быть доступен с машины Prometheus. Ограничьте его firewall-правилом адресом Prometheus: endpoint не требует аутентификации и предназначен только для доверенной внутренней сети. Пароль MSSQL больше не хранится в исходнике и обязателен в окружении процесса.

Проверка Driver:

```bash
curl -fsS http://192.168.17.14:4040/metrics/prometheus/ | head
curl -fsS http://192.168.17.14:9109/metrics | grep '^spark_ss_'
```

## 3. Prometheus

`generated/prometheus/prometheus.yml` является самостоятельной минимальной конфигурацией. Если Prometheus уже содержит другие jobs, перенесите из неё шесть `spark-*` секций в существующий `scrape_configs`, скопируйте `generated/prometheus/rules/spark-rules.yml` в каталог rules и подключите его через `rule_files`.

Перед перезапуском:

```bash
promtool check config /opt/spark-observability/generated/prometheus/prometheus.yml
promtool check rules /opt/spark-observability/generated/prometheus/rules/spark-rules.yml
```

После проверки перезапустите Prometheus способом, используемым в вашем контуре.

## 4. Grafana

Скопируйте provisioning-файлы в конфигурационный каталог Grafana, а dashboard в путь `GRAFANA_DASHBOARDS_PATH`, указанный в `monitoring.env`.

```bash
cp generated/grafana/provisioning/datasources/prometheus.yml /etc/grafana/provisioning/datasources/
cp generated/grafana/provisioning/dashboards/spark.yml /etc/grafana/provisioning/dashboards/
mkdir -p /var/lib/grafana/dashboards/spark
cp generated/grafana/dashboards/spark-streaming.json /var/lib/grafana/dashboards/spark/
```

После перезапуска Grafana dashboard появится в папке `Spark` под именем `Spark Structured Streaming | ANALITIKA`.

## 5. Проверка контура

```bash
python3 scripts/check_endpoints.py --config config/monitoring.env
python3 -m unittest discover -s tests -v
```

Проверка должна видеть Master, Worker, Driver, executors, listener, History Server, Prometheus и Grafana.

## Значение метрик

- `spark_ss_query_active`: query `SHRINK` активна (`1`) или завершилась (`0`).
- `spark_ss_last_batch_input_rows`: количество строк Kafka в последнем micro-batch.
- `spark_ss_input_rows_total`: строки Kafka с момента запуска текущего Driver; после рестарта counter сбрасывается, что корректно обрабатывается Prometheus.
- `spark_ss_input_rows_per_second`: скорость поступления, рассчитанная Spark.
- `spark_ss_processed_rows_per_second`: скорость обработки, рассчитанная Spark.
- `spark_ss_last_progress_timestamp_seconds`: время последнего progress event.
- `spark_ss_trigger_duration_seconds`: длительность последнего trigger.

Это входные строки Kafka, а не сумма строк, записанных в восемь MSSQL-таблиц. Listener не запускает `count()` и не добавляет Spark jobs к micro-batch.

## Важные ограничения исходной job

- `write_mssql()` перехватывает исключения записи и только печатает их. Поэтому зелёный статус означает, что Driver и query живы, но не гарантирует успешную запись во все MSSQL-таблицы.
- `maxOffsetsPerTrigger` сейчас задан на `writeStream`, как в переданном исходнике. Для Kafka ограничение обычно задаётся на `readStream`; перенос может существенно изменить нагрузку и поэтому в этом проекте намеренно не выполнен.
- compaction rolling event logs не включена: в Spark 4.0.1 она lossy и может удалить часть истории jobs/stages.

## Откат

Для отката запустите исходную job, удалите добавленные `spark-*` scrape jobs/rules из Prometheus и provisioning-файлы Spark из Grafana. Checkpoint `BILLING` проект не изменяет и не удаляет.
