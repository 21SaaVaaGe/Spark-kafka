# NiFi Server Manager

Локальное веб-приложение (Python 3.10 + Flask + HTML/CSS/JS без CDN) для мониторинга и управления **отдельными** экземплярами Apache NiFi **1.25.0+**.

## Быстрый старт

1. Установите зависимости:

```bash
python -m pip install -r requirements.txt
```

2. Создайте файл `data/servers.yaml` на основе примера:

```bash
copy config\servers.example.yaml data\servers.yaml
```

3. Отредактируйте `data/servers.yaml` (URL NiFi, TLS, аутентификация, при необходимости `restart_shell_command`).

4. Запустите:

```bash
python run.py
```

Откройте в браузере `http://127.0.0.1:8765/`.

## Переменные окружения

- `NIFI_MANAGER_HOME` — каталог, относительно которого по умолчанию ищется `data/servers.yaml` (по умолчанию текущий рабочий каталог).
- `NIFI_MANAGER_SERVERS_CONFIG` — явный путь к YAML со списком серверов.
- `HOST`, `PORT` — bind для встроенного сервера Flask.

## Документация

Полная пояснительная записка (архитектура, ограничения, модель данных NiFi): `POYASNITELNAYA_ZAPISKA.md`.
