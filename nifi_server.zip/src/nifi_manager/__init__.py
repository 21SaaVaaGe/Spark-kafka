"""NiFi Server Manager — пакет приложения."""

__version__ = "1.0.0"
