class NiFiManagerError(Exception):
    """Базовая ошибка приложения."""


class ConfigurationError(NiFiManagerError):
    """Ошибка конфигурации (файл, формат, обязательные поля)."""


class NiFiClientError(NiFiManagerError):
    """Ошибка взаимодействия с REST API NiFi."""


class ServerNotFoundError(NiFiManagerError):
    """Сервер с указанным идентификатором не найден в конфигурации."""

    def __init__(self, server_id: str) -> None:
        super().__init__(f"Сервер не найден: {server_id}")
        self.server_id = server_id
