from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional


class AuthType(str, Enum):
    NONE = "none"
    BASIC = "basic"
    TOKEN = "token"


@dataclass(frozen=True)
class ServerConfig:
    """Запись сервера в локальной конфигурации."""

    id: str
    display_name: str
    base_url: str
    verify_ssl: bool = True
    auth_type: AuthType = AuthType.NONE
    username: Optional[str] = None
    password: Optional[str] = None
    bearer_token: Optional[str] = None
    restart_shell_command: Optional[str] = None


@dataclass
class ServerOverview:
    """Сводка по серверу для списка."""

    id: str
    display_name: str
    api_base_url: str
    reachable: bool
    controller_state: Optional[str]
    nifi_version: Optional[str]
    uri_public: Optional[str]
    root_process_group_id: Optional[str]
    queued_flow_files: int
    queued_bytes: int
    has_disabled_processors: bool
    invalid_processors: int
    stopped_processors: int
    running_processors: int
    processors_up_to_date: bool
    error_message: Optional[str] = None


@dataclass
class ProcessGroupListItem:
    id: str
    name: str
    state: Optional[str]
    running_count: Optional[int] = None
    stopped_count: Optional[int] = None
    invalid_count: Optional[int] = None
    disabled_count: Optional[int] = None
    queued_flow_files: Optional[int] = None
    bytes_queued: Optional[int] = None


@dataclass
class MetricsSample:
    """Точка данных для графиков."""

    ts: datetime
    queued_flow_files: int
    heap_used_bytes: Optional[int]
    heap_max_bytes: Optional[int]
    heap_usage_percent: Optional[float]
    active_threads: Optional[int]


@dataclass
class ServerDetail:
    """Расширенная карточка сервера."""

    overview: ServerOverview
    process_groups: list[ProcessGroupListItem] = field(default_factory=list)
    last_client_ip: Optional[str] = None
    last_client_at: Optional[datetime] = None
    restart_command_configured: bool = False


@dataclass
class AccessRecord:
    last_ip: str
    last_at: datetime
