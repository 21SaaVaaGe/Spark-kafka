from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock
from typing import Any, Optional

from nifi_manager.domain.models import AccessRecord
from nifi_manager.application.ports import AccessLogRepository


def _iso(dt: datetime) -> str:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.isoformat()


def _parse_iso(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


class JsonAccessLogRepository(AccessLogRepository):
    """Простое файловое хранилище последнего IP, с которого открывали карточку сервера."""

    def __init__(self, path: Path) -> None:
        self._path = path
        self._lock = Lock()
        self._path.parent.mkdir(parents=True, exist_ok=True)

    def _read_all(self) -> dict[str, Any]:
        if not self._path.is_file():
            return {}
        with self._path.open("r", encoding="utf-8") as fh:
            return json.load(fh)

    def _write_all(self, data: dict[str, Any]) -> None:
        tmp = self._path.with_suffix(".tmp")
        with tmp.open("w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
        tmp.replace(self._path)

    def get(self, server_id: str) -> Optional[AccessRecord]:
        with self._lock:
            data = self._read_all()
        row = data.get(server_id)
        if not row:
            return None
        return AccessRecord(last_ip=str(row["last_ip"]), last_at=_parse_iso(str(row["last_at"])))

    def record_visit(self, server_id: str, client_ip: str) -> None:
        with self._lock:
            data = self._read_all()
            data[server_id] = {"last_ip": client_ip, "last_at": _iso(datetime.now(timezone.utc))}
            self._write_all(data)
