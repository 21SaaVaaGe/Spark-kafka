from __future__ import annotations

from typing import Any, Optional

import httpx

from nifi_manager.domain.exceptions import NiFiClientError
from nifi_manager.domain.models import AuthType, ServerConfig
from nifi_manager.application.ports import NiFiGateway


def _normalize_api_root(base_url: str) -> str:
    b = base_url.rstrip("/")
    if b.endswith("/nifi-api"):
        return b
    return f"{b}/nifi-api"


class HttpxNiFiGateway(NiFiGateway):
    """Реализация NiFiGateway через HTTP/HTTPS (httpx)."""

    def __init__(self, config: ServerConfig, timeout_sec: float = 30.0) -> None:
        self._config = config
        self._root = _normalize_api_root(config.base_url)
        self._timeout = timeout_sec
        self._client = self._build_client()

    def __enter__(self) -> HttpxNiFiGateway:
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()

    def _build_client(self) -> httpx.Client:
        verify: bool | str = self._config.verify_ssl
        auth: Optional[tuple[str, str]] = None
        headers: dict[str, str] = {}
        if self._config.auth_type is AuthType.BASIC and self._config.username is not None:
            auth = (self._config.username, self._config.password or "")
        elif self._config.auth_type is AuthType.TOKEN and self._config.bearer_token:
            headers["Authorization"] = f"Bearer {self._config.bearer_token}"
        return httpx.Client(verify=verify, auth=auth, headers=headers, follow_redirects=True)

    def close(self) -> None:
        self._client.close()

    def _request_text(self, method: str, path: str, **kwargs: Any) -> str:
        url = f"{self._root}{path}"
        try:
            resp = self._client.request(method, url, timeout=self._timeout, **kwargs)
        except httpx.HTTPError as exc:
            raise NiFiClientError(f"Сетевая ошибка при обращении к NiFi ({url}): {exc}") from exc
        if resp.status_code >= 400:
            body = (resp.text or "")[:2000]
            raise NiFiClientError(f"NiFi вернул HTTP {resp.status_code} для {url}: {body}")
        return (resp.text or "").strip().strip('"')

    def _request_json(self, method: str, path: str, **kwargs: Any) -> Any:
        url = f"{self._root}{path}"
        try:
            resp = self._client.request(method, url, timeout=self._timeout, **kwargs)
        except httpx.HTTPError as exc:
            raise NiFiClientError(f"Сетевая ошибка при обращении к NiFi ({url}): {exc}") from exc
        if resp.status_code >= 400:
            body = (resp.text or "")[:2000]
            raise NiFiClientError(f"NiFi вернул HTTP {resp.status_code} для {url}: {body}")
        ctype = resp.headers.get("content-type", "")
        if "application/json" not in ctype:
            raise NiFiClientError(f"Неожиданный Content-Type от NiFi: {ctype} для {url}")
        try:
            return resp.json()
        except ValueError as exc:
            raise NiFiClientError("Ответ NiFi не является корректным JSON.") from exc

    def fetch_about(self) -> dict[str, Any]:
        data = self._request_json("GET", "/flow/about")
        if not isinstance(data, dict):
            raise NiFiClientError("/flow/about: ожидался объект JSON.")
        return data

    def fetch_flow_bootstrap(self) -> dict[str, Any]:
        """Корень потока: в NiFi 1.x данные PG надёжнее читать из /flow/process-groups/root.

        Эндпоинт ``GET /flow`` часто содержит только ``revision`` без ``processGroupFlow`` (или с
        урезанным телом в зависимости от правил прокси/версии), поэтому он используется только как
        запасной вариант при HTTP 404 на ``/root``.
        """
        url = f"{self._root}/flow/process-groups/root"
        try:
            resp = self._client.get(url, timeout=self._timeout)
        except httpx.HTTPError as exc:
            raise NiFiClientError(f"Сетевая ошибка при обращении к NiFi ({url}): {exc}") from exc
        if resp.status_code == 200:
            ctype = resp.headers.get("content-type", "")
            if "application/json" in ctype:
                try:
                    data = resp.json()
                except ValueError as exc:
                    raise NiFiClientError("Ответ NiFi (root) не является корректным JSON.") from exc
                if isinstance(data, dict):
                    return data
            raise NiFiClientError(f"Неожиданный Content-Type от NiFi: {ctype} для {url}")
        if resp.status_code == 404:
            legacy = self._request_json("GET", "/flow")
            if not isinstance(legacy, dict):
                raise NiFiClientError("/flow: ожидался объект JSON.")
            return legacy
        body = (resp.text or "")[:2000]
        raise NiFiClientError(f"NiFi вернул HTTP {resp.status_code} для {url}: {body}")

    def fetch_process_group_status(self, process_group_id: str, recursive: bool) -> dict[str, Any]:
        q = "recursive=true" if recursive else "recursive=false"
        data = self._request_json("GET", f"/flow/process-groups/{process_group_id}/status?{q}")
        if not isinstance(data, dict):
            raise NiFiClientError("status: ожидался объект JSON.")
        return data

    def fetch_process_group_flow(self, process_group_id: str) -> dict[str, Any]:
        data = self._request_json("GET", f"/flow/process-groups/{process_group_id}")
        if not isinstance(data, dict):
            raise NiFiClientError("process group flow: ожидался объект JSON.")
        return data

    def fetch_system_diagnostics(self) -> dict[str, Any]:
        data = self._request_json("GET", "/system-diagnostics")
        if not isinstance(data, dict):
            raise NiFiClientError("/system-diagnostics: ожидался объект JSON.")
        return data

    def fetch_client_id(self) -> str:
        return self._request_text("GET", "/flow/client-id")

    def fetch_process_group_entity(self, process_group_id: str) -> dict[str, Any]:
        data = self._request_json("GET", f"/process-groups/{process_group_id}")
        if not isinstance(data, dict):
            raise NiFiClientError("/process-groups/{id}: ожидался объект JSON.")
        return data

    def update_process_group_run_status(
        self,
        process_group_id: str,
        state: str,
        revision: dict[str, Any],
        client_id: str,
    ) -> dict[str, Any]:
        """Запуск/остановка всех компонентов в PG (ScheduleComponentsEntity).

        В Apache NiFi это ``PUT /flow/process-groups/{{id}}``, а не ``.../run-status``
        (последний путь относится к другим типам сущностей и для PG даёт ошибку).
        """
        body: dict[str, Any] = {
            "id": process_group_id,
            "revision": revision,
            "state": state,
            "disconnectedNodeAcknowledged": False,
        }
        data = self._request_json(
            "PUT",
            f"/flow/process-groups/{process_group_id}",
            json=body,
            headers={"Content-Type": "application/json"},
            params={"clientId": client_id},
        )
        if not isinstance(data, dict):
            raise NiFiClientError("scheduleComponents (PUT /flow/process-groups/{id}): ожидался объект JSON.")
        return data


def obtain_token_via_password(base_api_root: str, username: str, password: str, verify_ssl: bool) -> str:
    """Получение JWT по логину/паролю (NiFi с включённой аутентификацией)."""
    root = _normalize_api_root(base_api_root)
    with httpx.Client(verify=verify_ssl, follow_redirects=True) as client:
        resp = client.post(
            f"{root}/access/token",
            data={"username": username, "password": password},
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=30.0,
        )
        if resp.status_code >= 400:
            raise NiFiClientError(f"Не удалось получить токен: HTTP {resp.status_code}: {resp.text[:500]}")
        token = (resp.text or "").strip().strip('"')
        if not token:
            raise NiFiClientError("Пустой токен от /access/token.")
        return token
