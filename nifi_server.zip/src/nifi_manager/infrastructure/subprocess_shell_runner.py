from __future__ import annotations

import subprocess


class SubprocessShellRunner:
    """Запуск shell-команды на машине, где работает веб-приложение."""

    def run(self, command: str, timeout_sec: int = 180) -> tuple[int, str, str]:
        proc = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            check=False,
        )
        return proc.returncode, proc.stdout or "", proc.stderr or ""
