from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Optional

import yaml

from nifi_manager.domain.exceptions import ConfigurationError
from nifi_manager.domain.models import AuthType, ServerConfig
from nifi_manager.application.ports import ServerConfigRepository


def _parse_auth(raw: dict[str, Any]) -> tuple[AuthType, Optional[str], Optional[str], Optional[str]]:
    auth = raw.get("auth") or {}
    atype = str(auth.get("type", "none")).lower()
    try:
        auth_type = AuthType(atype)
    except ValueError as exc:
        raise ConfigurationError(f"Неизвестный тип аутентификации: {atype}") from exc
    username = auth.get("username")
    password = auth.get("password")
    token = auth.get("bearer_token")
    return auth_type, username, password, token


class YamlServerConfigRepository(ServerConfigRepository):
    """Загрузка списка серверов из YAML."""

    def __init__(self, path: Path) -> None:
        self._path = path

    def load_all(self) -> list[ServerConfig]:
        if not self._path.is_file():
            raise ConfigurationError(
                f"Файл конфигурации не найден: {self._path}. "
                f"Скопируйте config/servers.example.yaml в {self._path} и отредактируйте."
            )
        with self._path.open("r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
        servers = data.get("servers")
        if not isinstance(servers, list) or not servers:
            raise ConfigurationError("В конфигурации отсутствует непустой список servers.")
        result: list[ServerConfig] = []
        for item in servers:
            if not isinstance(item, dict):
                raise ConfigurationError("Каждый элемент servers должен быть объектом YAML.")
            sid = item.get("id")
            name = item.get("display_name")
            base = item.get("base_url")
            if not sid or not name or not base:
                raise ConfigurationError("Поля id, display_name и base_url обязательны для каждого сервера.")
            auth_type, username, password, token = _parse_auth(item)
            if auth_type is AuthType.BASIC and (not username or password is None):
                raise ConfigurationError(f"Для сервера {sid} при auth.type=basic нужны username и password.")
            if auth_type is AuthType.TOKEN and not token:
                raise ConfigurationError(f"Для сервера {sid} при auth.type=token нужен bearer_token.")
            verify_ssl = bool(item.get("verify_ssl", True))
            restart_cmd = item.get("restart_shell_command")
            if restart_cmd is not None and not isinstance(restart_cmd, str):
                raise ConfigurationError("restart_shell_command должен быть строкой или отсутствовать.")
            result.append(
                ServerConfig(
                    id=str(sid),
                    display_name=str(name),
                    base_url=str(base).rstrip("/"),
                    verify_ssl=verify_ssl,
                    auth_type=auth_type,
                    username=str(username) if username else None,
                    password=str(password) if password is not None else None,
                    bearer_token=str(token) if token else None,
                    restart_shell_command=restart_cmd,
                )
            )
        return result

    def get_by_id(self, server_id: str) -> Optional[ServerConfig]:
        for s in self.load_all():
            if s.id == server_id:
                return s
        return None


def default_config_path() -> Path:
    root = Path(os.environ.get("NIFI_MANAGER_HOME", Path.cwd()))
    env_path = os.environ.get("NIFI_MANAGER_SERVERS_CONFIG")
    if env_path:
        return Path(env_path)
    return root / "data" / "servers.yaml"
