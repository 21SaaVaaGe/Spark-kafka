from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Any, Iterable, Optional


@dataclass(frozen=True)
class ParsedAggregate:
    queued_flow_files: int
    queued_bytes: int
    invalid_processors: int
    stopped_processors: int
    running_processors: int
    disabled_processors: int
    versioned_flow_state: Optional[str]


def _as_int(value: Any) -> int:
    if value is None:
        return 0
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    if isinstance(value, str):
        try:
            return int(float(value))
        except ValueError:
            return 0
    return 0


def _first_int(snap: dict[str, Any], keys: Iterable[str]) -> int:
    for k in keys:
        if k in snap and snap[k] is not None:
            return _as_int(snap.get(k))
    return 0


def count_processors_from_status_snapshots(snap: Any) -> tuple[int, int, int, int, bool]:
    """Считает RUNNING/STOPPED/INVALID/DISABLED по списку ``processorStatusSnapshots`` в снимке PG (NiFi 1.25+).

    Возвращает ``(running, stopped, invalid, disabled, found_list)``. ``runStatus`` в API: Running, Stopped, …
    """
    if not isinstance(snap, dict):
        return 0, 0, 0, 0, False
    raw = snap.get("processorStatusSnapshots")
    if not isinstance(raw, list) or not raw:
        return 0, 0, 0, 0, False
    run = stop = inv = dis = 0
    for item in raw:
        proc = item
        if isinstance(item, dict) and "processorStatusSnapshot" in item:
            proc = item.get("processorStatusSnapshot") or {}
        if not isinstance(proc, dict):
            continue
        rs = str(proc.get("runStatus") or proc.get("run_status") or "").strip().lower()
        if rs == "running":
            run += 1
        elif rs in ("stopped", "validating"):
            stop += 1
        elif rs == "disabled":
            dis += 1
        elif rs == "invalid":
            inv += 1
        elif rs:
            stop += 1
    return run, stop, inv, dis, True


def normalize_nested_pg_status_node(child: dict[str, Any]) -> dict[str, Any]:
    """Приводит элемент ``processGroupStatusSnapshots`` к виду ``{id, name, aggregateSnapshot}``."""
    if "aggregateSnapshot" in child and isinstance(child.get("aggregateSnapshot"), dict):
        return child
    inner = child.get("processGroupStatusSnapshot")
    if isinstance(inner, dict):
        cid = str(child.get("id") or inner.get("id") or "")
        cname = str(inner.get("name") or cid)
        return {"id": cid, "name": cname, "aggregateSnapshot": inner}
    return child


def parse_aggregate_snapshot(snap: Any) -> ParsedAggregate:
    if not isinstance(snap, dict):
        return ParsedAggregate(0, 0, 0, 0, 0, 0, None)
    queued_ff = _first_int(
        snap,
        (
            "flowFilesQueued",
            "queuedCount",
            "flowfilesQueued",
        ),
    )
    queued_bytes = _first_int(snap, ("bytesQueued", "queuedBytes", "queuedSize"))
    invalid_p = _first_int(snap, ("invalidCount", "invalidProcessors", "invalid"))
    stopped_p = _first_int(snap, ("stoppedCount", "stoppedProcessors"))
    running_p = _first_int(snap, ("runningCount", "runningProcessors", "activeThreadCount"))
    disabled_p = _first_int(snap, ("disabledCount", "disabledProcessors"))
    vfs = snap.get("versionedFlowState")
    versioned = str(vfs) if vfs is not None else None
    agg = ParsedAggregate(
        queued_flow_files=queued_ff,
        queued_bytes=queued_bytes,
        invalid_processors=invalid_p,
        stopped_processors=stopped_p,
        running_processors=running_p,
        disabled_processors=disabled_p,
        versioned_flow_state=versioned,
    )
    cr, cs, ci, cd, from_proc_list = count_processors_from_status_snapshots(snap)
    if from_proc_list:
        return ParsedAggregate(
            queued_flow_files=agg.queued_flow_files,
            queued_bytes=agg.queued_bytes,
            invalid_processors=ci,
            stopped_processors=cs,
            running_processors=cr,
            disabled_processors=cd,
            versioned_flow_state=agg.versioned_flow_state,
        )
    return agg


def extract_root_process_group_status(flow_status_entity: dict[str, Any]) -> dict[str, Any]:
    pgs = flow_status_entity.get("processGroupStatus")
    if isinstance(pgs, dict):
        return pgs
    return {}


def parse_recursive_aggregate(flow_status_entity: dict[str, Any]) -> ParsedAggregate:
    """Использует корневой aggregateSnapshot при recursive=true (NiFi агрегирует по дереву)."""
    root = extract_root_process_group_status(flow_status_entity)
    snap = root.get("aggregateSnapshot")
    return parse_aggregate_snapshot(snap)


def _iter_child_pg_status_nodes(node: dict[str, Any]) -> Iterable[dict[str, Any]]:
    """Дочерние PG: в NiFi 1.25+ они в ``aggregateSnapshot.processGroupStatusSnapshots`` (не в ``childProcessGroupStatuses``)."""
    seen: set[str] = set()
    snap = node.get("aggregateSnapshot")
    if isinstance(snap, dict):
        nested = snap.get("processGroupStatusSnapshots")
        if isinstance(nested, list):
            for ch in nested:
                if isinstance(ch, dict):
                    norm = normalize_nested_pg_status_node(ch)
                    cid = str(norm.get("id") or "")
                    if cid and cid not in seen:
                        seen.add(cid)
                        yield norm
    legacy = node.get("childProcessGroupStatuses")
    if isinstance(legacy, list):
        for ch in legacy:
            if isinstance(ch, dict):
                cid = str(ch.get("id") or "")
                if cid and cid not in seen:
                    seen.add(cid)
                    yield ch


def walk_process_group_status_tree(root_status: dict[str, Any]) -> list[dict[str, Any]]:
    """Обход дерева статусов PG (GET .../status?recursive=true), порядок: в ширину (корень, затем уровни)."""
    out: list[dict[str, Any]] = []
    q: deque[dict[str, Any]] = deque([root_status])
    while q:
        cur = q.popleft()
        out.append(cur)
        for ch in _iter_child_pg_status_nodes(cur):
            q.append(ch)
    return out


def _dig_str(obj: Any, *path: str) -> Optional[str]:
    cur: Any = obj
    for key in path:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(key)
    if cur is None:
        return None
    s = str(cur).strip()
    return s or None


def extract_flow_root_id(flow_entity: dict[str, Any]) -> Optional[str]:
    """Извлекает UUID корневой PG из ответа ``/flow/process-groups/root`` или ``/flow``.

    В разных версиях NiFi идентификатор может лежать на разных уровнях вложенности.
    """
    if not isinstance(flow_entity, dict):
        return None
    candidates = (
        _dig_str(flow_entity, "processGroupFlow", "id"),
        _dig_str(flow_entity, "processGroupFlow", "component", "id"),
        _dig_str(flow_entity, "processGroupFlow", "flow", "id"),
        _dig_str(flow_entity, "processGroupFlow", "breadcrumb", "id"),
        _dig_str(flow_entity, "flow", "processGroupFlow", "id"),
        _dig_str(flow_entity, "id"),
    )
    for cid in candidates:
        if cid:
            return cid
    return None


def resolve_root_process_group_id(flow_entity: dict[str, Any]) -> str:
    """UUID корневой PG или литерал ``root`` (NiFi принимает его в ``/flow/process-groups/{id}/...``)."""
    return extract_flow_root_id(flow_entity) or "root"


def extract_controller_state(about_entity: dict[str, Any]) -> Optional[str]:
    about = about_entity.get("about")
    if not isinstance(about, dict):
        return None
    return about.get("controllerStatus") or about.get("controller_state")


def extract_nifi_version(about_entity: dict[str, Any]) -> Optional[str]:
    about = about_entity.get("about")
    if not isinstance(about, dict):
        return None
    return about.get("version")


def extract_public_uri(about_entity: dict[str, Any]) -> Optional[str]:
    about = about_entity.get("about")
    if not isinstance(about, dict):
        return None
    return about.get("uri")


def processors_up_to_date_flag(agg: ParsedAggregate) -> bool:
    if agg.invalid_processors > 0:
        return False
    state = (agg.versioned_flow_state or "").upper()
    if not state:
        return True
    ok_states = {"UP_TO_DATE", "NOT_UNDER_VERSION_CONTROL", "UNKNOWN"}
    bad_states = {"LOCALLY_MODIFIED", "STALE", "SYNC_FAILURE", "LOCALLY_MODIFIED_AND_STALE"}
    if state in bad_states:
        return False
    if state in ok_states:
        return True
    return True


def heap_from_system_diagnostics(diag: dict[str, Any]) -> tuple[Optional[int], Optional[int], Optional[float]]:
    """Возвращает (used, max, percent) для JVM heap из /system-diagnostics."""
    aggr = diag.get("systemDiagnostics")
    if not isinstance(aggr, dict):
        aggr = diag
    snap = aggr.get("aggregateSnapshot")
    if not isinstance(snap, dict):
        return None, None, None
    heap_used = snap.get("usedHeap") or snap.get("totalHeap") or snap.get("heapUsed")
    heap_max = snap.get("maxHeap") or snap.get("heapMax")
    heap_usage = snap.get("heapUtilization")
    u = _as_int(heap_used) if heap_used is not None else None
    m = _as_int(heap_max) if heap_max is not None else None
    pct: Optional[float] = None
    if heap_usage is not None:
        hs = str(heap_usage).replace("%", "").strip()
        try:
            pct = float(hs)
        except ValueError:
            pct = None
    elif u is not None and m and m > 0:
        pct = round(100.0 * u / m, 2)
    return u, m, pct


def active_threads_from_system_diagnostics(diag: dict[str, Any]) -> Optional[int]:
    aggr = diag.get("systemDiagnostics")
    if not isinstance(aggr, dict):
        aggr = diag
    snap = aggr.get("aggregateSnapshot")
    if not isinstance(snap, dict):
        return None
    return _as_int(snap.get("totalThreads"))
