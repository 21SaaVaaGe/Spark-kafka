from __future__ import annotations

from typing import Any, Optional, Protocol

from nifi_manager.domain.models import AccessRecord, ServerConfig


class ServerConfigRepository(Protocol):
    def load_all(self) -> list[ServerConfig]: ...

    def get_by_id(self, server_id: str) -> Optional[ServerConfig]: ...


class AccessLogRepository(Protocol):
    def get(self, server_id: str) -> Optional[AccessRecord]: ...

    def record_visit(self, server_id: str, client_ip: str) -> None: ...


class NiFiGateway(Protocol):
    """Абстракция доступа к экземпляру NiFi по REST API."""

    def fetch_about(self) -> dict[str, Any]: ...

    def fetch_flow_bootstrap(self) -> dict[str, Any]: ...

    def fetch_process_group_status(self, process_group_id: str, recursive: bool) -> dict[str, Any]: ...

    def fetch_process_group_flow(self, process_group_id: str) -> dict[str, Any]: ...

    def fetch_system_diagnostics(self) -> dict[str, Any]: ...

    def fetch_client_id(self) -> str: ...

    def fetch_process_group_entity(self, process_group_id: str) -> dict[str, Any]: ...

    def update_process_group_run_status(
        self,
        process_group_id: str,
        state: str,
        revision: dict[str, Any],
        client_id: str,
    ) -> dict[str, Any]: ...


class ShellRunner(Protocol):
    """Выполнение локальной команды (например, перезапуск службы NiFi на хосте приложения)."""

    def run(self, command: str, timeout_sec: int = 180) -> tuple[int, str, str]: ...
