from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

from nifi_manager.domain.exceptions import NiFiClientError, NiFiManagerError, ServerNotFoundError
from nifi_manager.domain.models import (
    MetricsSample,
    ProcessGroupListItem,
    ServerConfig,
    ServerDetail,
    ServerOverview,
)
from nifi_manager.application.ports import AccessLogRepository, NiFiGateway, ServerConfigRepository, ShellRunner
from nifi_manager.application.flow_status_parser import (
    active_threads_from_system_diagnostics,
    extract_controller_state,
    extract_public_uri,
    extract_nifi_version,
    extract_root_process_group_status,
    heap_from_system_diagnostics,
    parse_aggregate_snapshot,
    parse_recursive_aggregate,
    processors_up_to_date_flag,
    resolve_root_process_group_id,
    walk_process_group_status_tree,
)
from nifi_manager.infrastructure.nifi_http_gateway import HttpxNiFiGateway


class NiFiMonitoringService:
    """Сценарии использования: обзор серверов, детали, управление PG, перезапуск."""

    def __init__(
        self,
        config_repo: ServerConfigRepository,
        access_log: AccessLogRepository,
        shell: ShellRunner,
    ) -> None:
        self._configs = config_repo
        self._access = access_log
        self._shell = shell

    def _open_gateway(self, cfg: ServerConfig) -> HttpxNiFiGateway:
        return HttpxNiFiGateway(cfg)

    def _require_config(self, server_id: str) -> ServerConfig:
        cfg = self._configs.get_by_id(server_id)
        if cfg is None:
            raise ServerNotFoundError(server_id)
        return cfg

    def list_overviews(self) -> list[ServerOverview]:
        out: list[ServerOverview] = []
        for cfg in self._configs.load_all():
            out.append(self._build_overview(cfg))
        return out

    def _build_overview(self, cfg: ServerConfig) -> ServerOverview:
        with self._open_gateway(cfg) as gw:
            try:
                return self._build_overview_core(cfg, gw)
            except NiFiClientError as exc:
                return ServerOverview(
                    id=cfg.id,
                    display_name=cfg.display_name,
                    api_base_url=cfg.base_url,
                    reachable=False,
                    controller_state=None,
                    nifi_version=None,
                    uri_public=None,
                    root_process_group_id=None,
                    queued_flow_files=0,
                    queued_bytes=0,
                    has_disabled_processors=False,
                    invalid_processors=0,
                    stopped_processors=0,
                    running_processors=0,
                    processors_up_to_date=False,
                    error_message=str(exc),
                )
            except NiFiManagerError as exc:
                return ServerOverview(
                    id=cfg.id,
                    display_name=cfg.display_name,
                    api_base_url=cfg.base_url,
                    reachable=False,
                    controller_state=None,
                    nifi_version=None,
                    uri_public=None,
                    root_process_group_id=None,
                    queued_flow_files=0,
                    queued_bytes=0,
                    has_disabled_processors=False,
                    invalid_processors=0,
                    stopped_processors=0,
                    running_processors=0,
                    processors_up_to_date=False,
                    error_message=str(exc),
                )
            except Exception as exc:  # noqa: BLE001 — обзор не должен падать из-за неожиданных ошибок NiFi/парсинга
                return ServerOverview(
                    id=cfg.id,
                    display_name=cfg.display_name,
                    api_base_url=cfg.base_url,
                    reachable=False,
                    controller_state=None,
                    nifi_version=None,
                    uri_public=None,
                    root_process_group_id=None,
                    queued_flow_files=0,
                    queued_bytes=0,
                    has_disabled_processors=False,
                    invalid_processors=0,
                    stopped_processors=0,
                    running_processors=0,
                    processors_up_to_date=False,
                    error_message=str(exc),
                )

    def _build_overview_core(self, cfg: ServerConfig, gw: NiFiGateway) -> ServerOverview:
        about = gw.fetch_about()
        flow = gw.fetch_flow_bootstrap()
        root_id = resolve_root_process_group_id(flow)
        status_entity = gw.fetch_process_group_status(root_id, recursive=True)
        agg = parse_recursive_aggregate(status_entity)
        version = extract_nifi_version(about)
        ctrl = extract_controller_state(about)
        uri = extract_public_uri(about)
        return ServerOverview(
            id=cfg.id,
            display_name=cfg.display_name,
            api_base_url=cfg.base_url,
            reachable=True,
            controller_state=ctrl,
            nifi_version=version,
            uri_public=uri,
            root_process_group_id=root_id,
            queued_flow_files=agg.queued_flow_files,
            queued_bytes=agg.queued_bytes,
            has_disabled_processors=agg.disabled_processors > 0,
            invalid_processors=agg.invalid_processors,
            stopped_processors=agg.stopped_processors,
            running_processors=agg.running_processors,
            processors_up_to_date=processors_up_to_date_flag(agg),
            error_message=None,
        )

    def get_detail(self, server_id: str, client_ip: str) -> ServerDetail:
        cfg = self._require_config(server_id)
        self._access.record_visit(server_id, client_ip)
        rec = self._access.get(server_id)
        last_ip = rec.last_ip if rec else client_ip
        last_at = rec.last_at if rec else datetime.now(timezone.utc)
        with self._open_gateway(cfg) as gw:
            overview = self._build_overview_core(cfg, gw)
            groups: list[ProcessGroupListItem] = []
            if overview.root_process_group_id:
                status_entity = gw.fetch_process_group_status(overview.root_process_group_id, recursive=True)
                root = extract_root_process_group_status(status_entity)
                for node in walk_process_group_status_tree(root):
                    snap = node.get("aggregateSnapshot") if isinstance(node.get("aggregateSnapshot"), dict) else {}
                    nid = str(node.get("id") or "").strip()
                    if not nid:
                        nid = str(snap.get("id") or "").strip()
                    if not nid:
                        continue
                    name = str(node.get("name") or "").strip()
                    if not name:
                        name = str(snap.get("name") or nid)
                    local = parse_aggregate_snapshot(snap)
                    run_state = snap.get("state") or node.get("state")
                    groups.append(
                        ProcessGroupListItem(
                            id=nid,
                            name=name,
                            state=str(run_state) if run_state else None,
                            running_count=local.running_processors,
                            stopped_count=local.stopped_processors,
                            invalid_count=local.invalid_processors,
                            disabled_count=local.disabled_processors,
                            queued_flow_files=local.queued_flow_files,
                            bytes_queued=local.queued_bytes,
                        )
                    )
            groups.sort(key=lambda g: g.name.lower())
            detail = ServerDetail(
                overview=overview,
                process_groups=groups,
                last_client_ip=last_ip,
                last_client_at=last_at,
                restart_command_configured=bool(cfg.restart_shell_command),
            )
            return detail

    def sample_metrics(self, server_id: str) -> MetricsSample:
        cfg = self._require_config(server_id)
        with self._open_gateway(cfg) as gw:
            flow = gw.fetch_flow_bootstrap()
            root_id = resolve_root_process_group_id(flow)
            status_entity = gw.fetch_process_group_status(root_id, recursive=True)
            agg = parse_recursive_aggregate(status_entity)
            diag = gw.fetch_system_diagnostics()
            heap_u, heap_m, heap_pct = heap_from_system_diagnostics(diag)
            threads = active_threads_from_system_diagnostics(diag)
            return MetricsSample(
                ts=datetime.now(timezone.utc),
                queued_flow_files=agg.queued_flow_files,
                heap_used_bytes=heap_u,
                heap_max_bytes=heap_m,
                heap_usage_percent=heap_pct,
                active_threads=threads,
            )

    def set_process_group_run_state(self, server_id: str, process_group_id: str, state: str) -> dict[str, Any]:
        if state not in {"RUNNING", "STOPPED"}:
            raise NiFiClientError("Допустимые значения state: RUNNING или STOPPED.")
        cfg = self._require_config(server_id)
        with self._open_gateway(cfg) as gw:
            client_id = gw.fetch_client_id()
            entity = gw.fetch_process_group_entity(process_group_id)
            revision = entity.get("revision")
            if not isinstance(revision, dict):
                flow_entity = gw.fetch_process_group_flow(process_group_id)
                revision = flow_entity.get("revision")
            if not isinstance(revision, dict):
                raise NiFiClientError(
                    "В ответе NiFi отсутствует revision для процессорной группы "
                    "(ни в GET /process-groups/{id}, ни в GET /flow/process-groups/{id})."
                )
            rev = dict(revision)
            rev["clientId"] = client_id
            return gw.update_process_group_run_status(process_group_id, state, rev, client_id)

    def restart_nifi(self, server_id: str) -> tuple[int, str, str]:
        cfg = self._require_config(server_id)
        cmd = cfg.restart_shell_command
        if not cmd:
            raise NiFiClientError(
                "Команда перезапуска не задана. Укажите restart_shell_command для сервера в data/servers.yaml."
            )
        return self._shell.run(cmd, timeout_sec=300)
