from __future__ import annotations

from flask import Blueprint, render_template

pages_bp = Blueprint("pages", __name__)


@pages_bp.get("/")
def dashboard():
    return render_template("dashboard.html")


@pages_bp.get("/server/<server_id>")
def server_detail(server_id: str):
    return render_template("server_detail.html", server_id=server_id)
