from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
from typing import Any

from nifi_manager.domain.models import MetricsSample, ProcessGroupListItem, ServerDetail, ServerOverview


def _dt_iso(value: datetime | None) -> str | None:
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.isoformat()


def server_overview_to_dict(o: ServerOverview) -> dict[str, Any]:
    d = asdict(o)
    return d


def process_group_to_dict(p: ProcessGroupListItem) -> dict[str, Any]:
    return asdict(p)


def metrics_sample_to_dict(m: MetricsSample) -> dict[str, Any]:
    return {
        "ts": _dt_iso(m.ts),
        "queued_flow_files": m.queued_flow_files,
        "heap_used_bytes": m.heap_used_bytes,
        "heap_max_bytes": m.heap_max_bytes,
        "heap_usage_percent": m.heap_usage_percent,
        "active_threads": m.active_threads,
    }


def server_detail_to_dict(d: ServerDetail) -> dict[str, Any]:
    return {
        "overview": server_overview_to_dict(d.overview),
        "process_groups": [process_group_to_dict(p) for p in d.process_groups],
        "last_client_ip": d.last_client_ip,
        "last_client_at": _dt_iso(d.last_client_at),
        "restart_command_configured": d.restart_command_configured,
    }
