from __future__ import annotations

from pathlib import Path

from flask import Flask

from nifi_manager.application.nifi_monitoring_service import NiFiMonitoringService
from nifi_manager.infrastructure.json_access_log_repository import JsonAccessLogRepository
from nifi_manager.infrastructure.subprocess_shell_runner import SubprocessShellRunner
from nifi_manager.infrastructure.yaml_config_repository import YamlServerConfigRepository, default_config_path
from nifi_manager.web.routes_api import api_bp
from nifi_manager.web.routes_pages import pages_bp


def create_app() -> Flask:
    base = Path(__file__).resolve().parent
    app = Flask(
        __name__,
        static_folder=str(base / "static"),
        template_folder=str(base / "templates"),
    )
    cfg_path = default_config_path()
    data_dir = cfg_path.parent
    access_path = data_dir / "access_log.json"
    config_repo = YamlServerConfigRepository(cfg_path)
    access_repo = JsonAccessLogRepository(access_path)
    shell = SubprocessShellRunner()
    service = NiFiMonitoringService(config_repo, access_repo, shell)
    app.config["MONITORING_SERVICE"] = service
    app.register_blueprint(pages_bp)
    app.register_blueprint(api_bp, url_prefix="/api")
    return app
