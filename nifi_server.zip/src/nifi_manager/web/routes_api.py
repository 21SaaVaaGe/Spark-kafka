from __future__ import annotations

from flask import Blueprint, current_app, jsonify, request

from nifi_manager.domain.exceptions import NiFiClientError, ServerNotFoundError
from nifi_manager.application.nifi_monitoring_service import NiFiMonitoringService
from nifi_manager.web.serialization import (
    metrics_sample_to_dict,
    server_detail_to_dict,
    server_overview_to_dict,
)

api_bp = Blueprint("api", __name__)


def _service() -> NiFiMonitoringService:
    return current_app.config["MONITORING_SERVICE"]


def _client_ip() -> str:
    xff = request.headers.get("X-Forwarded-For")
    if xff:
        return xff.split(",")[0].strip()
    return request.remote_addr or "unknown"


@api_bp.get("/servers")
def list_servers():
    data = [server_overview_to_dict(o) for o in _service().list_overviews()]
    return jsonify({"servers": data})


@api_bp.get("/servers/<server_id>")
def get_server(server_id: str):
    try:
        detail = _service().get_detail(server_id, _client_ip())
        return jsonify(server_detail_to_dict(detail))
    except ServerNotFoundError as exc:
        return jsonify({"error": str(exc)}), 404
    except NiFiClientError as exc:
        return jsonify({"error": str(exc)}), 502


@api_bp.get("/servers/<server_id>/metrics")
def get_metrics(server_id: str):
    try:
        sample = _service().sample_metrics(server_id)
        return jsonify(metrics_sample_to_dict(sample))
    except ServerNotFoundError as exc:
        return jsonify({"error": str(exc)}), 404
    except NiFiClientError as exc:
        return jsonify({"error": str(exc)}), 502


@api_bp.put("/servers/<server_id>/process-groups/<pg_id>/run-status")
def set_pg_status(server_id: str, pg_id: str):
    body = request.get_json(silent=True) or {}
    state = body.get("state")
    if state not in ("RUNNING", "STOPPED"):
        return jsonify({"error": "Поле state должно быть RUNNING или STOPPED."}), 400
    try:
        result = _service().set_process_group_run_state(server_id, pg_id, state)
        return jsonify({"ok": True, "result": result})
    except ServerNotFoundError as exc:
        return jsonify({"error": str(exc)}), 404
    except NiFiClientError as exc:
        return jsonify({"error": str(exc)}), 502


@api_bp.post("/servers/<server_id>/restart")
def restart_server(server_id: str):
    try:
        code, out, err = _service().restart_nifi(server_id)
        return jsonify({"exit_code": code, "stdout": out, "stderr": err})
    except ServerNotFoundError as exc:
        return jsonify({"error": str(exc)}), 404
    except NiFiClientError as exc:
        return jsonify({"error": str(exc)}), 400
