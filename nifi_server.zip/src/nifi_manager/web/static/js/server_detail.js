/* global TimeSeriesChart, fetch, window */

function el(id) {
  return document.getElementById(id);
}

function showAlert(message, kind) {
  const box = el("alert");
  if (!box) return;
  box.classList.remove("hidden", "info");
  if (kind === "info") box.classList.add("info");
  box.textContent = message || "";
}

function hideAlert() {
  const box = el("alert");
  if (!box) return;
  box.classList.add("hidden");
  box.textContent = "";
}

function setKV(container, rows) {
  if (!container) return;
  container.innerHTML = "";
  for (const [k, v] of rows) {
    const dt = document.createElement("dt");
    dt.textContent = k;
    const dd = document.createElement("dd");
    dd.textContent = v == null ? "—" : String(v);
    container.appendChild(dt);
    container.appendChild(dd);
  }
}

function fmtBytes(n) {
  if (n == null) return "—";
  const x = Number(n);
  if (!Number.isFinite(x)) return "—";
  if (x < 1024) return `${x} B`;
  if (x < 1024 * 1024) return `${(x / 1024).toFixed(1)} KiB`;
  if (x < 1024 * 1024 * 1024) return `${(x / (1024 * 1024)).toFixed(1)} MiB`;
  return `${(x / (1024 * 1024 * 1024)).toFixed(2)} GiB`;
}

async function apiGet(path) {
  const res = await fetch(path, { headers: { Accept: "application/json" } });
  const data = await res.json().catch(() => ({}));
  return { res, data };
}

async function apiPutJson(path, body) {
  const res = await fetch(path, {
    method: "PUT",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  return { res, data };
}

async function apiPost(path) {
  const res = await fetch(path, { method: "POST", headers: { Accept: "application/json" } });
  const data = await res.json().catch(() => ({}));
  return { res, data };
}

function renderProcessGroups(groups) {
  const tbody = document.querySelector("#tbl-pg tbody");
  if (!tbody) return;
  tbody.innerHTML = "";
  for (const g of groups) {
    const tr = document.createElement("tr");
    const tdName = document.createElement("td");
    tdName.textContent = g.name || g.id;

    const tdState = document.createElement("td");
    tdState.textContent = g.state || "—";

    const tdQ = document.createElement("td");
    tdQ.textContent = String(g.queued_flow_files ?? 0);

    const tdCounts = document.createElement("td");
    tdCounts.textContent = `${g.running_count ?? "—"} / ${g.stopped_count ?? "—"} / ${g.invalid_count ?? "—"} / ${
      g.disabled_count ?? "—"
    }`;

    const tdAct = document.createElement("td");
    const bRun = document.createElement("button");
    bRun.type = "button";
    bRun.className = "btn primary";
    bRun.textContent = "Запустить";
    bRun.addEventListener("click", () => void setPgState(g.id, "RUNNING"));

    const bStop = document.createElement("button");
    bStop.type = "button";
    bStop.className = "btn";
    bStop.textContent = "Остановить";
    bStop.addEventListener("click", () => void setPgState(g.id, "STOPPED"));

    tdAct.appendChild(bRun);
    tdAct.appendChild(document.createTextNode(" "));
    tdAct.appendChild(bStop);

    tr.appendChild(tdName);
    tr.appendChild(tdState);
    tr.appendChild(tdQ);
    tr.appendChild(tdCounts);
    tr.appendChild(tdAct);
    tbody.appendChild(tr);
  }
}

async function setPgState(pgId, state) {
  hideAlert();
  const serverId = window.__SERVER_ID__;
  const { res, data } = await apiPutJson(`/api/servers/${encodeURIComponent(serverId)}/process-groups/${encodeURIComponent(pgId)}/run-status`, {
    state,
  });
  if (!res.ok) {
    showAlert(data.error || `Ошибка HTTP ${res.status}`);
    return;
  }
  showAlert(`Команда отправлена (${state}). Обновляю данные…`, "info");
  await refreshDetail();
  hideAlert();
}

async function refreshDetail() {
  hideAlert();
  const serverId = window.__SERVER_ID__;
  const { res, data } = await apiGet(`/api/servers/${encodeURIComponent(serverId)}`);
  if (!res.ok) {
    showAlert(data.error || `Ошибка HTTP ${res.status}`);
    return;
  }

  const ov = data.overview || {};
  el("srv-title").textContent = ov.display_name || serverId;
  el("srv-sub").textContent = ov.reachable ? `Версия NiFi: ${ov.nifi_version || "—"}` : "NiFi недоступен по REST API.";

  setKV(el("kv-overview"), [
    ["Идентификатор", ov.id],
    ["Публичный URI (из NiFi)", ov.uri_public || "—"],
    ["Состояние контроллера", ov.controller_state || "—"],
    ["Корневая PG", ov.root_process_group_id || "—"],
    ["Файлов в очередях (агрегат)", String(ov.queued_flow_files ?? 0)],
    ["Байт в очередях", fmtBytes(ov.queued_bytes)],
    ["INVALID процессоров", String(ov.invalid_processors ?? 0)],
    ["RUNNING процессоров", String(ov.running_processors ?? 0)],
    ["STOPPED процессоров", String(ov.stopped_processors ?? 0)],
    ["Есть DISABLED", ov.has_disabled_processors ? "да" : "нет"],
    ["Поток «актуален» (версионирование/валидность)", ov.processors_up_to_date ? "да" : "нет"],
  ]);

  setKV(el("kv-access"), [
    ["Последний IP", data.last_client_ip || "—"],
    ["Время", data.last_client_at || "—"],
    ["Команда перезапуска настроена", data.restart_command_configured ? "да" : "нет"],
  ]);

  renderProcessGroups(Array.isArray(data.process_groups) ? data.process_groups : []);

  const btnRestart = el("btn-restart");
  if (btnRestart) btnRestart.disabled = !data.restart_command_configured;
}

async function pollMetrics(queueChart, heapChart) {
  const serverId = window.__SERVER_ID__;
  const { res, data } = await apiGet(`/api/servers/${encodeURIComponent(serverId)}/metrics`);
  if (!res.ok) return;
  const q = Number(data.queued_flow_files ?? 0);
  queueChart.push(q);
  const hp = data.heap_usage_percent;
  if (hp != null && Number.isFinite(Number(hp))) {
    heapChart.push(Number(hp));
  }
}

async function restartNiFi() {
  const serverId = window.__SERVER_ID__;
  const ok = window.confirm(
    "Вы уверены, что хотите выполнить настроенную команду перезапуска на машине приложения? " +
      "Это не встроенная функция NiFi, а локальный shell из конфигурации сервера."
  );
  if (!ok) return;
  hideAlert();
  const { res, data } = await apiPost(`/api/servers/${encodeURIComponent(serverId)}/restart`);
  if (!res.ok) {
    showAlert(data.error || `Ошибка HTTP ${res.status}`);
    return;
  }
  const msg = `Код выхода: ${data.exit_code}\nstdout:\n${data.stdout || ""}\nstderr:\n${data.stderr || ""}`;
  showAlert(msg, "info");
}

function wire() {
  const btnRefresh = el("btn-refresh");
  if (btnRefresh) btnRefresh.addEventListener("click", () => void refreshDetail());

  const btnRestart = el("btn-restart");
  if (btnRestart) btnRestart.addEventListener("click", () => void restartNiFi());

  const cQ = /** @type {HTMLCanvasElement} */ (el("chart-queues"));
  const cH = /** @type {HTMLCanvasElement} */ (el("chart-heap"));
  const queueChart = new TimeSeriesChart(cQ, {
    stroke: "rgba(91,140,255,1)",
    fill: "rgba(91,140,255,0.18)",
    label: "FlowFiles в очередях (агрегат)",
    formatValue: (n) => (Number.isFinite(n) ? String(Math.round(n)) : "—"),
  });
  const heapChart = new TimeSeriesChart(cH, {
    stroke: "rgba(61,214,140,1)",
    fill: "rgba(61,214,140,0.14)",
    label: "Загрузка heap JVM, %",
    formatValue: (n) => (Number.isFinite(n) ? `${n.toFixed(1)} %` : "—"),
  });

  void refreshDetail();
  void pollMetrics(queueChart, heapChart);
  window.setInterval(() => void pollMetrics(queueChart, heapChart), 5000);
}

wire();
