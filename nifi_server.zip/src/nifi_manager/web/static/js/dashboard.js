/* global fetch */

function el(id) {
  return document.getElementById(id);
}

function showAlert(message, kind) {
  const box = el("alert");
  if (!box) return;
  box.classList.remove("hidden", "info");
  if (kind === "info") box.classList.add("info");
  box.textContent = message || "";
}

function hideAlert() {
  const box = el("alert");
  if (!box) return;
  box.classList.add("hidden");
  box.textContent = "";
}

function pill(text, tone) {
  const span = document.createElement("span");
  span.className = `pill ${tone}`;
  span.textContent = text;
  return span;
}

function fmtBool(v) {
  return v ? "да" : "нет";
}

async function loadServers() {
  hideAlert();
  const res = await fetch("/api/servers", { headers: { Accept: "application/json" } });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    showAlert(data.error || `Ошибка HTTP ${res.status}`);
    return [];
  }
  return Array.isArray(data.servers) ? data.servers : [];
}

function renderTable(servers) {
  const tbody = document.querySelector("#tbl-servers tbody");
  if (!tbody) return;
  tbody.innerHTML = "";
  for (const s of servers) {
    const tr = document.createElement("tr");
    const reachable = !!s.reachable;
    const stateText = reachable ? (s.controller_state || "доступен") : "недоступен";
    const tone = reachable ? "ok" : "bad";

    const tdName = document.createElement("td");
    const a = document.createElement("a");
    a.href = `/server/${encodeURIComponent(s.id)}`;
    a.textContent = s.display_name;
    tdName.appendChild(a);

    const tdAddr = document.createElement("td");
    tdAddr.textContent = s.api_base_url || "";

    const tdState = document.createElement("td");
    tdState.appendChild(pill(stateText, tone));
    if (!reachable && s.error_message) {
      const br = document.createElement("div");
      br.className = "muted small";
      br.textContent = s.error_message;
      tdState.appendChild(br);
    }

    const tdVer = document.createElement("td");
    tdVer.textContent = s.nifi_version || "—";

    const tdQ = document.createElement("td");
    tdQ.textContent = reachable ? String(s.queued_flow_files ?? 0) : "—";

    const tdDis = document.createElement("td");
    tdDis.appendChild(pill(fmtBool(!!s.has_disabled_processors), s.has_disabled_processors ? "warn" : "ok"));

    const tdUpd = document.createElement("td");
    const ok = !!s.processors_up_to_date;
    tdUpd.appendChild(pill(fmtBool(ok), ok ? "ok" : "warn"));

    const tdGo = document.createElement("td");
    const go = document.createElement("a");
    go.href = `/server/${encodeURIComponent(s.id)}`;
    go.textContent = "Открыть";
    tdGo.appendChild(go);

    tr.appendChild(tdName);
    tr.appendChild(tdAddr);
    tr.appendChild(tdState);
    tr.appendChild(tdVer);
    tr.appendChild(tdQ);
    tr.appendChild(tdDis);
    tr.appendChild(tdUpd);
    tr.appendChild(tdGo);
    tbody.appendChild(tr);
  }
}

async function refresh() {
  const servers = await loadServers();
  renderTable(servers);
}

function wire() {
  const btn = el("btn-refresh");
  if (btn) btn.addEventListener("click", () => void refresh());
}

wire();
void refresh();
