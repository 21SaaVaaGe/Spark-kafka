/**
 * Временной ряд на canvas без внешних библиотек (офлайн).
 * Рисует сетку, подписи оси Y (числа), время на оси X, сводку мин/макс/текущее.
 */
class TimeSeriesChart {
  /**
   * @param {HTMLCanvasElement} canvas
   * @param {{
   *   stroke: string,
   *   fill: string,
   *   label: string,
   *   formatValue?: (n: number) => string,
   * }} style
   */
  constructor(canvas, style) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.stroke = style.stroke;
    this.fill = style.fill;
    this.label = style.label;
    /** @type {(n: number) => string} */
    this.formatValue =
      style.formatValue ||
      ((n) => {
        if (!Number.isFinite(n)) return "—";
        if (Math.abs(n - Math.round(n)) < 1e-6) return String(Math.round(n));
        return n.toFixed(2);
      });
    /** @type {{x: number, y: number}[]} */
    this.points = [];
    this.maxPoints = 90;
    this._margin = { top: 28, right: 12, bottom: 28, left: 52 };
  }

  push(value) {
    const t = Date.now();
    this.points.push({ x: t, y: Number(value) });
    if (this.points.length > this.maxPoints) {
      this.points.splice(0, this.points.length - this.maxPoints);
    }
    this.draw();
  }

  draw() {
    const c = this.canvas;
    const g = this.ctx;
    if (!g) return;
    const w = c.width;
    const h = c.height;
    const { top, right, bottom, left } = this._margin;
    g.clearRect(0, 0, w, h);

    g.fillStyle = "rgba(255,255,255,0.04)";
    g.fillRect(0, 0, w, h);

    const fmt = this.formatValue;

    if (this.points.length < 2) {
      g.fillStyle = "rgba(232,236,255,0.65)";
      g.font = "14px system-ui, sans-serif";
      g.fillText("Собираем данные…", left, top - 6);
      return;
    }

    const xs = this.points.map((p) => p.x);
    const ys = this.points.map((p) => p.y);
    const minData = Math.min(...ys);
    const maxData = Math.max(...ys);
    let minY = minData;
    let maxY = maxData;
    if (!Number.isFinite(minY) || !Number.isFinite(maxY)) {
      minY = 0;
      maxY = 1;
    }
    if (Math.abs(maxY - minY) < 1e-9) {
      minY -= 1;
      maxY += 1;
    }

    const minX = Math.min(...xs);
    const maxX = Math.max(...xs);
    const x0 = left;
    const y0 = top;
    const x1 = w - right;
    const y1 = h - bottom;

    const dx = Math.max(1, maxX - minX);
    const dy = Math.max(1e-9, maxY - minY);

    const mapX = (x) => x0 + ((x - minX) / dx) * (x1 - x0);
    const mapY = (y) => y1 - ((y - minY) / dy) * (y1 - y0);

    const timeOpts = { hour: "2-digit", minute: "2-digit", second: "2-digit" };

    // сетка + подписи оси Y
    g.strokeStyle = "rgba(154,167,214,0.18)";
    g.lineWidth = 1;
    g.font = "11px ui-monospace, Menlo, Consolas, monospace";
    g.fillStyle = "rgba(154,167,214,0.92)";
    g.textAlign = "right";
    g.textBaseline = "middle";
    const yTicks = 4;
    for (let i = 0; i <= yTicks; i++) {
      const yy = y0 + (i / yTicks) * (y1 - y0);
      const v = maxY - (i / yTicks) * (maxY - minY);
      g.beginPath();
      g.moveTo(x0, yy);
      g.lineTo(x1, yy);
      g.stroke();
      g.fillText(fmt(v), x0 - 6, yy);
    }

    // вертикальные линии сетки (5 делений)
    g.strokeStyle = "rgba(154,167,214,0.1)";
    const xTicks = 5;
    for (let j = 1; j < xTicks; j++) {
      const xx = x0 + (j / xTicks) * (x1 - x0);
      g.beginPath();
      g.moveTo(xx, y0);
      g.lineTo(xx, y1);
      g.stroke();
    }

    // заливка под линией
    g.beginPath();
    g.moveTo(mapX(this.points[0].x), mapY(this.points[0].y));
    for (let i = 1; i < this.points.length; i++) {
      g.lineTo(mapX(this.points[i].x), mapY(this.points[i].y));
    }
    g.lineTo(mapX(this.points[this.points.length - 1].x), y1);
    g.lineTo(mapX(this.points[0].x), y1);
    g.closePath();
    g.fillStyle = this.fill;
    g.fill();

    // линия ряда
    g.beginPath();
    g.moveTo(mapX(this.points[0].x), mapY(this.points[0].y));
    for (let i = 1; i < this.points.length; i++) {
      g.lineTo(mapX(this.points[i].x), mapY(this.points[i].y));
    }
    g.strokeStyle = this.stroke;
    g.lineWidth = 2;
    g.stroke();

    // заголовок и сводка чисел (мин / макс / сейчас)
    const last = this.points[this.points.length - 1].y;
    g.textAlign = "left";
    g.textBaseline = "top";
    g.fillStyle = "rgba(232,236,255,0.9)";
    g.font = "13px system-ui, sans-serif";
    g.fillText(this.label, 10, 6);
    g.font = "11px ui-monospace, Menlo, Consolas, monospace";
    g.fillStyle = "rgba(154,167,214,0.95)";
    g.textAlign = "right";
    const summary = `мин ${fmt(minData)} · макс ${fmt(maxData)} · сейчас ${fmt(last)}`;
    g.fillText(summary, w - 10, 8);

    // ось X: время начала и конца окна
    g.textAlign = "left";
    g.textBaseline = "top";
    g.fillStyle = "rgba(154,167,214,0.88)";
    g.font = "10px ui-monospace, Menlo, Consolas, monospace";
    const tStart = new Date(this.points[0].x).toLocaleTimeString("ru-RU", timeOpts);
    const tEnd = new Date(this.points[this.points.length - 1].x).toLocaleTimeString("ru-RU", timeOpts);
    g.fillText(tStart, x0, y1 + 6);
    g.textAlign = "right";
    g.fillText(tEnd, x1, y1 + 6);
  }
}
