from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from nifi_manager.web.app import create_app  # noqa: E402

app = create_app()

if __name__ == "__main__":
    host = os.environ.get("HOST", "192.168.0.15")
    port = int(os.environ.get("PORT", "8765"))
    app.run(host=host, port=port, debug=False)
