from pyspark.sql import SparkSession, functions as F

spark = SparkSession.builder.appName("kafka-console").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

df = (spark.readStream.format("kafka")
    .option("kafka.bootstrap.servers", "k1:9092")
    .option("subscribe", "input-topic")
    .load())

txt = df.selectExpr("CAST(value AS STRING) AS value")
q = (txt.writeStream.format("console")
    .option("truncate", "false")
    .option("checkpointLocation", "/tmp/ckp/kafka-console")
    .start())

q.awaitTermination()
