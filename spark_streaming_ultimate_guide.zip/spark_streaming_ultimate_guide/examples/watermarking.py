from pyspark.sql import SparkSession, functions as F

spark = SparkSession.builder.appName("watermark-demo").getOrCreate()

events = (spark.readStream.format("json")
    .schema("user_id string, event_time timestamp, amount double")
    .load("/data/events"))

agg = (events
    .withWatermark("event_time", "10 minutes")
    .groupBy(F.window("event_time", "5 minutes"), F.col("user_id"))
    .agg(F.sum("amount").alias("sum_amount")))

q = (agg.writeStream
    .format("console")
    .outputMode("update")
    .option("truncate", "false")
    .option("checkpointLocation", "/tmp/ckp/watermark")
    .start())

q.awaitTermination()
