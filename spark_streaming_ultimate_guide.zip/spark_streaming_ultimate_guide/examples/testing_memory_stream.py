from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
from pyspark.sql.functions import *
from pyspark.sql.streaming import MemoryStream

spark = SparkSession.builder.appName("testable").getOrCreate()

schema = StructType([StructField("id", StringType()), StructField("x", IntegerType())])
mem = MemoryStream(spark, schema=schema)
df = mem.toDF()
out = df.groupBy("id").sum("x")

q = (out.writeStream
    .format("memory")
    .queryName("agg")
    .outputMode("complete")
    .start())

mem.addData([("a",1),("a",2),("b",5)])
q.processAllAvailable()

spark.sql("select * from agg").show()
q.stop()
