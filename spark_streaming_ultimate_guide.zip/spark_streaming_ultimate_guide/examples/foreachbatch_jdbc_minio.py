import os, time, tempfile
from pyspark.sql import SparkSession, functions as F

spark = SparkSession.builder.appName("foreachbatch-jdbc-minio").getOrCreate()

df = (spark.readStream.format("rate").option("rowsPerSecond", 10).load())

def sink(batch_df, batch_id):
    data = batch_df.select(F.col("value").alias("v"), F.current_timestamp().alias("ts"))
    try:
        (data.write
          .format("jdbc")
          .option("url", os.getenv("JDBC_URL","jdbc:sqlserver://mssql:1433;databaseName=db"))
          .option("user", os.getenv("JDBC_USER","sa"))
          .option("password", os.getenv("JDBC_PASSWORD","Passw0rd!"))
          .option("dbtable", "dbo.stream_values")
          .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
          .mode("append").save())
    except Exception as e:
        # fallback: local json (в реале — MinIO/S3)
        tmp = tempfile.mkdtemp()
        data.coalesce(1).write.mode("overwrite").json(tmp)
        print("DB failed, wrote JSON to", tmp, "reason:", e)

q = (df.writeStream
    .foreachBatch(sink)
    .option("checkpointLocation", "/tmp/ckp/foreach-jdbc")
    .start())

q.awaitTermination()
