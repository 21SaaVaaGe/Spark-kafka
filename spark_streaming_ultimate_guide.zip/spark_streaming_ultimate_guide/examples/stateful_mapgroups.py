from pyspark.sql import SparkSession, functions as F, types as T
from pyspark.sql.streaming import GroupState, GroupStateTimeout

spark = SparkSession.builder.appName("stateful").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

schema = "user_id string, event_time timestamp, delta int"
src = (spark.readStream.format("json").schema(schema).load("/data/stateful"))

def update_state(key, rows, state: GroupState):
    total = state.get("total") if state.exists else 0
    last_ts = state.get("last_ts") if state.exists else None
    out = []
    for r in rows:
        total += int(r["delta"])
        last_ts = r["event_time"]
    state.update({"total": total, "last_ts": last_ts})
    state.setTimeoutDuration("10 minutes")
    out.append((key, total, last_ts))
    return out

out_schema = T.StructType([
    T.StructField("user_id", T.StringType()),
    T.StructField("total", T.IntegerType()),
    T.StructField("last_ts", T.TimestampType()),
])

keyed = src.groupByKey(lambda r: r["user_id"])
res = keyed.flatMapGroupsWithState(
    outputMode="update",
    stateFunc=update_state,
    timeoutConf="ProcessingTimeTimeout"
)

q = (res.writeStream
    .format("console")
    .outputMode("update")
    .option("checkpointLocation", "/tmp/ckp/stateful")
    .start())

q.awaitTermination()
