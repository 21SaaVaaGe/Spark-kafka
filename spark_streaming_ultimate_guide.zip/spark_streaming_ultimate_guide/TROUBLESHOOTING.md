# Troubleshooting / Частые ошибки
- Поток падает: изолируйте внешние вызовы в foreachBatch (try/except), отправляйте проблемные записи в отдельный sink.
- Нет записей: проверьте outputMode и watermark/окна.
- Lag: увеличьте ресурсы/параллелизм, снимите тяжёлые операции, настройте триггер.
- Small files: coalesce/repartition, compaction, AvailableNow.
- OOM/GC: меньше shuffle, broadcast joins, контроль state store.
