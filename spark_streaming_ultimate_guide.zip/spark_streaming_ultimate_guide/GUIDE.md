# Полный гид по Apache Spark Structured Streaming (2025)

Этот гид — максимально практичный: основы, архитектура, примеры кода, оптимизация, мониторинг, тестирование, частые ошибки и чек-листы.

## Содержание
- Введение и архитектура
- Базовые примеры
- Источники/синки (Kafka, файлы, JDBC/Delta)
- Выводные режимы (append/update/complete)
- Работа со временем: event-time, watermark, окна
- Stateful-операции и таймауты
- Джоины (stream-static, stream-stream)
- Триггеры и контроль батчей
- foreachBatch и интеграции
- Надёжность и семантики доставки
- Производительность и тюнинг
- Тестирование
- Мониторинг
- Деплой (Standalone/YARN/K8s)
- Частые ошибки и решения
- Шпаргалки и чек-листы

---

## Введение и архитектура
Structured Streaming — высокоуровневое API поверх DataFrame/SQL для потоков, где поток представляется как «бесконечная таблица». Spark исполняет вычисления пакетами — микробатчами.

- **Source**: Kafka, файловые системы, сокеты, каталоги таблиц.
- **Execution**: Catalyst-оптимизации, state store, watermark.
- **Sink**: Kafka, файловая система, Delta/Iceberg, foreach/foreachBatch.

Checkpoint хранит: оффсеты источников, прогресс, состояние, коммиты.

---

## Базовый пример
```python
from pyspark.sql import SparkSession, functions as F

spark = SparkSession.builder.appName("basic").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

df = (spark.readStream.format("rate")  # встроенный генератор
      .option("rowsPerSecond", 5).load())

q = (df.writeStream.format("console")
     .outputMode("append")
     .option("truncate", "false")
     .start())

q.awaitTermination()
```

---

## Источники/синки: Kafka
```python
src = (spark.readStream.format("kafka")
       .option("kafka.bootstrap.servers", "k1:9092,k2:9092")
       .option("subscribe", "input-topic")
       .option("startingOffsets", "latest")
       .load())

df = src.selectExpr("CAST(key AS STRING) AS k", "CAST(value AS STRING) AS v", "timestamp")

# Запись в Kafka
(df.writeStream.format("kafka")
   .option("kafka.bootstrap.servers", "k1:9092,k2:9092")
   .option("topic", "output-topic")
   .option("checkpointLocation", "/ckp/out")
   .start())
```

Файлы как поток:
```python
json_stream = (spark.readStream.format("json")
    .schema("id string, amount double, ts timestamp")
    .load("/data/incoming"))
```

---

## Режимы вывода
- **append** — только новые строки.
- **update** — обновления по ключам/окнам (после закрытия watermark).
- **complete** — перезапись всего результата (дорого).

---

## Время и Watermark
```python
from pyspark.sql import functions as F
events = df.withWatermark("event_time", "10 minutes")
agg = (events
       .groupBy(F.window("event_time","5 minutes"), "user_id")
       .count())
```

Watermark ограничивает «опоздание» событий; поздние будут отброшены (append/update).

---

## Stateful-операции
Произвольное состояние через `mapGroupsWithState` / `flatMapGroupsWithState` (см. пример в `examples/stateful_mapgroups.py`).

---

## Джоины
- stream-static: эффективно, подходит для обогащения.
- stream-stream: нужен watermark на обеих сторонах и условие по времени.

```python
from pyspark.sql import functions as F
joined = left.join(
    right,
    F.expr(\"\"\"left.user_id = right.user_id AND
              left.event_time BETWEEN right.event_time - interval 5 minutes
                               AND right.event_time + interval 5 minutes\"\"\"))
```

---

## Триггеры
- `Trigger.ProcessingTime("5 seconds")`
- `Trigger.Once()`
- `Trigger.AvailableNow()`

---

## foreachBatch
Используйте для вставок в внешние системы, ретраев, транзакций. См. пример `examples/foreachbatch_jdbc_minio.py`.

---

## Надёжность
- Обязательно `checkpointLocation`.
- Kafka: ключи + `acks=all`.
- Exactly-once — зависит от sink (Delta, транзакции/идемпотентность).

---

## Производительность
- Настрой `spark.sql.shuffle.partitions` по данным.
- Следи за размером файлов (small files), делай compaction.
- Полезны broadcast-джоины, фильтрация как можно раньше (predicate pushdown).

---

## Тестирование
- `MemoryStream` для юнитов — см. `examples/testing_memory_stream.py`.
- Интеграционные — контейнеры Kafka/DB/MinIO.

---

## Мониторинг
- Spark UI / History Server.
- Prometheus + JMX exporter + Grafana.
- OpenTelemetry метрики на уровне приложения (liveness, batch duration, throughput).
- Логи → ELK/Loki.
- Kafka lag (Burrow/Kafka Exporter).

---

## Деплой
- Standalone, YARN, Kubernetes.
- В Kubernetes — агенты метрик (jmx_exporter), sidecar для логов, init-контейнеры для JARов.

---

## Частые ошибки (кратко)
- Поток упал из-за исключения: оборачивать внешние вызовы в try/except внутри `foreachBatch`, проблемные записи — в «мусорный» sink.
- Нет записей в sink: неверный `outputMode` или watermark логика.
- Высокий lag: увеличь параллелизм, сними тяжёлые трансформации, настраивай Trigger.
- Small files: `AvailableNow`/compaction/коалесинг.
- OOM/GC: меньше shuffle, broadcast join, контроль state store.

---

## Шпаргалка
- `withWatermark(col, delay)`, окна `window(col, '5 minutes')`
- `outputMode`: append / update / complete
- Триггер: `.trigger(processingTime="5 seconds")`
- `.option("checkpointLocation","/path")` — must-have
- `foreachBatch` для внешних систем
